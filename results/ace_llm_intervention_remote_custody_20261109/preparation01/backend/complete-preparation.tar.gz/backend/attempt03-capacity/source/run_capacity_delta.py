from pathlib import Path
import datetime,hashlib,json,os,resource,shutil,subprocess,sys,time
O=Path(__file__).resolve().parent;E=O/'attempt03-capacity';E.mkdir();(E/'source').mkdir();(E/'fixtures').mkdir()
for n in ['remote_custody.py','test_remote_custody.py','test_capacity_delta.py','run_capacity_delta.py']:shutil.copyfile(O/n,E/'source'/n)
methods=['test_scratch_capacity_shortfall_before_archive','test_project_capacity_shortfall_before_archive','test_local_shortfall_before_selected_or_operation_payload','test_same_filesystem_capacity_obligations_are_combined','test_affected_positive_has_capacity_in_intents_and_receipts']
cmd=[sys.executable,'-B',str(E/'source/test_capacity_delta.py')]+['CapacityTests.'+n for n in methods];env=dict(os.environ,ACE_REMOTE_CUSTODY_FIXTURES=str(E/'fixtures'),PYTHONDONTWRITEBYTECODE='1')
t=time.monotonic();b=resource.getrusage(resource.RUSAGE_CHILDREN)
with (E/'stdout.txt').open('xb') as out,(E/'stderr.txt').open('xb') as err:p=subprocess.run(cmd,cwd='/tmp',env=env,stdout=out,stderr=err)
a=resource.getrusage(resource.RUSAGE_CHILDREN);wall=time.monotonic()-t
files={}
for f in sorted(E.rglob('*')):
 if f.is_symlink():files[str(f.relative_to(E))]={'type':'intentional_negative_fixture_symlink','target':os.readlink(f)}
 elif f.is_file():files[str(f.relative_to(E))]={'bytes':f.stat().st_size,'sha256':hashlib.sha256(f.read_bytes()).hexdigest(),'nlink':f.stat().st_nlink}
r={'status':'passed' if p.returncode==0 else 'failed','returncode':p.returncode,'command':cmd,'cwd':'/tmp','utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'wall_seconds':wall,'child_cpu_seconds':a.ru_utime+a.ru_stime-b.ru_utime-b.ru_stime,'peak_rss_bytes_macos':a.ru_maxrss,'files':files,'fixture_aliases':'Deliberate original-hardlink fixtures only; source/evidence independent bytes','actual_remote_actions':False,'actual_scientific_inputs_read':False}
(E/'receipt.json').write_text(json.dumps(r,sort_keys=True,indent=2)+'\n');print(json.dumps({k:v for k,v in r.items() if k!='files'},indent=2));sys.exit(p.returncode)
