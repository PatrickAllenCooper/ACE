"""New capacity-only fixtures; no SSH or real remote capacity observation."""
import json
from pathlib import Path
from types import SimpleNamespace
import unittest
from unittest import mock
from test_remote_custody import Tests,c

class CapacityTests(Tests):
    def short_remote(self,parent):
        real=c.os.statvfs
        def capacity(path):
            if Path(path)==parent:return SimpleNamespace(f_bavail=1,f_frsize=1)
            return real(path)
        with mock.patch.object(c.os,'statvfs',side_effect=capacity),self.assertRaisesRegex(ValueError,'insufficient storage capacity'):
            self.collect()
        for directory in (self.backup,self.scratch/'ACE_custody_transfer/backup'):
            self.assertFalse((directory/'raw.tar').exists())
            self.assertTrue((directory/'failure.json').is_file())
            record=json.loads((directory/'capacity.json').read_bytes());self.assertFalse(record['admitted'])
            for row in record['observations']:
                self.assertEqual(row['payload_bytes'],c.tar_size(c.normalized(self.observation)))
                self.assertGreater(row['metadata_budget_bytes'],0)
                self.assertEqual(row['headroom_bytes'],c.CAPACITY_HEADROOM)
            self.assertFalse(record['institutional_backup_attested'])

    def test_scratch_capacity_shortfall_before_archive(self):
        self.short_remote(self.scratch/'ACE_custody_transfer')

    def test_project_capacity_shortfall_before_archive(self):
        self.short_remote(self.projects/'ACE_evidence')

    def test_local_shortfall_before_selected_or_operation_payload(self):
        with mock.patch.object(c.os,'statvfs',return_value=SimpleNamespace(f_bavail=1,f_frsize=1)),self.assertRaisesRegex(ValueError,'insufficient storage capacity'):
            self.collect()
        c.transport.assert_not_called();self.assertEqual(list(self.local.iterdir()),[])
        self.assertFalse((self.root/'collect-log').exists());self.assertFalse(self.backup.exists())

    def test_same_filesystem_capacity_obligations_are_combined(self):
        head=c.CAPACITY_HEADROOM
        # Each obligation fits alone; their simultaneous total does not.
        with mock.patch.object(c.os,'statvfs',return_value=SimpleNamespace(f_bavail=head+100,f_frsize=1)):
            result=c.capacity_observation([('a',self.root,60,10),('b',self.local,60,10)])
        self.assertFalse(result['admitted']);self.assertEqual(len(result['filesystem_totals']),1)
        self.assertEqual(next(iter(result['filesystem_totals'].values()))['required_bytes'],2*(head+70))

    def test_affected_positive_has_capacity_in_intents_and_receipts(self):
        super().test_archive_subset_verify_fetch_and_independent_hardlinks()
        receipt=json.loads((self.root/'collect-log/receipt.json').read_bytes())
        cap=receipt['capacity']
        self.assertTrue(cap['remote_initial']['admitted']);self.assertTrue(cap['project_before_copy']['admitted']);self.assertTrue(cap['local']['admitted'])
        self.assertEqual(cap['remote_initial'],json.loads((self.backup/'intent.json').read_bytes())['capacity'])
        self.assertEqual(cap['local'],json.loads((self.root/'collect-log/intent.json').read_bytes())['capacity'])
        roles={row['role']:row for row in cap['local']['observations']}
        self.assertEqual(roles['local_selected_payload']['payload_bytes'],sum(v['bytes'] for v in receipt['local_inventory']['files'].values()))
        self.assertGreater(roles['local_operation_metadata']['metadata_budget_bytes'],0)
        for operation in ('verify-log','fetch-log'):
            self.assertTrue(json.loads((self.root/operation/'capacity.json').read_bytes())['admitted'])

if __name__=='__main__':unittest.main(verbosity=2)
