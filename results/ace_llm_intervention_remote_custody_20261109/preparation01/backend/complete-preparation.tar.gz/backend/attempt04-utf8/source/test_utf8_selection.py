"""One new fabricated metadata selection fixture; no payload or remote calls."""
from pathlib import Path
import hashlib
import importlib.util
import json
import os
import unittest

HERE=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('remote_custody_utf8',HERE/'remote_custody.py')
c=importlib.util.module_from_spec(spec);spec.loader.exec_module(c)

class Selection(unittest.TestCase):
    def test_utf8_current_numeric_input_selected_legacy_omitted(self):
        info={'bytes':15,'sha256':hashlib.sha256(b'fake input only').hexdigest()}
        current='launch/cpu/worker/artifacts/numeric-calls/call-000/input.utf8'
        legacy='training/worker/numeric-calls/call-000/input.utf8'
        names=[current,legacy]
        dirs=sorted({'/'.join(n.split('/')[:i]) for n in names for i in range(1,len(n.split('/')))})
        full=c.normalized({'files':{n:dict(info) for n in names},'directories':dirs})
        selected,omitted=c.selected_inventory(full)
        self.assertEqual(selected['files'],{current:info})
        self.assertEqual(omitted,{legacy:info})
        self.assertEqual(selected['directories'],['/'.join(current.split('/')[:i]) for i in range(1,len(current.split('/'))) ])
        self.assertEqual(set(selected['files'])|set(omitted),set(full['files']))
        evidence={'fabricated':True,'full_inventory':full,'selected_inventory':selected,'omitted_files':omitted}
        with (Path(os.environ['ACE_UTF8_FIXTURES'])/'selection.json').open('x') as f:json.dump(evidence,f,sort_keys=True,indent=2)

if __name__=='__main__':unittest.main(verbosity=2)
