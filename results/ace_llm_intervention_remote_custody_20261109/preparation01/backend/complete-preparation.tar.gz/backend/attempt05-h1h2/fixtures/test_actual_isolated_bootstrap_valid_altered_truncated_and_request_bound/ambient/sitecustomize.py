from pathlib import Path
Path('/private/tmp/ace-remote-custody-helper-a519xa2a/attempt05-h1h2/fixtures/test_actual_isolated_bootstrap_valid_altered_truncated_and_request_bound/ambient-executed').write_text("unexpected")
