"""New artificial fixtures only. All APIs use an in-process toy transport, never SSH."""
import hashlib
import importlib.util
import io
import json
import os
from pathlib import Path
import shutil
import unittest
from unittest import mock

HERE=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('remote_custody_tested',HERE/'remote_custody.py')
c=importlib.util.module_from_spec(spec);spec.loader.exec_module(c)
c.bind_source((HERE/'remote_custody.py').read_bytes(),hashlib.sha256((HERE/'remote_custody.py').read_bytes()).hexdigest())
ROOT=Path(os.environ['ACE_REMOTE_CUSTODY_FIXTURES'])

class Tests(unittest.TestCase):
    def setUp(self):
        self.root=ROOT/self._testMethodName;self.root.mkdir(mode=0o700)
        self.scratch=self.root/'scratch';self.scratch.mkdir(mode=0o700)
        self.projects=self.root/'projects';self.projects.mkdir(mode=0o700);self.projects.chmod(0o2770)
        self.patchers=[mock.patch.object(c,'SCRATCH_PARENT',self.scratch),mock.patch.object(c,'PROJECT_PARENT',self.projects),mock.patch.object(c,'PROJECT_BASE',self.projects/'ACE_evidence'),mock.patch.object(c,'TRANSFER_BASE',self.scratch/'ACE_custody_transfer'),mock.patch.object(c.subprocess,'Popen',side_effect=AssertionError('NO SSH/child process in fixture'))]
        for p in self.patchers:p.start();self.addCleanup(p.stop)
        launch=self.scratch/'stage';(launch/'inputs').mkdir(parents=True);(launch/'logs').mkdir();(launch/'empty').mkdir()
        (launch/'inputs/source.py').write_bytes(b'# fabricated source\n');(launch/'inputs/adapter.pt').write_bytes(b'opaque fake adapter bytes: no tensors')
        (launch/'inputs/array.npy').write_bytes(b'opaque fake array')
        (launch/'logs/run.log').write_bytes(b'fabricated log\n')
        (launch/'inputs/header.tar.json').write_bytes(b'{"fake":true}')
        os.link(launch/'logs/run.log',launch/'logs/hardlinked.log')
        old=self.scratch/'old';old.mkdir();(old/'legacy.json').write_bytes(b'{"not_selected":true}')
        namespace=self.scratch/'namespace.json';namespace.write_bytes(b'{"fabricated":true}')
        self.roots={'launch':str(launch),'old':str(old),'namespace.json':str(namespace)}
        full,ids,groups=c.scan(self.roots);self.observation={**full,'original_hardlink_groups':groups,'artificial':True}
        self.backup=self.projects/'ACE_evidence/backup';self.local=self.root/'selected';self.local.mkdir(mode=0o700)
        self.transport_patch=mock.patch.object(c,'transport',side_effect=self.toy_transport);self.transport_patch.start();self.addCleanup(self.transport_patch.stop)

    def toy_transport(self,request,receiver,helper_path,logs):
        out=io.BytesIO();c.remote_main(request,out)
        data=out.getvalue()
        for n in range(0,len(data),17):receiver.feed(data[n:n+17])
        receiver.finish()

    def collect(self):
        return c.collect_backup(observation=self.observation,roots=self.roots,backup_root=str(self.backup),local_root=str(self.local),helper_path='/never-used/transport',log_dir=str(self.root/'collect-log'))

    def test_archive_subset_verify_fetch_and_independent_hardlinks(self):
        r=self.collect();self.assertTrue(r['full_backup_verified']);self.assertFalse(r['full_local_copy']);self.assertFalse(r['acceptance'])
        self.assertEqual(r['full_inventory'],c.normalized(self.observation));self.assertEqual(c.local_inventory(self.local),r['local_inventory'])
        self.assertNotIn('old/legacy.json',r['local_inventory']['files'])
        self.assertNotIn('launch/inputs/adapter.pt',r['local_inventory']['files'])
        self.assertNotIn('launch/inputs/header.tar.json',r['local_inventory']['files'])
        self.assertTrue((self.backup/'raw.tar').is_file());self.assertFalse((self.backup/'raw').exists())
        self.assertEqual(self.projects.stat().st_mode&0o7777,0o2770)
        self.assertEqual(self.backup.stat().st_mode&0o7777,0o700)
        self.assertEqual((self.projects/'ACE_evidence').stat().st_mode&0o7777,0o700)
        a=self.local/'launch/logs/run.log';b=self.local/'launch/logs/hardlinked.log'
        self.assertNotEqual(a.stat().st_ino,b.stat().st_ino);self.assertEqual(a.stat().st_nlink,b.stat().st_nlink,1)
        self.assertTrue(r['original_hardlink_groups'])
        v=c.verify_backup(receipt=r,observation=self.observation,helper_path='/unused',log_dir=str(self.root/'verify-log'));self.assertEqual(v['receipt_sha256'],c.sha(c.raw(r)))
        staging=self.root/'staging';staging.mkdir(mode=0o700);n='launch/inputs/adapter.pt';dst=staging/'adapter.pt'
        f=c.fetch_exact(receipt=r,member=n,expected_sha256=r['full_inventory']['files'][n]['sha256'],destination=str(dst),helper_path='/unused',log_dir=str(self.root/'fetch-log'))
        self.assertTrue(f['verified']);self.assertEqual(dst.read_bytes(),(Path(self.roots['launch'])/'inputs/adapter.pt').read_bytes())
        with self.assertRaises(ValueError):c.fetch_exact(receipt=r,member=n,expected_sha256=f['sha256'],destination=str(dst),helper_path='/unused',log_dir=str(self.root/'no-retry-log'))

    def test_missing_extra_traversal_duplicates_and_alias_reject(self):
        bad=json.loads(json.dumps(self.observation));bad['directories'].append(bad['directories'][0])
        with self.assertRaises(ValueError):c.normalized(bad)
        bad=json.loads(json.dumps(self.observation));bad['files']['launch/../escape']={'bytes':0,'sha256':c.sha(b'')}
        with self.assertRaises(ValueError):c.normalized(bad)
        (Path(self.roots['launch'])/'extra.txt').write_bytes(b'extra')
        with self.assertRaisesRegex(ValueError,'original observation'):self.collect()
        self.assertTrue((self.backup/'failure.json').is_file());self.assertFalse((self.backup/'raw.tar').exists())
        with self.assertRaises(FileExistsError):self.collect()

    def test_source_mutation_after_archive_preserved(self):
        original=c.make_tar
        def mutate(path,full,roots,ids):
            original(path,full,roots,ids);(Path(roots['launch'])/'inputs/source.py').write_bytes(b'changed source')
        with mock.patch.object(c,'make_tar',side_effect=mutate),self.assertRaisesRegex(ValueError,'original tree changed'):
            self.collect()
        transfer=self.scratch/'ACE_custody_transfer/backup'
        self.assertTrue((transfer/'raw.tar').is_file());self.assertTrue((transfer/'failure.json').is_file());self.assertFalse((self.backup/'raw.tar').exists())

    def test_backup_corruption_and_exact_fetch_pin_rejected(self):
        r=self.collect();stage=self.root/'staging';stage.mkdir(mode=0o700)
        with self.assertRaises(ValueError):c.fetch_exact(receipt=r,member='old/legacy.json',expected_sha256=r['full_inventory']['files']['old/legacy.json']['sha256'],destination=str(stage/'old'),helper_path='/unused',log_dir=str(self.root/'wrong-member'))
        with self.assertRaises(ValueError):c.fetch_exact(receipt=r,member='launch/inputs/adapter.pt',expected_sha256='0'*64,destination=str(stage/'bad'),helper_path='/unused',log_dir=str(self.root/'wrong-pin'))
        backup=self.backup/'raw.tar';copy=self.root/'archive-before-corruption.tar';shutil.copyfile(backup,copy)
        with backup.open('r+b') as f:f.seek(512);f.write(b'X')
        with self.assertRaises(ValueError):c.verify_backup(receipt=r,observation=self.observation,helper_path='/unused',log_dir=str(self.root/'corruption-log'))
        self.assertTrue((self.root/'corruption-log/failure.json').exists());self.assertTrue(copy.exists())

    def test_ambiguous_completed_remote_copy_never_retried(self):
        calls=[]
        def ambiguous(request,receiver,helper_path,logs):
            calls.append(request);c.remote_collect(request);raise TimeoutError('fabricated lost transport after durable copy')
        with mock.patch.object(c,'transport',side_effect=ambiguous),self.assertRaises(TimeoutError):self.collect()
        self.assertEqual(len(calls),1);self.assertTrue((self.backup/'raw.tar').exists());failure=c.decode((self.root/'collect-log/failure.json').read_bytes());self.assertTrue(failure['remote_outcome_ambiguous'])
        with self.assertRaises(FileExistsError):self.collect()
        self.assertTrue((self.backup/'receipt.json').exists())

    def test_limits_static_bundle_and_deterministic_selection(self):
        p='0'*64
        # Pure metadata only, no multi-GiB fixture allocation or actual static input access.
        full=c.normalized({'files':{'runtime.tar':{'bytes':8438650880,'sha256':p},'model.bin':{'bytes':1519182365,'sha256':p}},'directories':[]})
        self.assertEqual(c.selected_inventory(full)[0]['files'],{})
        with self.assertRaises(ValueError):c.normalized({'files':{'big':{'bytes':9*1024**3+1,'sha256':p}},'directories':[]})
        with self.assertRaises(ValueError):c.normalized({'files':{'a':{'bytes':9*1024**3,'sha256':p},'b':{'bytes':9*1024**3,'sha256':p}},'directories':[]})
        too={'files':{f'launch/{i:02}.json':{'bytes':32*1024**2,'sha256':p} for i in range(17)},'directories':['launch']}
        with self.assertRaisesRegex(ValueError,'no partial subset'):c.selected_inventory(c.normalized(too))
        one={'files':{'launch/large.json':{'bytes':32*1024**2+1,'sha256':p}},'directories':['launch']}
        local,omitted=c.selected_inventory(c.normalized(one));self.assertEqual(local['files'],{});self.assertEqual(omitted,one['files'])

    def test_symlink_archive_and_partial_local_stream_retained(self):
        r=self.collect();path=self.backup/'raw.tar';path.rename(self.backup/'preserved.tar');path.symlink_to(self.backup/'preserved.tar')
        with self.assertRaises(OSError):c.verify_backup(receipt=r,observation=self.observation,helper_path='/unused',log_dir=str(self.root/'symlink-log'))
        out=self.root/'partial.bin';meta={'bytes':6,'sha256':c.sha(b'abcdef')};recv=c.Receiver({'launch/inputs/x':meta},{'launch/inputs/x':out},lambda result:None)
        header=c.raw({'result':{'fabricated':True},'stream_files':{'launch/inputs/x':meta}})
        try:
            recv.feed(len(header).to_bytes(8,'big')+header+b'abc')
            with self.assertRaises(ValueError):recv.finish()
        finally:recv.close()
        self.assertEqual(out.read_bytes(),b'abc')

if __name__=='__main__':unittest.main(verbosity=2)
