from pathlib import Path
import datetime,hashlib,json,os,resource,shutil,subprocess,sys,time
O=Path(__file__).resolve().parent;E=O/'attempt02';E.mkdir();(E/'source').mkdir();(E/'fixtures').mkdir()
for n in ['remote_custody.py','test_remote_custody.py','run_tests.py']:shutil.copyfile(O/n,E/'source'/n)
cmd=[sys.executable,'-B',str(E/'source/test_remote_custody.py'),'Tests.test_archive_subset_verify_fetch_and_independent_hardlinks','Tests.test_limits_static_bundle_and_deterministic_selection'];env=dict(os.environ,ACE_REMOTE_CUSTODY_FIXTURES=str(E/'fixtures'),PYTHONDONTWRITEBYTECODE='1')
t=time.monotonic();b=resource.getrusage(resource.RUSAGE_CHILDREN)
with (E/'stdout.txt').open('xb') as out,(E/'stderr.txt').open('xb') as err:p=subprocess.run(cmd,cwd='/tmp',env=env,stdout=out,stderr=err)
a=resource.getrusage(resource.RUSAGE_CHILDREN);wall=time.monotonic()-t
files={}
for f in sorted(E.rglob('*')):
 if f.is_symlink():files[str(f.relative_to(E))]={'type':'intentional_negative_fixture_symlink','target':os.readlink(f)}
 elif f.is_file():files[str(f.relative_to(E))]={'bytes':f.stat().st_size,'sha256':hashlib.sha256(f.read_bytes()).hexdigest(),'nlink':f.stat().st_nlink}
r={'status':'passed' if p.returncode==0 else 'failed','returncode':p.returncode,'command':cmd,'cwd':'/tmp','utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'wall_seconds':wall,'child_cpu_seconds':a.ru_utime+a.ru_stime-b.ru_utime-b.ru_stime,'peak_rss_bytes_macos':a.ru_maxrss,'files':files,'fixture_aliases':'Only deliberate original-hardlink and symlink-rejection fixtures; source/evidence are independent bytes','actual_remote_actions':False,'actual_scientific_inputs_read':False}
(E/'receipt.json').write_text(json.dumps(r,sort_keys=True,indent=2)+'\n');print(json.dumps({k:v for k,v in r.items() if k!='files'},indent=2));sys.exit(p.returncode)
