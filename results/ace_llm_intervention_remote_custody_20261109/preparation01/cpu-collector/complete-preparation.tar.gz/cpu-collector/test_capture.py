import unittest, importlib.util, pathlib, copy
p=pathlib.Path(__file__).with_name('pull_terminal.py')
spec=importlib.util.spec_from_file_location('collector',p);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
class CaptureTests(unittest.TestCase):
 def setUp(self):
  self.full={'files':{'launch/metadata.json':{'sha256':'a'*64,'bytes':12},'launch/adapter.pt':{'sha256':'b'*64,'bytes':100}},'directories':['launch']}
  self.selected={'files':{'launch/metadata.json':self.full['files']['launch/metadata.json']},'directories':['launch']}
  self.receipt={'full_backup_verified':True,'full_inventory':copy.deepcopy(self.full),'local_inventory':copy.deepcopy(self.selected)}
 def test_partial_is_explicit_and_valid(self):
  self.assertEqual(m.validate_backup_capture(self.receipt,self.full,self.selected),self.full)
  self.assertNotEqual(self.selected,self.full)
 def test_missing_or_false_remote_verification(self):
  for value in (False,1,None):
   r=copy.deepcopy(self.receipt);r['full_backup_verified']=value
   with self.assertRaises(ValueError):m.validate_backup_capture(r,self.full,self.selected)
 def test_missing_remote_binary_rejected(self):
  r=copy.deepcopy(self.receipt);del r['full_inventory']['files']['launch/adapter.pt']
  with self.assertRaises(ValueError):m.validate_backup_capture(r,self.full,self.selected)
 def test_local_mutation_rejected(self):
  s=copy.deepcopy(self.selected);s['files']['launch/metadata.json']['sha256']='c'*64
  with self.assertRaises(ValueError):m.validate_backup_capture(self.receipt,self.full,s)
 def test_extra_or_escaping_local_paths_rejected(self):
  for name in ('launch/extra','../escape'):
   r=copy.deepcopy(self.receipt);s=copy.deepcopy(self.selected);s['files'][name]={'sha256':'d'*64,'bytes':1};r['local_inventory']=s
   with self.assertRaises(ValueError):m.validate_backup_capture(r,self.full,s)
 def test_extra_duplicate_directories_rejected(self):
  for dirs in (['launch','extra'],['launch','launch']):
   r=copy.deepcopy(self.receipt);s=copy.deepcopy(self.selected);s['directories']=dirs;r['local_inventory']=s
   with self.assertRaises(ValueError):m.validate_backup_capture(r,self.full,s)
if __name__=='__main__':unittest.main()
