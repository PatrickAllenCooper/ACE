import unittest,importlib.util,pathlib,tempfile,shutil
p=pathlib.Path(__file__).with_name('pull_terminal.py');s=importlib.util.spec_from_file_location('collector',p);m=importlib.util.module_from_spec(s);s.loader.exec_module(m)
class FailureDelta(unittest.TestCase):
 def test_directory_failure_does_not_replace_primary(self):
  root=pathlib.Path(tempfile.mkdtemp(prefix='ace-mirror-failure-'));ext=root/'external';loc=root/'local';ext.mkdir();loc.mkdir();(ext/'remote').mkdir();(ext/'remote'/'record.json').write_text('{}');(loc/'remote').write_text('conflict')
  with self.assertRaisesRegex(RuntimeError,'original transport failure'):
   try:raise RuntimeError('original transport failure')
   except RuntimeError:
    errors=m.mirror_partial_evidence(ext,loc,shutil.copyfile);self.assertEqual(len(errors),1);self.assertEqual((loc/'remote').read_text(),'conflict');raise
 def test_conflict_preserved_and_other_directory_mirrored(self):
  root=pathlib.Path(tempfile.mkdtemp(prefix='ace-mirror-conflict-'));ext=root/'external';loc=root/'local';ext.mkdir();loc.mkdir()
  for tree in (ext,loc):(tree/'remote').mkdir()
  (ext/'remote'/'record.json').write_text('original');(loc/'remote'/'record.json').write_text('different');(ext/'backup-operations').mkdir();(ext/'backup-operations'/'stderr.log').write_text('retained')
  errors=m.mirror_partial_evidence(ext,loc,shutil.copyfile);self.assertEqual(len(errors),1);self.assertEqual((loc/'remote'/'record.json').read_text(),'different');self.assertEqual((loc/'backup-operations'/'stderr.log').read_text(),'retained')
if __name__=='__main__':unittest.main()
