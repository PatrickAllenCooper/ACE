from pathlib import Path
import tempfile,shutil,hashlib,json,difflib
old=Path('/tmp/ace-scientific-cpu-campaign-collector-rmo1sxtp')
r=Path(tempfile.mkdtemp(prefix='ace-scientific-cpu-campaign-collector-complete-',dir='/tmp'))
shutil.copytree(old,r/'predecessor-draft')
base=(old/'predecessors/gpu-collector.py').read_text();s=base
s=s.replace('Complete scientific GPUtrain terminal custody, never training/scientific acceptance.', 'Complete scientific CPU campaign terminal custody, never runtime/scientific acceptance.')
s=s.replace('Only allowlisted public telemetry scalars are decoded after custody; score values and tensors stay opaque.', 'Only allowlisted public scalar/count evidence is decoded after custody; outcomes and tensors stay opaque.')
s=s.replace('ace_llm_intervention_scientific_training_gpu_20261108/launch01','ace_llm_intervention_scientific_campaign_cpu_20261108/launch01')
s=s.replace('ACE-LLM-intervention-scientific-training-gpu-20261108-01','ACE-LLM-intervention-scientific-campaign-cpu-20261108-01')
s=s.replace('ACE-LLM-intervention-scientific-training-gpu-terminal-20261108-01','ACE-LLM-intervention-scientific-campaign-cpu-terminal-20261108-01')
s=s.replace("ROOT='/scratch/alpine/paco0228/ACE/results/ace_llm_intervention_scientific_training_gpu_20261108_01'", "ROOT='/scratch/alpine/paco0228/ACE/results/ace_llm_intervention_scientific_campaign_cpu_20261108_01'\nTRAIN_ROOT='/scratch/alpine/paco0228/ACE/results/ace_llm_intervention_scientific_training_gpu_20261108_01'")
s=s.replace("root_present=root.exists(),cpu_present", "root_present=root.exists(),training_present=Path(TRAIN_ROOT).exists(),cpu_present")
s=s.replace("(('launch',root,v['root_present']),('cpu'", "(('launch',root,v['root_present']),('training',Path(TRAIN_ROOT),v['training_present']),('cpu'")
s=s.replace('# Explicit training-only paths; never enumerate the realization root or read world032..055.', '# Explicit original pinned paths, including24 supplied development descriptor bytes; never enumerate realization or decode payloads.')
start=s.index('RESOURCES=dict(');end=s.index('def tres(',start)
s=s[:start]+s[end:]
start=s.index('def resource_tres(');end=s.index('def public_fields(',start)
s=s[:start]+s[end:]
meta=(old/'cpu_metadata.txt').read_text()
start=s.index('def public_gpu_evidence(');end=s.index('def accounting_extension(',start)
s=s[:start]+meta+'\n\n'+s[end:]
s=s.replace('len(prior)==43','len(prior)==44').replace("len(observation['related_accounting'])==44","len(observation['related_accounting'])==45")
s=s.replace("len(baseline['journal_pins'])==88 and len(journals)==90", "len(baseline['journal_pins'])==90 and len(journals)==92")
s=s.replace("'cpu-terminal-custody','cpu-custody-inventory-sha256'", "'training-terminal-custody','training-custody-inventory-sha256','training-acceptance-sha256','baseline-sha256'")
s=s.replace("packet['schema']=='ace-scientific-training-gpu-launch-v1'", "packet['schema']=='ace-scientific-cpu-campaign-launch-v1'")
s=s.replace("baseline_pin=pins['baseline.json'];", "baseline_pin=a.baseline_sha256;need(baseline_pin==pins['baseline.json'],'independent current baseline pin differs');")
s=s.replace("baseline['terminal_jobs']==43","baseline['terminal_jobs']==44").replace("baseline['submission_journals']==88","baseline['submission_journals']==90")
s=s.replace("len(baseline['related_accounting'])==43","len(baseline['related_accounting'])==44").replace("len(baseline['journal_pins'])==88","len(baseline['journal_pins'])==90")
s=s.replace('actual43-job/88-journal','actual44-job/90-journal')
start=s.index("    need(packet['resources']==intent['resources']==RESOURCES")
end=s.index('    locks=[];claimed=[];',start)
s=s[:start]+(old/'upstream.txt').read_text()+s[end:]
s=s.replace('UPSTREAM_PINS=upstream_pins,COMMON_ROOT=COMMON_ROOT', 'UPSTREAM_PINS=upstream_pins,TRAIN_ROOT=TRAIN_ROOT,COMMON_ROOT=COMMON_ROOT')
s=s.replace('accepted_cpu_root=CPU_ROOT,accepted_collection_root=COMMON_ROOT', 'accepted_training_root=TRAIN_ROOT,accepted_token_root=CPU_ROOT,accepted_collection_root=COMMON_ROOT')
s=s.replace('cpu_custody_inventory_sha256=a.cpu_custody_inventory_sha256', 'training_custody_inventory_sha256=a.training_custody_inventory_sha256')
s=s.replace('cpu_custody_before','prior_custody_before').replace('cpu_custody','prior_custody')
s=s.replace('upstream-cpu-custody','upstream-training-custody')
s=s.replace("(('launch',ROOT,before['root_present']),('cpu',CPU_ROOT,before['cpu_present']),", "(('launch',ROOT,before['root_present']),('training',TRAIN_ROOT,before['training_present']),('cpu',CPU_ROOT,before['cpu_present']),")
s=s.replace("label in ('launch','cpu','common','failed01')", "label in ('launch','training','cpu','common','failed01')")
s=s.replace("and after['cpu_present']==before['cpu_present']", "and after['training_present']==before['training_present'] and after['cpu_present']==before['cpu_present']")
s=s.replace('exact43 prior plus current44th','exact44 prior plus current45th').replace('exact88 prior plus current90','exact90 prior plus current92')
s=s.replace("EXT/'remote/launch/training'", "EXT/'remote/launch/cpu'")
start=s.index("        markers={n:actual['files'].get('launch/training/'+n)")
end=s.index("        outcome='terminal_custody_review_pending'",start)
s=s[:start]+'''        markers={n:actual['files'].get('launch/cpu/'+n) for n in (
            'supervisor.json','failure.json','worker.cleanup.json','worker.resources.json','worker.started.json',
            'worker.lifecycle-errors.json','worker/work-start.json','worker/artifacts/terminal.json',
            'worker/artifacts/failure.json','worker/artifacts/cpu-phase/terminal.json',
            'worker/artifacts/cpu-phase/campaign-bundle.json','worker/artifacts/cpu-phase/ranker/terminal.json')}
        failure_members=sorted(n for n in actual['files'] if n.startswith('launch/cpu/') and
            (Path(n).name.endswith('failure.json') or Path(n).name in ('publication-interruption.json','worker.lifecycle-errors.json')))
        complete_markers=all(markers[n] is not None for n in ('supervisor.json','worker/artifacts/terminal.json','worker/artifacts/cpu-phase/terminal.json'))
        reported=public_cpu_evidence(EXT/'remote/launch/cpu',actual['files'])
        save('public-cpu-evidence.json',reported)
'''+s[end:]
s=s.replace("or any(\n                value is not None for name,value in markers.items() if 'failure.json' in name)", "or failure_members")
s=s.replace("schema='ace-scientific-training-gpu-terminal-custody-v1'", "schema='ace-scientific-cpu-campaign-terminal-custody-v1'")
s=s.replace("output_root=ROOT+'/training'", "output_root=ROOT+'/cpu'")
s=s.replace("recovery_bindings=recovery_bindings,cpu_acceptance_sha256=pins['cpu-acceptance.json'],", "recovery_bindings=recovery_bindings,training_acceptance_sha256=a.training_acceptance_sha256,")
s=s.replace("collection_acceptance_sha256=pins['collection-acceptance.json']", "collection_acceptance_sha256=accepted['collection_acceptance_sha256'],cpu_preparation_acceptance_sha256=accepted['cpu_preparation_acceptance_sha256']")
s=s.replace("public_gpu_evidence_sha256=sha(raw(reported)),development_payloads_read=0,scored_outcomes_decoded=False,", "public_cpu_evidence_sha256=sha(raw(reported)),failure_members=failure_members,\n            collector_new_scientific_responses=0,collector_training_updates=0,development_payloads_decoded=False,scored_outcomes_decoded=False,")
s=s.replace('adapter_tensors_decoded=False,scientific_qualified=False,training_execution_qualified=False', 'checkpoint_tensors_decoded=False,scientific_qualified=False,cpu_campaign_accepted=False')
s=s.replace('retained claims, work signals and exit0 do not qualify runtime, training, utility or science.', 'retained claims, public counts and exit0 do not qualify runtime, fits, utility or science.')
s=s.replace('accepted CPU custody changed during copy','accepted training custody changed during copy').replace('original accepted CPU custody changed','original accepted training custody changed')
s=s.replace('accepted original CPU/collection input bytes changed/missing','accepted original input/descriptor bytes changed/missing')
(r/'pull_terminal.py').write_text(s)
(r/'gpu-predecessor.diff').write_text(''.join(difflib.unified_diff(base.splitlines(True),s.splitlines(True),fromfile='reviewed-gpu-collector.py',tofile='pull_terminal.py')))
Path('/tmp/ace-scientific-cpu-campaign-collector-complete-current.txt').write_text(str(r)+'\n')
print(r)
