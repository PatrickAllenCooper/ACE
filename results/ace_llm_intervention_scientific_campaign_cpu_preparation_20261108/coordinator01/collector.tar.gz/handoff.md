# Scientific CPU campaign terminal collector — prospective authoring handoff

Complete standalone source, ready for independent review. No core roster or production source changed. Original unfinished fragments remain untouched at `/tmp/ace-scientific-cpu-campaign-collector-rmo1sxtp` and are copied in predecessor-draft. Reused reviewed GPU collector mechanism, source9346be8d… and review11f05d7d…, with explicit new CPU/upstream interfaces. No streaming-helper integration: existing SCP mechanism remains; current transfers are untouched.

## Exact source and evidence

- pull_terminal.py: `846681a43770debf2d7cd6cccea2a1ad087758ff0c7a1af16bb5110979252260`
- test_cpu_collector_metadata.py: `72bb1bd6b054f374bd98c906538228c34785532c3b47a3e75cfc564d64aeaa8f`
- test01/receipt.json: `f0e6e5ebb0033cb4800ebce237557d2684f7c1d06bc7d6f66b1f5c6b0f3d5cde`

Five NEW fabricated stdlib methods passed once from cwd /tmp: actual CPU profile/failed allocation charges and unexpected GPU retention; durable reserve/response/failure counts with malformed tail/private fields skipped; all five arms with missing/unexpected journals explicit; exact44→45 rows and90→92 journals preserving failed costs; current core/producer path and captured remote syntax compatibility. Wall0.084893291s, childCPU0.076126s, unittest0.024s. No failed test attempt; intentional failed-job/malformed-journal fixtures, exact source snapshots and raw stdout/stderr remain in test01. No old tests repeated. No collector main, project callable, remote action, model/tokenizer/scientific draw/response, actual build/submission/install or commit.

## Consumer CLI

Required independent arguments, all without defaults/fake future pins:

`--job-id`, `--packet-sha256` (outer launch packet), `--submission-result-sha256`, `--local-intent-sha256`, `--packet-commit` (full40hex), `--collector-sha256`, `--collector-repository-path` (relative .py in that commit), `--collector-review` and `--collector-review-sha256`, `--packet-review` and `--packet-review-sha256`, `--baseline-sha256`, `--training-acceptance-sha256`, `--training-terminal-custody`, `--training-custody-inventory-sha256`.

Collector and its independent review must be captured in the eventual packet commit as standalone files; they need not be added to the already-reviewed core's new_input_files roster. The core packet/launcher/monitor, every packet input and both local mirrors must match that full commit. Current result, local intent, authenticated remote intent plus its two allowed additions, job, independent packet review, baseline and training acceptance must join exactly. No packet is built here.

Fixed outer ROOT is `/scratch/alpine/paco0228/ACE/results/ace_llm_intervention_scientific_campaign_cpu_20261108_01`; outputs ROOT/cpu. Sourcea9346022…/freeze15602614…/collection amendmentfa94858d… unchanged. Exact2CPU7680MiB6000seconds/acpu/cpu-normal, noGPU/no-requeue, startup180/work5940/hard5980; actual saved allocation uses public stdout/returncode schema. Parent Slurm row and all steps/requested TRES/requeue evidence are retained. CPU/GPU cost uses actual allocated counts×elapsed, including failures; unknown accelerator charge remains unresolved, not zero.

## Full custody and upstream interface

Local terminal destination: `results/ace_llm_intervention_scientific_campaign_cpu_20261108/terminal01`. External: `ACE-LLM-intervention-scientific-campaign-cpu-terminal-20261108-01` under existing BASE. Both exclusive; one collection attempt, no automatic reuse/retry.

Under both existing coordinator locks, conclusively terminal current job/no active ACE is required. Collect whole current and upstream roots as remote/launch (CPUcampaign), remote/training (GPUtrain), remote/cpu (TOKEN01), remote/common (collection02), remote/failed01 (failed collection01), plus both separate namespace claims. Preserve complete local/external launch histories and the entire accepted GPUtrain terminal capsule as upstream-training-custody, including its original TOKEN/collection/failure evidence and prior transfer receipts. Whole original upstream file AND directory rosters must match; original hardlink topology is recorded while all local file copies are independent bytes. Symlinks reject.

The core's original_input_pins are rechecked on remote byte reads. Realization access is restricted to the exact original task terminal and24 pinned development descriptor files from that core; no realization directory enumeration or descriptor payload decode. All24 descriptors are also preserved as opaque current inputs. Supplied-world realization public metadata selects only ordered world032..055/IDs202611070100..123. Independently accepted training44/90 baseline is required; current terminal extends it to45/92 with every prior row/journal unchanged. Actual collection42/86 acceptance alone cannot substitute for those later gates.

Two complete remote inventory observations, two independent local copies and final rereads retain source/input/log/output/cleanup/failure/checkpoint bytes. Failed or missing current output is preserved with terminal-failure/partial status, never acceptance. Transport exceptions retain partial stdout/stderr/copies and best-effort mirrored failure inventories without overwrite. No cancellations.

## Public counts, no private scoring

Only after whole raw custody is copied/read back, public-cpu-evidence.json selects allowlisted scalar fields from worker/phase/ranker summaries and scans120 expected five-policy×24-world charged journals. Reserve units, valid responses, known failed returns and unresolved reservations remain distinct. Missing/malformed/partial/unexpected journals stay explicit; totals are lower bounds and total_campaign_response_cost_units is null pending the independent accounting audit. No favorable arm filtering or scientific benefit claim. Unknown JSON values are scanned lexically and never decoded; scores, noisy values/targets/actions, campaign bundle and checkpoint tensors stay opaque. Runtime/resource/cleanup source checks are reused, not rerun by the collector. Collector-generated scientific responses/training updates are0.

No future job ID, costs, acceptance or runtime outcome is invented. No throughput, memory headroom or WAN performance qualification. SCP may remain slow; any future reviewed stream-helper integration is a separate source delta. This source still requires independent collector review and concrete packet pins before use.
