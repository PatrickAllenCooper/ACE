# Scientific CPU campaign coordinator — authoring handoff

Stable prospective source for independent review in this NEW exclusive directory. No packet build, production callable, scientific draw/response, descriptor/outcome decoding, tokenizer/model execution, remote command, install, submission or commit occurred. GPU core/collector remain unchanged after their closed reviews. This authoring does not confer source/runtime/scheduler or scientific qualification.

## Fixed worker and API

Entry `prepare_llm_intervention_scientific_campaign_cpu.py` ba439d819f49f6832c97181e4ff727c4813f29031e7b67f8085670f845b0f893, sourcea9346022f145cc29439325b6f291597b2e6ec037, freeze15602614ef9d7e9a3e21027e7495f891c98ba32a2b6b0ee9857e5b71d5e5e66d. Top-level stage name is cpu_campaign; closure key is CPUcampaign. Exactly49 source names and51 captured source/helper files, including original probe artifact; all67 frozen source-map entries are compared against full Git commit bytes with replace objects disabled. No project module is imported/executed by these coordinators.

2CPU7680MiB6000seconds,zeroGPU,ucb736_asc2/acpu/cpu-normal; absolute startup180/work5940/hard5980, numeric work50/timeout55. No host-memory or runtime-headroom claim. The future allocated worker performs the unchanged staging/runtime/owned-cleanup checks and full scientific validation.

Builder CLI requires `--NAME PATH --NAME-sha256 SHA` for every entry in argument-map.json, plus `--training-remote-custody` and `--realization-task`. Null paths/pins mean missing actual independent evidence, not defaults or fake acceptance. Fixed known authority pins still require supplied original bytes. Builder and launcher each hold both existing coordinator locks; neither creates/replaces namespace claims.

The original freeze/adoption/namespace and realization recovery authority stay separate from collection-only amendmentfa94858d. The original failed collection acceptance00c4557a, proof59c21d63 and baselineeeec362d are pinned through the accepted GPU packet. Current actual44-job/90-journal baseline and preceding accepted43/88 baseline are mandatory independent inputs. They must join original training acceptance/result/packet/disposition/inventory, complete predecessor rows/journals and actual4CPU×elapsed/1MIG×elapsed. Failed charges remain included. No future job duration/cost/acceptance defaults exist. Remaining frozen stage caps plus the single3600CPU preparation allowance must fit57600CPU/7200GPU. Collection02 submission/completion alone cannot pass this gate.

`gpu-training-acceptance` consumes the existing lineage helper's schema ace-scientific-training-gpu-acceptance-v1, status scientific_training_gpu_accepted, scopepolicy_train, integer0 findings, full training/checkpoint-reload/custody/runtime/cleanup/scheduler qualification, scientific_utility_qualifiedfalse, exact prepared/plan/exposure/source/freeze/model/runtime/collection/CPU-acceptance/job lineage, engine terminal and both SFT/final checkpoint/adapter pins. No new acceptance schema is introduced.

`expected-training` is a separate caller-owned pinned JSON containing exactly job_id, source_commit, prepared_sha256, training_plan_sha256, exposure_sha256, scientific_freeze_sha256, collection_acceptance_sha256, cpu_preparation_acceptance_sha256, model_files_sha256, runtime_contract_sha256. It is checked against independently accepted CPU preparation/freeze and GPU acceptance, rather than self-extracted from GPU acceptance. Original strict18-field CPU acceptance remains unchanged and supplies the numerical-plan byte/semantic pins.

Original GPU collector inventory_transport.json is `training-inventory`; disposition.json is training-disposition. The accepted GPU capsule remote tree supplies original prepared bytes at launch/inputs/prepared.json; numerical plan at cpu/preparation/session/worker/artifacts/numerical-plan.json; and engine terminal/checkpoints/adapters at launch/training/session/worker/artifacts/fit/training/. Those paths match the new standalone GPU collector interface. Original realization terminal/inventory/acceptance must pin all56 metadata entries. Exactly its world032..055 files are copied byte-for-byte as descriptor000..023 after admission; descriptor JSON is never decoded by the coordinator.

## Scientific inputs and prospective services

95 exact worker inputs comprise51 captured source/helper files and44 data declarations/artifacts. The original proposal supplies24 ordered development IDs and192 arms, shared8 observe_all initial actions/cost8, additional24 acquisition budget, and original per-arm namespaces. The coordinator constructs96 numerical binding declarations from public proposal fields only. It does not draw coefficients/responses or select/filter cells. The actual worker checks these against its unchanged assembler, fits the matched numerical ranker from the independently accepted full plan, enforces exact exposure equivalence, and runs only uniform_random/menu_coverage/local_information/target_risk/learned_ranker. It retains charged attempts/failures and cannot invoke LLM inference/private scoring in this phase.

Prepared/numerical-plan data and engine/checkpoint/adapter payloads are copied/hashes only. Same-exposure/SFT-reference/optimizer/checkpoint semantics remain enforced by the frozen production worker against accepted original bytes; authoring does not rerun them. No existing trained numerical ranker is substituted for the planned matched fit.

Three prospective services bind pristine frozen weights, accepted finalSFT, and accepted finalDPO respectively. Public service recipe/source/runtime/model identity is captured from pinned source via a narrow AST literal resolver, not module execution. Limits are startup120/request30/idle30,total1200 from frozen GPU session cap,max576; caller limits125 startup/35 request/5 cleanup. These are prospective declarations requiring concrete review, not claims of actual GPU throughput. No service starts here.

The future GPU output spelling is frozen GPU-stage ROOT plus `/gpu`; service launch/worker directories and shared stage-binding/stage files all use that root. It is outside CPU inputs/output. Future GPU coordinator must consume these exact contracts without rebinding them. Actual frozen GPU wall is2880seconds (not a reconstructed2890 assumption); global closure uses the original stage list verbatim.

## Packet, launcher and monitor

Repository results/ace_llm_intervention_scientific_campaign_cpu_20261108/launch01; external ACE-LLM-intervention-scientific-campaign-cpu-20261108-01 under the existing BASE; remote ROOT /scratch/alpine/paco0228/ACE/results/ace_llm_intervention_scientific_campaign_cpu_20261108_01.

Outer coordinator packet ROOT/packet.json, inner worker packet ROOT/inputs/packet.json, admission ROOT/inputs/admission.json. Worker output ROOT/cpu; actual prepared192-arm campaign at ROOT/cpu/worker/artifacts/campaign; matched ranker at ROOT/cpu/worker/artifacts/cpu-phase/ranker. The inner packet is ace-scientific-campaign-cpu-v1. Its exact existing admission schema is conditional on independent prior authority and the launcher's fresh gates, not proof of future runtime success. Publication is exclusive, with original failures retained and no retry/adoption.

launch_once.py requires packet-directory/full packet-commit/packet-sha256/packet-review path+SHA. It reauthenticates/reconstructs exact source/input declarations without production calls, verifies both committed mirrors, both namespace claims, and twice reconciles every original44 row/90 journal plus no active ACE job, account/QoS/partition wall/memory and original accepted bytes. It verifies transferred pins/readback, retains local then remote intent, and issues one sbatch. Ambiguous/timeout transports retain partial streams and prohibit blind retry. No model-weight hash traversal or GPU allocation is done by the CPU launcher; model identity stays frozen metadata and trained adapter bytes remain opaque input artifacts.

monitor_once.py requires packet-directory/packet-sha256/submission-result-sha256/evidence-directory. It reads only scheduler and known worker/output marker hashes, including current worker.cleanup.json, worker.resources.json and worker.started.json. It never cancels, accepts, retries or reads outcomes. A complete terminal collector is a separate future task, outside this requested core.

## Evidence and limits

static01 retained three NEW passing metadata/static tests: actual frozen closure/literal interfaces, coordinator/embedded-remote syntax, and failed/unknown/duplicate GPU cost accounting. During final interface inspection the inherited monitor cleanup spelling was corrected to the actual shared helper's worker.cleanup.json/worker.resources.json. monitor-delta02 ran only one NEW exact-marker AST regression; passed. No earlier methods were rerun. Both snapshots, exact stdout/stderr and process costs remain retained. No admit/main/make_packet function or scientific production callable was executed; the three-source prospective integration still requires independent static review and later concrete packet review.

Predecessors preserve the accepted artificial CPU03 coordinator plus the closed GPU core used for modern locking/once-only transport/metadata authentication. Per-script diffs against artificial CPU03 and exact current source pins are included. Existing production/source/reviews and all other authoring trees were not edited.

## Exact current pins

- build_packet.py: `4f9aeefe929d89f70fd98a93d8368fbe1b150b4ef7189e2a7f258f306325e19e`
- launch_once.py: `d2b731024b9dbc567f5254fa6b9ba65875909a9309c4c0dec88c735cdc08cec0`
- monitor_once.py: `354cab58ecf5416293ee8464f133906d4cd05e6f080e47ff5a8160a0e93e0b5e`
- test_static_interfaces.py: `a4266c2f363264c7b9953e67db1c64a9a9b349cb57bda958775bc3148e9e5d03`
