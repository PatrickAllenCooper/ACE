"""NEW fabricated CPU collector edges only; no collector main, project calls or transport."""
import ast,copy,hashlib,importlib.util,json,os,tempfile,unittest
from pathlib import Path
from unittest import mock
ROOT=Path(__file__).parent
spec=importlib.util.spec_from_file_location('cpu_custody_sidecar',ROOT/'pull_terminal.py')
m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
class CpuCollectorMetadata(unittest.TestCase):
 def setUp(self):
  self.root=Path(tempfile.mkdtemp(prefix='fabricated-',dir=ROOT)).resolve()
 def row(self,job='999',state='FAILED',elapsed='126',cpus='2',tres='cpu=2,mem=7680M,node=1'):
  return [job,'ace_llm_scientific_campaign_cpu01',state,'1:0' if state=='FAILED' else '0:0',cpus,elapsed,'ucb736_asc2',tres]
 def observation(self):
  return dict(parent_accounting=self.row(),results=dict(details=dict(returncode=0,stdout='999|acpu|cpu-normal|100|cpu=2,mem=7680M,node=1|paco0228|\n'),job=dict(returncode=0,stdout='JobId=999 Requeue=0 Restarts=0')))
 def journal(self,path,records,tail=b''):
  path.parent.mkdir(parents=True,exist_ok=True)
  path.write_bytes(b''.join((json.dumps(r)+'\n').encode() for r in records)+tail)
  return m.fingerprint(path,sole_link=True)
 def test_cpu_failed_job_actual_resources_and_unexpected_gpu_are_not_zeroed(self):
  obs=self.observation();saved=self.root/'allocation.json'
  saved.write_bytes(m.raw(dict(returncode=0,stdout='JobId=999 Requeue=0 Restarts=0',stderr='')))
  pins={'launch/cpu/allocation.json':m.fingerprint(saved)}
  v=m.resources(obs,'999',self.root,pins)
  self.assertTrue(v['resource_contract_matched']);self.assertEqual(v['scheduler_state'],'FAILED')
  self.assertEqual((v['allocated_cpu_seconds'],v['gpu_slice_seconds']),(252,0))
  for cpus,tres in [('8','cpu=8,mem=7680M,node=1'),('2','cpu=2,mem=7680M,node=1,gres/gpu:a100_3g.20gb=1'),('2','')]:
   bad=copy.deepcopy(obs);bad['parent_accounting']=self.row(cpus=cpus,tres=tres)
   v=m.resources(bad,'999',self.root,pins);self.assertFalse(v['resource_contract_matched'])
   if 'gres/gpu' in tres:self.assertEqual(v['gpu_slice_seconds'],126)
   if not tres:self.assertIsNone(v['gpu_slice_seconds'])
 def test_charge_failures_partial_tail_and_private_values_remain_opaque(self):
  records=[dict(event='reserve',request_id=0,cost_units=2,action={'SECRET':[0,1]}),
    dict(event='response',request_id=0,cost_units=2,values={'SECRET':17}),
    dict(event='reserve',request_id=1,cost_units=1),dict(event='failure',request_id=1,response_returned_to_driver=None),
    dict(event='reserve',request_id=2,cost_units=3),dict(event='failure',request_id=2,response_returned_to_driver=True),
    dict(event='reserve',request_id=3,cost_units=1)]
  p=self.root/'journal.jsonl';pin=self.journal(p,records,b'{"event":"reserve"')['sha256']
  original=m.decode
  def public_only(data):
   self.assertNotIn('SECRET',data if isinstance(data,str) else data.decode());return original(data)
  with mock.patch.object(m,'decode',public_only):v=m.charged_journal(p,pin)
  self.assertEqual((v['recorded_reserved_requests'],v['known_reserved_units_lower_bound'],v['recorded_valid_responses']),(4,7,1))
  self.assertEqual((v['recorded_failure_events'],v['recorded_failed_returns'],v['unresolved_reservations']),(2,1,2))
  self.assertTrue(v['errors']);self.assertFalse(v['ledger_fully_validated'])
  with self.assertRaises(ValueError):m.charged_journal(p,'0'*64)
 def test_all_five_arms_missing_and_unexpected_journals_remain_explicit(self):
  files={}
  for i in range(5):
   n=f'worker/artifacts/campaign/policy-{i:02d}/world-00/episode/journal.jsonl'
   records=[dict(event='reserve',request_id=0,cost_units=i+1),dict(event='failure',request_id=0,response_returned_to_driver=None)]
   files['launch/cpu/'+n]=self.journal(self.root/n,records)
  extra='worker/artifacts/campaign/policy-05/world-00/episode/journal.jsonl'
  files['launch/cpu/'+extra]=self.journal(self.root/extra,[dict(event='reserve',request_id=0,cost_units=1)])
  ranker='worker/artifacts/cpu-phase/ranker/terminal.json';p=self.root/ranker;p.parent.mkdir(parents=True,exist_ok=True)
  p.write_bytes(m.raw(dict(completed_steps=164,sft_steps=160,dpo_steps=4,losses={'SECRET':[0,1]})))
  files['launch/cpu/'+ranker]=m.fingerprint(p)
  # Opaque artifacts are present but never opened by public summarization.
  for n in ['worker/artifacts/cpu-phase/campaign-bundle.json','worker/artifacts/cpu-phase/ranker/dpo.ranker.pt']:
   p=self.root/n;p.write_bytes(b'opaque private fixture');files['launch/cpu/'+n]=m.fingerprint(p)
  read=m.read_metadata
  def only_public(path,*args):
   self.assertNotIn('campaign-bundle.json',str(path));self.assertFalse(str(path).endswith('.pt'));return read(path,*args)
  with mock.patch.object(m,'read_metadata',only_public):v=m.public_cpu_evidence(self.root,files)
  self.assertEqual(v['authorized_cpu_policies'],list(m.POLICIES[:5]));self.assertEqual(v['observed_charge_journals'],5)
  self.assertEqual(len(v['missing_expected_journals']),115);self.assertEqual(v['unexpected_journals'],[extra])
  self.assertEqual(v['known_reserved_units_lower_bound'],15);self.assertEqual(v['unresolved_reservations'],5)
  self.assertIsNone(v['total_campaign_response_cost_units']);self.assertFalse(v['complete_response_accounting_qualified'])
  self.assertEqual(v['collector_new_scientific_responses'],0)
  self.assertEqual(v['reported_metadata'][ranker]['reported']['completed_steps'],164)
 def test_exact_44_to_45_history_90_to_92_journals_preserves_failed_cost(self):
  rows=[self.row(str(i),elapsed='1') for i in range(1,45)]
  baseline=dict(related_accounting=rows,journal_pins={f'/fabricated/prior/{i}':'a'*64 for i in range(90)})
  now=self.row();intent='b'*64;result='c'*64
  observation=dict(related_accounting=rows+[now],parent_accounting=now,
    journal_pins={**baseline['journal_pins'],m.ROOT+'/submission.intent.json':intent,m.ROOT+'/submission.result.json':result})
  self.assertEqual(m.accounting_extension(observation,baseline,'999',intent,result),(True,True))
  self.assertEqual(m.cost(observation['related_accounting']),(340,0))
  changed=copy.deepcopy(observation);changed['related_accounting'][0][5]='2'
  self.assertFalse(m.accounting_extension(changed,baseline,'999',intent,result)[0])
  changed=copy.deepcopy(observation);changed['journal_pins']['/fabricated/prior/0']='d'*64
  self.assertFalse(m.accounting_extension(changed,baseline,'999',intent,result)[1])
 def test_new_collector_matches_public_core_and_producer_paths_without_execution(self):
  pins=json.loads((ROOT/'interface-pins.json').read_text())
  for n,pin in pins.items():self.assertEqual(m.sha((ROOT/'interfaces'/n).read_bytes()),pin)
  core=ast.parse((ROOT/'interfaces/cpu-build_packet.py').read_bytes())
  outer=next(n.value for n in ast.walk(core) if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='outer' for t in n.targets))
  fields={k.arg for k in outer.keywords}
  tree=ast.parse((ROOT/'pull_terminal.py').read_bytes());compile(tree,'collector','exec');compile(m.REMOTE_OBSERVATION,'remote','exec')
  used={n.slice.value for n in ast.walk(tree) if isinstance(n,ast.Subscript) and isinstance(n.value,ast.Name) and n.value.id=='packet' and isinstance(n.slice,ast.Constant)}
  self.assertLessEqual(used,fields)
  remote=ast.parse(m.REMOTE_OBSERVATION)
  labels={n.value for n in ast.walk(remote) if isinstance(n,ast.Constant) and isinstance(n.value,str)}
  self.assertTrue({'launch','training','cpu','common','failed01'}<=labels)
  self.assertNotIn('stream_custody', {n.module for n in ast.walk(tree) if isinstance(n,ast.ImportFrom)})
  body=(ROOT/'pull_terminal.py').read_text()
  self.assertIn('worker/artifacts/cpu-phase/campaign-bundle.json',body)
  self.assertNotIn('cpu/worker/artifacts/campaign/bundle.json',body)
  self.assertEqual(m.ROOT,'/scratch/alpine/paco0228/ACE/results/ace_llm_intervention_scientific_campaign_cpu_20261108_01')
if __name__=='__main__':unittest.main(verbosity=2)
