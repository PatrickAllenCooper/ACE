"""One NEW producer-to-monitor path check; AST only, no target imports/calls."""
import ast, hashlib, json, unittest
from pathlib import Path
ROOT=Path(__file__).parent
class BundlePathRegression(unittest.TestCase):
 def test_bundle_marker_matches_frozen_phase_writer(self):
  pins=json.loads((ROOT/'producer-pins.json').read_text())
  trees={}
  for n,pin in pins.items():
   data=(ROOT/'producers'/n).read_bytes()
   self.assertEqual(hashlib.sha256(data).hexdigest(),pin)
   trees[n]=ast.parse(data)
  prod=trees['prepare_llm_intervention_scientific_campaign_cpu.py']
  phase=next(n for n in prod.body if isinstance(n,ast.FunctionDef) and n.name=='run_phase')
  self.assertTrue(any(isinstance(n,ast.Assign) and ast.unparse(n)=='out = loc[\'phase\']' for n in ast.walk(phase)))
  saves=[n.args[0] for n in ast.walk(phase) if isinstance(n,ast.Call) and isinstance(n.func,ast.Name) and n.func.id=='save' and n.args]
  bundle=next(n for n in saves if isinstance(n,ast.BinOp) and isinstance(n.left,ast.Name) and n.left.id=='out' and isinstance(n.right,ast.Constant) and n.right.value=='campaign-bundle.json')
  base=trees['prepare_llm_intervention_campaign_cpu.py']
  paths=next(n for n in base.body if isinstance(n,ast.FunctionDef) and n.name=='paths')
  artifacts=next(n.value for n in paths.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='artifacts' for t in n.targets))
  phase_expr=next(k.value for n in ast.walk(paths) if isinstance(n,ast.Call) and isinstance(n.func,ast.Name) and n.func.id=='dict' for k in n.keywords if k.arg=='phase')
  self.assertEqual(ast.unparse(artifacts),"out / 'worker/artifacts'")
  self.assertEqual(ast.unparse(phase_expr),"artifacts / 'cpu-phase'")
  expected='cpu/'+artifacts.right.value+'/'+phase_expr.right.value+'/'+bundle.right.value
  monitor=ast.parse((ROOT/'monitor_once.py').read_bytes())
  fragment=next(n.value for n in ast.walk(monitor) if isinstance(n,ast.Constant) and isinstance(n.value,str) and n.value.startswith('\nimport pathlib,hashlib,json,subprocess,datetime'))
  remote=ast.parse(fragment);compile(remote,'monitor-remote','exec')
  names=next(ast.literal_eval(n.value) for n in remote.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='paths' for t in n.targets))
  self.assertEqual(names.count(expected),1)
  self.assertNotIn('cpu/worker/artifacts/campaign/bundle.json',names)
if __name__=='__main__':unittest.main(verbosity=2)
