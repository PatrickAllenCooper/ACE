# CPU campaign monitor R1 correction — ready for independent delta review

Only executable-source change: monitor marker `cpu/worker/artifacts/campaign/bundle.json` → `cpu/worker/artifacts/cpu-phase/campaign-bundle.json`. Builder, launcher and argument map are byte-identical. Full predecessor tree, prior attempts and Godel initial review SHA94dee1c33ea357baac5d77d47f17e454e41340b2f52e510befecb6da497babae are preserved; original authoring untouched. Original full interface remains in predecessor/handoff.md; its monitor pin is superseded below.

One NEW focused AST regression passed once in delta01 from unrelated cwd /tmp: derives phase writer location from independently frozen scientific producer and inherited paths helper, checks corrected monitor includes it exactly once and excludes the obsolete path, and compiles only the embedded remote AST. No target code/import/call, scientific data/model, packet build, remote command, old test repetition or commit. Full stdout/stderr, source snapshots and exact costs retained. Wall0.0465385s, childCPU0.042706s, unittest0.014s. No test failure occurred.

Source pins:
- build_packet.py: `4f9aeefe929d89f70fd98a93d8368fbe1b150b4ef7189e2a7f258f306325e19e`
- launch_once.py: `d2b731024b9dbc567f5254fa6b9ba65875909a9309c4c0dec88c735cdc08cec0`
- monitor_once.py: `cb63691494e51fd200b1d40105794126fc7cd1986e7521a1d667836225fd0012`
- test_monitor_bundle_r1.py: `5c0aa54d0fdddc0d158081509f7ce80afa429522ff703c3a8113bae450e60d69`
- argument-map.json: `9a3af4fa80940cf866017d6233a3fb64e8c326a4a38f7453b93786ff11d68c46`

Test receipt SHA256 `9af1ae617602cb638ec2d3693d8bc3fa031a5b6117bb835e1219ab71816ce46f`. Exact one-line source diff: monitor-r1.diff. Independent Godel recheck remains required; no execution authorization.
