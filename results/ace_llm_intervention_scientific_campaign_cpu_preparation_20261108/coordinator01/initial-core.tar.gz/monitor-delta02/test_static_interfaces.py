"""New metadata-only compatibility checks; never call admit/main/make_packet."""
from pathlib import Path
import ast,hashlib,importlib.util,json,unittest
ROOT=Path(__file__).parent
spec=importlib.util.spec_from_file_location('new_cpu_campaign_authoring',ROOT/'build_packet.py')
b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
class StaticInterfaces(unittest.TestCase):
 def test_actual_freeze_closure_roster_resource_and_literal_interfaces(self):
  path=b.REPO/'results/ace_llm_intervention_scientific_contract_20261108/candidate03/scientific-freeze.json'
  data=path.read_bytes();self.assertEqual(b.sha(data),b.FIXED['freeze']);f=json.loads(data)
  cl=f['stage_closure']['stages']['CPUcampaign'];self.assertEqual((len(cl['source_names']),len(cl['input_source_files'])),(49,51))
  self.assertEqual(cl['entrypoint_sha256'],b.ENTRY_SHA)
  stage=next(s for s in f['stages'] if s['stage']=='cpu_campaign');self.assertEqual(stage['deadlines'],b.DEADLINES)
  self.assertTrue(all(stage[k]==v for k,v in b.RESOURCES.items()));self.assertEqual((f['numeric_internal_seconds'],f['numeric_timeout_seconds']),(50,55))
  service=(b.REPO/'scripts/research/llm_intervention_model_service.py').read_bytes()
  self.assertEqual(b.sha(service),cl['input_source_files']['llm_intervention_model_service.py'])
  self.assertTrue(b.literal(service,'SOURCE_NAMES')<=set(cl['source_names']))
  self.assertEqual(b.literal(service,'RUNTIME'),f['runtime']);self.assertIsInstance(b.literal(service,'RECIPE'),dict)
  diagnostic=(b.REPO/'scripts/research/qualify_llm_intervention_runtime_metadata.py').read_bytes()
  self.assertEqual(b.sha(diagnostic),cl['input_source_files']['qualify_llm_intervention_runtime_metadata.py'])
  self.assertIsInstance(b.literal(diagnostic,'BOOTSTRAP'),str)
  entry=(ROOT/'predecessors/cpu-entry.py').read_bytes();self.assertEqual(b.sha(entry),b.ENTRY_SHA)
  self.assertEqual(len(b.literal(entry,'PACKET_KEYS')),26)
  self.assertEqual(len(b.ARTIFACTS)+24+len(cl['input_source_files'])+7+6,95)
 def test_only_new_coordinator_and_remote_source_syntax(self):
  for name in ('build_packet.py','launch_once.py','monitor_once.py'):
   tree=ast.parse((ROOT/name).read_bytes());compile(tree,name,'exec')
   for node in ast.walk(tree):
    if isinstance(node,ast.Constant) and isinstance(node.value,str) and node.value.lstrip().startswith(('import pathlib,','need(root.parent','need(not os.path.lexists(root/')):
     compile(node.value,name+':remote','exec')
 def test_current_owned_worker_monitor_marker_paths(self):
  tree=ast.parse((ROOT/'monitor_once.py').read_bytes())
  fragments=[n.value for n in ast.walk(tree) if isinstance(n,ast.Constant) and isinstance(n.value,str) and n.value.startswith('\nimport pathlib,hashlib,json,subprocess,datetime')]
  self.assertEqual(len(fragments),1);remote=ast.parse(fragments[0]);compile(remote,'new-monitor-remote','exec')
  paths=next(ast.literal_eval(n.value) for n in remote.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='paths' for t in n.targets))
  helper=(b.REPO/'scripts/research/llm_intervention_cpu_owned_supervision.py').read_bytes()
  strings={n.value for n in ast.walk(ast.parse(helper)) if isinstance(n,ast.Constant) and isinstance(n.value,str)}
  for name in ('worker.cleanup.json','worker.resources.json','worker.started.json'):
   self.assertIn(name,strings);self.assertIn('cpu/'+name,paths)
  self.assertNotIn('cpu/session/cleanup.json',paths)
 def test_unknown_or_duplicate_allocation_rejects_and_failed_charges_remain(self):
  rows=[['1','ace_llm_failure','FAILED','1:0','2','126','ucb736_asc2','cpu=2,mem=7680M,node=1'],
   ['2','ace_llm_training','COMPLETED','0:0','4','10','ucb736_asc2','cpu=4,node=1,gres/gpu=1,gres/gpu:a100_3g.20gb=1']]
  self.assertEqual(b.gpu_cost(rows),(292,10))
  for value in ('','cpu=4,gres/gpu=1,gres/gpu=2','cpu=4,gres/gpu=2,gres/gpu:a100_3g.20gb=1'):
   bad=[list(rows[-1])];bad[0][-1]=value
   with self.subTest(value=value),self.assertRaises(ValueError):b.gpu_cost(bad)
if __name__=='__main__':unittest.main(verbosity=2)
