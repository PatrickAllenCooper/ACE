# Scientific CPU campaign wrapper — source/test handoff

Only new wrapper and focused test authored for this task. No closed source/helper/test/review edits, no commits, remote actions, scientific draws/responses, tokenizer/model calls or actual ranker fit. Parent-owned concurrent changes untouched. This source is for independent review; no scientific execution or resource admission is implied.

- `scripts/research/prepare_llm_intervention_scientific_campaign_cpu.py` SHA256 `6fb403616a58a11b15b33a8d10649280cc736e48a2c3ee07791dec9d13d5395d`
- `scripts/research/test_prepare_llm_intervention_scientific_campaign_cpu.py` SHA256 `82b703d95922af426ebdce6c62a4a6484c525b38badebd540290e7c4215934a5`

Ten distinct new stdlib tests passed: attempt01 eight tests; attempt02-new-design-check one added saved-bundle check; attempt03-new-packet-interface one added finalizer-interface check. All originals, stdout/stderr, resource reports, source-before/after and pins retained. No failing test attempt occurred. No source changed during any run. Earlier eight method ASTs are unchanged. Total wall 0.683512666s; child CPU 0.602550s; peak RSS 40,042,496 bytes on macOS. No old test method or completed new check was repeated.

The final source preserves both additions statically: the previously tested run_phase differs only by adding the compatibility success field failed_policies: []; the original accepted_inputs schema/phase/schedule controls remain unchanged. The new declaration-only packet_shape is individually tested; live authenticate uses it. Resource/source acquisition and real runtime/controller execution are not established by these mocked tests.

## API and output handoff

Stable exact packet/data/acceptance contract is copied into interface.md and available at `/tmp/ace-scientific-campaign-cpu-interface.md`; integration-map.md records the stage design. CLI is captured diagnostic BOOTSTRAP + independently pinned entry, --packet, --packet-sha256, --source-commit, --admission, --admission-sha256. No resource defaults authorize execution. Caller explicitly chooses2CPU/7680MiB/zeroGPU/acpu/cpu-normal/ucb736_asc2/no-requeue wall<=6000, deadlines, and numeric per-call limits. Implementation reuses old campaign supervise_child with explicit absolute deadlines and owned cleanup; no helper globals patched.

Public pure interfaces: packet_shape(packet,service,diagnostic); accepted_inputs(packet,data,lineage_api); service_contracts(root,packet,data,service,diagnostic,lineage,launch). authenticate(args) returns ctx containing root,p,data,service,cpu,diagnostic,lineage plus independently pinned packet/admission captures. validate_worker(ctx,args,stage,stage_pin,provenance) is parent saved-byte validation; args supplies the original absolute worker_deadline. Its exact CPU-only campaign membership applies before prospective GPU attempts. Later finalization uses independently accepted CPU custody subset, not rerunning that membership gate on a combined root.

Output uses old `<cpu_output>/worker/artifacts/{cpu-phase,campaign,numeric-calls}`. cpu-phase/campaign-bundle.json preserves the closed builder's full192-cell declaration; attempt-pins.json binds five CPU attempts across24 worlds/120 cells; no GPU attempts/private finalization. All3 service contracts retain exactly576 requests. CPU phase terminal status cpu_phase_complete, failed_policies[], numeric_training_updates160+D; D1..128 comes from original accepted numerical plan. CPU acceptance is external only, with agreed exact old key roster and new scientific schema/status in interface.md.

## What the new tests establish

Pure expected-lineage and agreed exact CPU acceptance schema/flags/byte-semantic pins; full original24 descriptor membership; fixed96 numeric bindings and final-only ranker export; matched fit called once before complete bundle/response initialization; all192 declared cells then only5 CPU policies; preserved bind/fit/policy failures with no next-policy/GPU rescue; explicit resource/allocation/no-accelerator rejection; saved task/learner/namespace/stratum/command mutations rejected even after rebinding output hashes; pure finalizer packet shape. Static import/AST checks cover project closure, no tokenizer/world-generation/finalization invocation, one unchanged ranker.fit call and reused supervise-before-validation ordering.

Tests use short fabricated raw records, descriptors, opaque adapter/ranker bytes, metadata and API doubles. They do not invoke closed assembler, WorldDescriptor, ranker.fit, campaign mechanics, real numerical CLI, staged runtime, scheduler or process supervisor. The unchanged original proposal is read only to obtain fixed public roster/design/namespace declarations. No new IDs are drawn.

## Remaining limits/review

Full accepted scientific GPU training, complete accepted CPU numerical plan, original accepted development realization, combined freeze and separate namespace/source/runtime/allocation admission must exist before actual execution. Full contract predating first scientific draw is an explicit independently pinned caller attestation; the wrapper cannot manufacture that historical fact. Preflight checks do not certify runtime duration or downstream adaptive prompt capacity. No scientific utility or GPU/development acceptance flags are promoted.

Private descriptors remain trusted-controller inputs; numeric child authentication reads only captured source and public binding data, while policy stdin is the public envelope. This is the existing trusted-process boundary, not an OS sandbox against malicious same-user code. Source capture/runtime/admission must supply that trust. All ranker plans/exports are pinned; fit uses unchanged exact numerical recipe and exposure, without tuning on development outcomes.

Safety bounds: each captured JSON<=256MiB, each input adapter<=16MiB, total captured input<=512MiB checked incrementally; complete saved custody<=262144 files/8GiB. These are bounded readers, not measured actual resource guarantees. Real supervisor/numerical-process/runtime/custody acceptance remains open. Unused original helper modules retained in captured source closure are imported for existing runtime observation, never invoked to generate worlds or load models.
