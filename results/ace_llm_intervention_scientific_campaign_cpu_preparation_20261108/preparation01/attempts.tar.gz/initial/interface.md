# Stable integration surface: scientific campaign CPU (2026-11-08)

Source/test work remains in progress; source pins follow tested handoff. No runtime/resource authorization. No scientific execution performed. CPU output layout intentionally follows prepare_llm_intervention_campaign_cpu.py. GPU phase belongs to parent, not this wrapper.

## Entry and caller authority

New source: scripts/research/prepare_llm_intervention_scientific_campaign_cpu.py.
CLI under caller-pinned diagnostic BOOTSTRAP:
`--packet <flat>/packet.json --packet-sha256 <bytepin> --source-commit <fullcommit> --admission <flat>/admission.json --admission-sha256 <bytepin>`.
No caller-selected executable/entrypoints, no globals patched. Parent owns combined contract before first scientific draw, source/runtime/allocation/freeze/namespace admission and eventual acceptance. Exact caller resources: account ucb736_asc2, partition acpu, qos cpu-normal, cpus2, memory_mib7680, gpus0,requeuefalse, supplied wall_seconds<=6000. Supplied deadlines startup<work<hard<wall with >=10s work-to-hard margin. Numeric timeout/internal-work seconds explicit, internal<timeout<=60. No 900s default.

Packet keys (exact): schema,scope,source_commit,files,source_names,cpu_output,archive,manifest,runtime_source,runtime,model_directory,model_files,resources,deadlines,numeric_timeout_seconds,numeric_work_seconds,protocol_source_pins,freeze_sha256,namespace_admission_sha256,world_pins,expected_training,numerical_plan_sha256,persistent_specs,services,service_identity_pins,outer_provenance_receipt_sha256. schema=ace-scientific-campaign-cpu-v1;scope=development. Exact source/helper roster is exported INPUT_NAMES/SOURCE_NAMES in source. Source closure is old campaign SOURCE_NAMES plus new wrapper, scientific lineage and scientific assembler; helper pins remain independent constants. Inputs are flat, original bytes; descriptors remain private controller inputs. model_files is known seven-file provenance, model_directory a future service path; no LLM weight file/tokenizer is required or loaded by this CPU stage.

Admission exact fields: schema=ace-scientific-campaign-cpu-v1/admission, packet_sha256,source_commit,freeze_sha256,namespace_admission_sha256,stage=matched_ranker_and_development_cpu,output=cpu_output,resources,deadlines; full_contract_frozen_before_first_scientific_draw/source_runtime_scheduler_qualified/namespace_owned/accounting_admitted/independent_acceptances_verified all true; retry_allowed false. Independent pinned attestation; not self-created by wrapper.

## Data files

proposal.json (unchanged original byte/semantic pins); scientific-freeze.json; realization-terminal.json; realization-acceptance.json; descriptor-000.json through descriptor-023.json (original terminal entries32..55); gpu-training-acceptance.json; cpu-preparation-acceptance.json; prepared.json (complete CPU LLM preparation); numerical-plan.json (original accepted numerical plan); engine-terminal.json; sft.checkpoint.json,final.checkpoint.json; sft.adapter.pt,final.adapter.pt (opaque byte hashing only); numeric-bindings.json (exact closed-builder 96-row output); frozen_llm.freeze.json,sft_llm.freeze.json,dpo_llm.freeze.json and corresponding .launch.json files.

expected_training is unchanged scientific lineage helper's exact separately frozen expected map. Its cpu_preparation_acceptance_sha256 binds the supplied original CPU acceptance. GPU acceptance is separately pinned by files map. Service roles use original checkpoint receipt SHA as training_receipt_sha256, not outer acceptance SHA.

CPU acceptance EXACT fields agreed with Kuhn:
- schema=ace-scientific-training-preparation-acceptance-v1,status=accepted,scope=policy_train,required_findings integer0;
- job_id positive decimal string,cpu_packet_sha256,prepared_sha256,plan_sha256,freeze_sha256,namespace_admission_sha256;
- complete_custody_verified,runtime_qualified_for_this_cpu_execution,owned_process_cleanup_verified: true;
- training_execution_qualified,scientific_qualified: false;
- numerical_plan_file_sha256,numerical_plan_sha256,exposure_sha256.

prepared/plan/exposure bind original CPU output and scientific GPU lineage; numerical plan byte+semantic pins bind same raw records, exact exposure, checkpoint indices and CPU packet outer provenance. Freeze/namespace ties match this campaign contract. CPU job is identified by the independently pinned acceptance; CPU packet hash also equals both matched plans' original outer provenance. GPU successor need not load numerical data.

Realization acceptance fields consumed: status accepted,required_findings integer0,complete_custody_verified true,realization_terminal_sha256,freeze_sha256,namespace_admission_sha256. Its original full56 terminal proves exact membership; only24 development payloads are staged, with distinct byte/descriptor-semantic pins. No replacement/draw path.

## Prospective services and numeric commands

Three complete service freezes retain development scope and frozen/sft/dpo treatments; adapters are training_scope policy_train. Each freeze and service setting has max_requests576. Service identity pins are supplied independently. Persistent specs bind unchanged launch source+contracts. Other service limits are explicit caller-owned freeze values, validated by original model service. CPU phase does not execute these commands. Parent's separate new GPU phase owns reserve/work/final offsets and actual remaining GPU admission.

96 numeric bindings come from closed numeric_policy_bindings using original proposal's arm namespaces, without aliases. Five CPU policy IDs: uniform_random,menu_coverage,local_information,target_risk,learned_ranker. Ranker command fixed seed109/draws32 and only final dpo.ranker.pt export. Wrapper adds a public --world-id argument to each captured numeric subprocess prefix for unambiguous call custody; original policy CLI sees only unchanged suffix. Policy stdin contains only original public envelope, never descriptors.

## Immutable CPU handoff

`<cpu_output>/stage.json`, allocation/start/worker.started/worker.cleanup/worker.resources and supervisor.json.
`<cpu_output>/worker/artifacts/`: runtime*, authenticated-before/after, numeric-prefixes.json, terminal.json, outer phase event journals; subdirectories cpu-phase/,campaign/,numeric-calls/.

`cpu-phase/`: training-lineage.json,numeric-training-plan.json (same accepted plan),ranker/ complete original training/checkpoints/exports; campaign-bundle.json; per-policy attempt receipts,attempt-pins.json,terminal.json. The ranker fits exactly once,160SFT+D (D1..128),same exposure; no fit selection from development outcomes.

`campaign-bundle.json` retains closed assembler output unchanged: campaign,campaign_sha256,source_plan_pins and original protocol/world/service bindings. All24x8=192 cells are frozen before campaign.initialize_campaign/run_policy. campaign/ contains original campaign root plus policy-00..policy-04 only (120 CPU cells); no GPU attempts/private finalization. Each successful attempt pin is for original campaign policy attempt bytes. Stop/actions/failures remain original charged journal evidence. Partial/failed CPU policy prevents success and next policy; no resume/retry/replacement.

GPU successor should consume unchanged campaign bundle/root +five attempt pins after independently accepting original CPU source/runtime/cleanup/all-input/all-output custody. Validation helpers in wrapper: authenticate(args)->context; validate_worker(ctx,args,stage,stage_pin,provenance)->saved-byte report (implementation completing); no heavy runtime in parent validator. Its signature is intended stable. Caller may use ctx['root'],ctx['p'],ctx['data'],ctx['service'],ctx['cpu'],ctx['diagnostic'],ctx['lineage'].

No private finalization in CPU wrapper; finalizer remains a later trusted-controller stage after all eight arms and their independent custody. Whole-stage success and report do not establish scientific utility or GPU execution acceptance.

## Finalizer/GPU outer alignment (stable tested source)

`packet_shape(packet, service, diagnostic)` is now implemented as a pure declaration gate (3 arguments). It checks exact source/helper/protocol/input rosters, original proposal, fixed runtime/model, full source commit, exact24 development ID pins, combined freeze and independently expected prepared/CPU-acceptance pins, explicit resources/deadlines. The finalizer must additionally bind its independently expected freeze/namespace to packet values and use original byte custody/acceptance; shape validation alone does not establish external authority. `accepted_inputs(packet,data,lineage_api)` is the separate pure captured-byte lineage/CPU numerical-plan/realization gate. `service_contracts(root,packet,data,service,diagnostic,lineage,launch)` verifies all three future service freezes/launches. `authenticate(args)` combines these gates for live CPU startup.

External campaign CPU acceptance retains EXACT original keys:
`schema,status,cpu_packet_sha256,job_id,allocation,cpu_output,campaign_root,cpu_output_files,cpu_output_excluded_directory,campaign_files,bundle_path,bundle_sha256,phase_terminal_path,phase_terminal_sha256,attempt_pins,scientific_qualified`.
Use schema `ace-scientific-campaign-cpu-acceptance-v1`, status `development_cpu_phase_accepted`, scientific_qualified false. It is produced only by independent review of actual accepted execution, never by this wrapper. cpu_output_excluded_directory remains `worker/artifacts/campaign`; original CPU campaign inventory is a subset of later combined custody, with additions only policy-05..07. cpu phase status remains `cpu_phase_complete`, success has `failed_policies: []`, numeric_training_updates is160+D derived from accepted numerical plan. GPU attempts cannot be present when live CPU validate_worker runs; later finalizer uses independently accepted CPU inventory/subset rules rather than rerunning the pre-GPU membership gate against the augmented root.

Wrapper supervisor summary is not this external acceptance. All metadata/terminal paths remain as above. No actual tokenization/model/ranker fitting/world/response/remote execution or old tests occurred during implementation. Source/testing handoff: /Users/pat/.codex/tmp/ace-scientific-campaign-cpu-tests-mrhwe7me/HANDOFF.md.
