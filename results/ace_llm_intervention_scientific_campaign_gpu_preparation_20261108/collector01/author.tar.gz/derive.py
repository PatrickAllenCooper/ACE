from pathlib import Path
p=Path(__file__).resolve().parent
s=(p/'predecessors/training-pull_terminal.py').read_text()
s=s.replace('scientific GPUtrain terminal custody, never training/scientific acceptance.','scientific GPU campaign terminal custody, never runtime/scientific acceptance.')
s=s.replace('import math\n','import math\nimport types\nimport shlex\n')
s=s.replace('scientific_training_gpu_20261108','scientific_campaign_gpu_20261108').replace('scientific-training-gpu-terminal','scientific-campaign-gpu-terminal').replace('scientific-training-gpu-20261108','scientific-campaign-gpu-20261108')
s=s.replace("CPU_ROOT='/scratch/alpine/paco0228/ACE/results/ace_llm_intervention_scientific_tokenization_20261108_01'", "CPU_ROOT='/scratch/alpine/paco0228/ACE/results/ace_llm_intervention_scientific_campaign_cpu_20261108_01'\nTRAIN_ROOT='/scratch/alpine/paco0228/ACE/results/ace_llm_intervention_scientific_training_gpu_20261108_01'\nTOKEN_ROOT='/scratch/alpine/paco0228/ACE/results/ace_llm_intervention_scientific_tokenization_20261108_01'")
s=s.replace("HELPER='/Users/pat/.codex/skills/curc-access/scripts/curc-access.sh'", "HELPER='/Users/pat/.codex/skills/curc-access/scripts/curc-access.sh'\nBUILDER_SHA='67f9b5fe1e681b73ab04c7948123e19ffa6ffdb808cc536b4b44cc40da47fc9e'\nPOLICIES=('frozen_llm','sft_llm','dpo_llm')\nUPSTREAM_ROOTS=dict(cpu=CPU_ROOT,training=TRAIN_ROOT,token=TOKEN_ROOT,common=COMMON_ROOT,failed01=FAILED_ROOT)")
s=s.replace("cpu_present=Path(CPU_ROOT).exists(),common_present=", "cpu_present=Path(CPU_ROOT).exists(),training_present=Path(TRAIN_ROOT).exists(),token_present=Path(TOKEN_ROOT).exists(),common_present=")
s=s.replace("('cpu',Path(CPU_ROOT),v['cpu_present']),", "('cpu',Path(CPU_ROOT),v['cpu_present']),('training',Path(TRAIN_ROOT),v['training_present']),('token',Path(TOKEN_ROOT),v['token_present']),")
s=s.replace('# Explicit training-only paths; never enumerate the realization root or read world032..055.', '# Explicit accepted upstream byte pins; never decode descriptors or outcomes.')
s=s.replace("wall_seconds=2700,gpus=1,gpu_type='a100_3g.20gb')", "wall_seconds=2880,gpus=1,gpu_type='a100_3g.20gb',requeue=False)")
s=s.replace('DEADLINES=dict(startup=240,worker=2620,soft=2630,cleanup=2645,hard=2670,progress=180,telemetry=90)', 'LIMITS=dict(session_reserve_seconds=600,session_cap_seconds=1200,work_seconds=2820,final_seconds=2860)')
s=s.replace("'gpu-testing','45'", "'gpu-testing','48'").replace("'launch/training/allocation.json'", "'launch/gpu/allocation.json'").replace("'ace_llm_scientific_train01'", "'ace_llm_scientific_campaign_gpu01'").replace('elapsed<=2700','elapsed<=2880')
start=s.index('def public_gpu_evidence(');end=s.index('def accounting_extension(',start)
s=s[:start]+(p/'public_evidence.txt').read_text()+s[end:]
s=s.replace('len(prior)==43','len(prior)==45').replace("len(observation['related_accounting'])==44", "len(observation['related_accounting'])==46").replace("len(baseline['journal_pins'])==88 and len(journals)==90", "len(baseline['journal_pins'])==92 and len(journals)==94")
s=s.replace("'packet-review','packet-review-sha256')", "'packet-review','packet-review-sha256','stream-helper-repository-path','stream-helper-review-repository-path')")
s=s.replace("'ace-scientific-training-gpu-launch-v1'", "'ace-scientific-campaign-gpu-launch-v1'")
start=s.index("    baseline_pin=pins['baseline.json']");end=s.index('    locks=[];claimed=[];',start)
s=s[:start]+(p/'metadata_gate.txt').read_text()+s[end:]
s=s.replace('FAILED_ROOT=FAILED_ROOT,CPU_ROOT=CPU_ROOT)', 'FAILED_ROOT=FAILED_ROOT,CPU_ROOT=CPU_ROOT,TRAIN_ROOT=TRAIN_ROOT,TOKEN_ROOT=TOKEN_ROOT)')
s=s.replace("for sub in ('remote','coordinator','namespaces')", "for sub in ('coordinator','namespaces')")
s=s.replace("write(dest/'pull_terminal.py',Path(__file__).read_bytes())", "write(dest/'pull_terminal.py',Path(__file__).read_bytes())\n            write(dest/'stream_custody.py',helper_source);write(dest/'stream_custody_review.md',helper_review)")
s=s.replace("cpu_custody_inventory_sha256=a.cpu_custody_inventory_sha256,\n            packet_commit", "cpu_custody_inventory_sha256=a.cpu_custody_inventory_sha256,\n            stream_helper_sha256=STREAM_HELPER_SHA,stream_helper_review_sha256=STREAM_REVIEW_SHA,\n            stream_helper_repository_path=a.stream_helper_repository_path,stream_helper_review_repository_path=a.stream_helper_review_repository_path,\n            packet_commit")
start=s.index('        for parent in (BASE,LOCAL.parent):');end=s.index("        (LOCAL/'upstream-cpu-custody').mkdir",start)
s=s[:start]+'''        helper=load_stream_helper(helper_source)
        actual,after=stream_transfer(before,observe=observe,save=save,helper=helper,helper_source=helper_source,
            external=EXT,local=LOCAL,copy_file=copy_file,
            coordinator_bytes=sum(v['bytes'] for info in coordinator.values() for v in info['files'].values())
                +sum(v['bytes'] for v in cpu_custody_before['files'].values()))
'''+s[end:]
s=s.replace("for sub in ('remote','coordinator','upstream-cpu-custody'):","for sub in ('coordinator','upstream-cpu-custody'):",1)
s=s.replace('exact43 prior plus current44th','exact45 prior plus current46th').replace('exact88 prior plus current90','exact92 prior plus current94')
s=s.replace("EXT/'remote/launch/training'", "EXT/'remote/launch/gpu'")
start=s.index("        markers={n:actual['files'].get('launch/training/'");end=s.index("        reported=public_gpu_evidence",start)
s=s[:start]+'''        marker_names=['terminal.json','failure.json','controller/phase/terminal.json','controller/phase/failure.json',
            'controller/phase/cleanup-hold-intent.json','controller/failure.json']
        for policy in POLICIES:
            marker_names += [f'controller/phase/{policy}/summary.json',f'controller/phase/{policy}/fallback-cleanup.json',
                f'controller/phase/{policy}/post-exit-gpu.json']
            marker_names += [f'services/{policy}/{sub}/{name}.json' for sub in ('worker','launch') for name in ('terminal','failure')]
        markers={n:actual['files'].get('launch/gpu/'+n) for n in marker_names}
        complete_markers=all(markers[n] is not None for n in ('terminal.json','controller/phase/terminal.json'))
'''+s[end:]
s=s.replace("schema='ace-scientific-training-gpu-terminal-custody-v1'", "schema='ace-scientific-campaign-gpu-terminal-custody-v1'")
s=s.replace("output_root=ROOT+'/training'", "output_root=ROOT+'/gpu'")
s=s.replace("cpu_custody_inventory_sha256=a.cpu_custody_inventory_sha256,collection_acceptance_sha256", "cpu_custody_inventory_sha256=a.cpu_custody_inventory_sha256,\n            training_acceptance_sha256=pins['training-acceptance.json'],token_acceptance_sha256=pins['token-acceptance.json'],\n            collection_acceptance_sha256")
s=s.replace('adapter_tensors_decoded=False,scientific_qualified=False,training_execution_qualified=False', 'adapter_tensors_decoded=False,scientific_qualified=False,runtime_qualified=False,training_execution_qualified=False')
s=s.replace("for sub in ('remote','coordinator','upstream-cpu-custody'):","for sub in ('remote','coordinator','upstream-cpu-custody','stream-attempt'):")
# Use the reviewed helper integration structure, expanded only for this complete campaign upstream roster.
t=(p/'predecessors/token-stream-pull_terminal.py').read_text();t=t[t.index("STREAM_HELPER_SHA =") if 'STREAM_HELPER_SHA =' in t else t.index('STREAM_HELPER_SHA='):t.index('def main():')]
t=t.replace("('launch',ROOT,'root_present'),('common',COMMON_ROOT,'common_present')", "('launch',ROOT,'root_present'),('cpu',CPU_ROOT,'cpu_present'),('training',TRAIN_ROOT,'training_present'),('token',TOKEN_ROOT,'token_present'),('common',COMMON_ROOT,'common_present')")
t=t.replace("and after['common_present']==before['common_present']", "and all(after[k]==before[k] for k in ('cpu_present','training_present','token_present'))\n         and after['common_present']==before['common_present']")
t=t.replace("str(LAUNCH/'stream_custody.py')", "'<independently-committed-stream-custody>'")
s=s.replace('def main():',t+'def main():',1)
(p/'pull_terminal.py').write_text(s)
