"""Complete scientific GPU campaign terminal custody, never runtime/scientific acceptance.

Standalone sidecar. Requires independent current job/outer packet/result pins.
Copies the whole root and both separate namespace claims, retains all terminal
failures/partial outputs, and performs a second remote inventory/readback.
Only allowlisted public telemetry scalars are decoded after custody; score values and tensors stay opaque.
"""
from pathlib import Path
import argparse
import datetime
import fcntl
import hashlib
import json
import os
import re
import shutil
import stat
import subprocess
import time
import math
import types
import shlex

REPO=Path('/Users/pat/code/ACE')
BASE=Path('/Users/pat/ACE_Study_Results/2026-10-peter-baseline')
LAUNCH=REPO/'results/ace_llm_intervention_scientific_campaign_gpu_20261108/launch01'
LAUNCH_EXT=BASE/'ACE-LLM-intervention-scientific-campaign-gpu-20261108-01'
LOCAL=LAUNCH.parent/'terminal01'
EXT=BASE/'ACE-LLM-intervention-scientific-campaign-gpu-terminal-20261108-01'
ROOT='/scratch/alpine/paco0228/ACE/results/ace_llm_intervention_scientific_campaign_gpu_20261108_01'
CPU_ROOT='/scratch/alpine/paco0228/ACE/results/ace_llm_intervention_scientific_campaign_cpu_20261108_01'
TRAIN_ROOT='/scratch/alpine/paco0228/ACE/results/ace_llm_intervention_scientific_training_gpu_20261108_01'
TOKEN_ROOT='/scratch/alpine/paco0228/ACE/results/ace_llm_intervention_scientific_tokenization_20261108_01'
COMMON_ROOT='/scratch/alpine/paco0228/ACE/results/ace_llm_intervention_scientific_collection_20261108_02'
FAILED_ROOT='/scratch/alpine/paco0228/ACE/results/ace_llm_intervention_scientific_collection_20261108_01'
REALIZATION_ROOT='/scratch/alpine/paco0228/ACE/results/ace_llm_intervention_scientific_realization_20261108_02'
LOCAL_NAMESPACE=BASE/'ACE-LLM-intervention-scientific-screen-20261107.namespace-recovery02.json'
REMOTE_NAMESPACE=str(Path(ROOT).parent/'.ace-scientific-screen-20261107.namespace-recovery02.json')
OLD_LOCAL_NAMESPACE=BASE/'ACE-LLM-intervention-scientific-screen-20261107.namespace.json'
OLD_REMOTE_NAMESPACE=str(Path(ROOT).parent/'.ace-scientific-screen-20261107.namespace.json')
OLD_CLAIM_SHA='58033e812390731ad08c83b7236e6e47893de3a3488cf4602d5c42809a51fa29'
HELPER='/Users/pat/.codex/skills/curc-access/scripts/curc-access.sh'
BUILDER_SHA='67f9b5fe1e681b73ab04c7948123e19ffa6ffdb808cc536b4b44cc40da47fc9e'
POLICIES=('frozen_llm','sft_llm','dpo_llm')
UPSTREAM_ROOTS=dict(cpu=CPU_ROOT,training=TRAIN_ROOT,token=TOKEN_ROOT,common=COMMON_ROOT,failed01=FAILED_ROOT)
TERMINAL={'COMPLETED','FAILED','CANCELLED','TIMEOUT','OUT_OF_MEMORY','NODE_FAIL',
          'PREEMPTED','BOOT_FAIL','DEADLINE','REVOKED'}


def need(ok,message):
    if not ok:raise ValueError(message)


def sha(data):return hashlib.sha256(data).hexdigest()
def raw(value):return (json.dumps(value,indent=2,sort_keys=True,allow_nan=False)+'\n').encode()
def utc():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def pin(value):return type(value) is str and re.fullmatch('[0-9a-f]{64}',value) is not None


def decode(data):
    def pairs(items):
        result={}
        for k,v in items:
            need(k not in result,'duplicate metadata key');result[k]=v
        return result
    def bad(value):raise ValueError('nonfinite metadata: '+value)
    return json.loads(data,object_pairs_hook=pairs,parse_constant=bad)


def fingerprint(path,*,sole_link=False):
    path=Path(path)
    need(not path.is_symlink(),'symlink custody forbidden: '+str(path))
    with os.fdopen(os.open(path,os.O_RDONLY|os.O_NOFOLLOW|os.O_NONBLOCK),'rb') as f:
        before=os.fstat(f.fileno())
        need(stat.S_ISREG(before.st_mode) and (not sole_link or before.st_nlink==1),'regular independent custody file required')
        digest=hashlib.sha256()
        for block in iter(lambda:f.read(1024**2),b''):digest.update(block)
        after=os.fstat(f.fileno())
    identity=lambda s:(s.st_dev,s.st_ino,s.st_size,s.st_mtime_ns,s.st_ctime_ns,s.st_nlink)
    need(identity(before)==identity(after)==identity(path.lstat()),'file changed during inventory')
    return dict(bytes=after.st_size,sha256=digest.hexdigest())


def read_metadata(path,expected=None):
    meta=fingerprint(path,sole_link=True);need(meta['bytes']<=32*1024**2,'bounded coordinator metadata required')
    data=Path(path).read_bytes()
    need(sha(data)==meta['sha256'],'metadata changed during read')
    if expected is not None:need(pin(expected) and sha(data)==expected,'independent pin differs: '+str(path))
    return data


def inventory(root):
    root=Path(root);need(root.is_dir() and not root.is_symlink(),'ordinary custody directory required')
    files={};directories=[]
    for path in sorted(root.rglob('*')):
        need(not path.is_symlink(),'custody symlink forbidden')
        name=path.relative_to(root).as_posix()
        if path.is_dir():directories.append(name)
        else:files[name]=fingerprint(path,sole_link=True)
    return dict(files=files,directories=directories)


def write(path,data):
    with Path(path).open('xb') as f:f.write(data);f.flush();os.fsync(f.fileno())


def normalize(rows):
    result=[]
    for row in rows:
        need(len(row)>=8 and not any(row[8:]) and row[0].isdigit() and row[4].isdigit() and row[5].isdigit(),
             'malformed allocation accounting row')
        pairs=[part.split('=',1) for part in row[7].split(',') if part]
        need(all(len(p)==2 for p in pairs) and len({p[0] for p in pairs})==len(pairs),'malformed allocation TRES')
        result.append([row[0],row[1].strip(),row[2].strip(),row[3].strip(),int(row[4]),int(row[5]),row[6].strip(),sorted(pairs)])
    need(len({r[0] for r in result})==len(result),'duplicate historical job')
    return sorted(result,key=lambda r:int(r[0]))


REMOTE_OBSERVATION=r'''
from pathlib import Path
import subprocess,hashlib,json,datetime,stat,os
root=Path(ROOT);namespace=Path(NAMESPACE);original_namespace=Path(OLD_NAMESPACE)
def need(ok,message):
 if not ok:raise ValueError(message)
def fingerprint(path):
 need(not path.is_symlink(),'remote symlink forbidden')
 with os.fdopen(os.open(path,os.O_RDONLY|os.O_NOFOLLOW|os.O_NONBLOCK),'rb') as f:
  before=os.fstat(f.fileno());need(stat.S_ISREG(before.st_mode),'nonregular remote file')
  h=hashlib.sha256()
  for block in iter(lambda:f.read(1024**2),b''):h.update(block)
  after=os.fstat(f.fileno())
 identity=lambda s:(s.st_dev,s.st_ino,s.st_size,s.st_mtime_ns,s.st_ctime_ns,s.st_nlink)
 need(identity(before)==identity(after)==identity(path.lstat()),'remote file changed during capture')
 return dict(bytes=after.st_size,sha256=h.hexdigest()),after
v=dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),results={},files={},directories=[],
       root_present=root.exists(),cpu_present=Path(CPU_ROOT).exists(),training_present=Path(TRAIN_ROOT).exists(),token_present=Path(TOKEN_ROOT).exists(),common_present=Path(COMMON_ROOT).exists(),failed_present=Path(FAILED_ROOT).exists(),namespace_present=os.path.lexists(namespace),original_hardlink_groups=[],
       original_namespace_present=os.path.lexists(original_namespace),upstream_pins={},upstream_errors={})
commands={
 'related_accounting':['sacct','-X','-u','paco0228','-S','2026-11-02','--format',
   'JobIDRaw,JobName%80,State,ExitCode,AllocCPUS,ElapsedRaw,Account,AllocTRES%180','-n','-P'],
 'steps':['sacct','-j',JOB,'--format',
   'JobIDRaw,JobName%80,State,ExitCode,AllocCPUS,ElapsedRaw,Account,AllocTRES%180,MaxRSS,TotalCPU','-n','-P'],
 'details':['sacct','-X','-j',JOB,'--format','JobIDRaw,Partition,QOS,TimelimitRaw,ReqTRES%180,User','-n','-P'],
 'queue':['squeue','-u','paco0228','-h','-o','%i|%j|%T|%R|%a'],
 'job':['scontrol','show','job',JOB,'-o']}
for name,command in commands.items():
 try:
  p=subprocess.run(command,capture_output=True,text=True,timeout=20)
  v['results'][name]=dict(command=command,returncode=p.returncode,stdout=p.stdout,stderr=p.stderr)
 except subprocess.TimeoutExpired as exc:
  txt=lambda x:x.decode(errors='replace') if isinstance(x,bytes) else x
  v['results'][name]=dict(command=command,returncode=None,timeout=True,stdout=txt(exc.stdout),stderr=txt(exc.stderr))
try:
 need(v['results']['related_accounting']['returncode']==0 and v['results']['queue']['returncode']==0,
      'scheduler observation unavailable')
 rows=[l.split('|') for l in v['results']['related_accounting']['stdout'].splitlines() if '|ace_llm' in l]
 selected=[r for r in rows if r[0]==JOB]
 need(len(selected)==1 and selected[0][2].split()[0] in TERMINAL,'requested job not conclusively terminal')
 queue=[l.split('|') for l in v['results']['queue']['stdout'].splitlines() if l.strip()]
 need(all(len(r)==5 and r[0]!=JOB and not r[1].lower().startswith('ace') for r in queue),'current/related ACE job active')
 v['parent_accounting']=selected[0];v['related_accounting']=rows;v['terminal_gate']=True
 links={}
 for label,tree,present in (('launch',root,v['root_present']),('cpu',Path(CPU_ROOT),v['cpu_present']),('training',Path(TRAIN_ROOT),v['training_present']),('token',Path(TOKEN_ROOT),v['token_present']),('common',Path(COMMON_ROOT),v['common_present']),('failed01',Path(FAILED_ROOT),v['failed_present'])):
  if not present:continue
  need(tree.is_dir() and tree==tree.resolve(),'ordinary remote root required')
  v['directories'].append(label)
  for path in sorted(tree.rglob('*')):
   need(not path.is_symlink(),'remote tree symlink forbidden')
   name=label+'/'+path.relative_to(tree).as_posix()
   if path.is_dir():v['directories'].append(name);continue
   info,s=fingerprint(path);v['files'][name]=info
   if s.st_nlink>1:links.setdefault((s.st_dev,s.st_ino,s.st_nlink),[]).append(name)
 for name,path,present in (('namespace.json',namespace,v['namespace_present']),
                           ('original-namespace.json',original_namespace,v['original_namespace_present'])):
  if not present:continue
  need(path.parent==path.parent.resolve(),'registry parent alias')
  info,s=fingerprint(path);v['files'][name]=info
  if s.st_nlink>1:links.setdefault((s.st_dev,s.st_ino,s.st_nlink),[]).append(name)
 v['original_hardlink_groups']=sorted([dict(paths=sorted(paths),link_count=k[2]) for k,paths in links.items()],
                                     key=lambda group:group['paths'])
 v['journal_pins']={str(p):fingerprint(p)[0]['sha256'] for d in root.parent.glob('ace_llm_intervention*')
                    for p in d.glob('submission.*.json')}
 # Explicit accepted upstream byte pins; never decode descriptors or outcomes.
 for path in UPSTREAM_PINS:
  try:v['upstream_pins'][path]=fingerprint(Path(path))[0]['sha256']
  except (OSError,ValueError) as exc:v['upstream_errors'][path]=dict(type=type(exc).__name__,message=str(exc))

except BaseException as exc:
 v['observation_error']=dict(type=type(exc).__name__,message=str(exc))
print(json.dumps(v,sort_keys=True))
'''


RESOURCES=dict(account='ucb736_asc2',partition='aa100',qos='gpu-testing',requested_cpus=4,
    max_allocated_cpus=4,memory_mib=15360,wall_seconds=2880,gpus=1,gpu_type='a100_3g.20gb',requeue=False)
LIMITS=dict(session_reserve_seconds=600,session_cap_seconds=1200,work_seconds=2820,final_seconds=2860)


def tres(text):
    pairs=[p.split('=',1) for p in text.split(',') if p]
    need(all(len(p)==2 and all(p) for p in pairs) and len(dict(pairs))==len(pairs),'invalid/duplicate allocation TRES')
    return dict(pairs)


def gpu_count(t,cpus,elapsed):
    if not t:return 0 if cpus==elapsed==0 else None
    g={k:v for k,v in t.items() if k.startswith('gres/')}
    if any(not v.isdigit() or not (k=='gres/gpu' or k.startswith('gres/gpu:')) for k,v in g.items()):return None
    typed=[int(v) for k,v in g.items() if k.startswith('gres/gpu:')]
    aggregate=int(g['gres/gpu']) if 'gres/gpu' in g else None
    if aggregate is not None and typed and aggregate!=sum(typed):return None
    return aggregate if aggregate is not None else sum(typed)


def cost(rows):
    cpu=gpu=0
    for row in normalize(rows):
        count=gpu_count(dict(row[7]),row[4],row[5]);need(count is not None,'unknown historical GPU charge')
        cpu+=row[4]*row[5];gpu+=count*row[5]
    return cpu,gpu


def resource_tres(t):
    return (t.get('cpu')=='4' and t.get('node')=='1' and t.get('mem') in ('15360M','15G','15.00G')
        and t.get('gres/gpu:a100_3g.20gb')=='1' and gpu_count(t,4,1)==1
        and all(k in ('gres/gpu','gres/gpu:a100_3g.20gb') for k in t if k.startswith('gres/')))


def resources(observation,job,output,files):
    row=observation['parent_accounting'];normalized=normalize([row])[0];errors=[]
    cpus,elapsed=normalized[4:6];allocated=dict(normalized[7]);gpu=gpu_count(allocated,cpus,elapsed)
    details=observation['results']['details'];requested={};request_identity=False
    if details['returncode']==0:
        rows=[r.split('|') for r in details['stdout'].splitlines() if r.strip()]
        if len(rows)==1 and len(rows[0])>=6:
            r=rows[0]
            try:requested=tres(r[4])
            except ValueError as exc:errors.append(str(exc))
            request_identity=r[:4]==[job,'aa100','gpu-testing','48'] and r[5]=='paco0228'
    fields={};allocation_pin=files.get('launch/gpu/allocation.json',{}).get('sha256')
    if allocation_pin:
        try:fields=decode(read_metadata(output/'allocation.json',allocation_pin))['fields']
        except (ValueError,KeyError,OSError) as exc:errors.append('saved allocation malformed: '+str(exc))
    if not fields and observation['results']['job']['returncode']==0:
        fields=dict(re.findall(r'([^\s=]+)=(\S+)',observation['results']['job']['stdout']))
    no_requeue=fields.get('JobId')==job and fields.get('Requeue')=='0' and fields.get('Restarts')=='0'
    matched=(request_identity and resource_tres(requested) and resource_tres(allocated) and no_requeue
        and normalized[1]=='ace_llm_scientific_campaign_gpu01' and normalized[6]=='ucb736_asc2'
        and cpus==4 and gpu==1 and 0<=elapsed<=2880)
    if not matched:errors.append('actual/requested GPU identity/resource/no-requeue/wall contract differs or unavailable')
    if gpu is None:errors.append('unknown GPU charge; never infer zero')
    return dict(resource_contract_matched=matched,errors=errors,expected=RESOURCES,requested_tres=requested,
        allocated_tres=allocated,allocated_cpus=cpus,elapsed_seconds=elapsed,allocated_cpu_seconds=cpus*elapsed,
        gpu_count=gpu,gpu_slice_seconds=None if gpu is None else gpu*elapsed,requested_mig_memory_gib=20,
        scheduler_state=row[2],scheduler_exit=row[3],account=row[6],alloc_tres=row[7],
        no_requeue_verified=no_requeue,allocation_fields=fields,allocation_source_sha256=allocation_pin,
        memory_note='15GiB host request and typed20GB MIG are distinct; framework total device bytes reported separately.')


def public_fields(data,allowed):
    """Select top-level JSON values without decoding any other values (notably scores).

    Unknown values are scanned lexically for object boundaries only. Original bytes
    remain authoritative; this does not validate or interpret their contents.
    """
    text=data.decode('utf-8');decoder=json.JSONDecoder();i=0;seen=set();result={}
    def ws(pos):
        while pos<len(text) and text[pos].isspace():pos+=1
        return pos
    i=ws(i);need(i<len(text) and text[i]=='{','public evidence must be a JSON object');i+=1
    while True:
        i=ws(i)
        if i<len(text) and text[i]=='}':i+=1;break
        key,end=decoder.raw_decode(text,i);need(type(key) is str and key not in seen,'duplicate/nonstring public key');seen.add(key)
        i=ws(end);need(i<len(text) and text[i]==':','public evidence colon required');start=ws(i+1)
        j=start;stack=[];quoted=False;escaped=False
        while j<len(text):
            c=text[j]
            if quoted:
                if escaped:escaped=False
                elif c=='\\':escaped=True
                elif c=='"':quoted=False
            elif c=='"':quoted=True
            elif c in '[{':stack.append(c)
            elif c in ']}':
                if not stack:break
                need((stack.pop(),c) in (('[',']'),('{','}')),'unbalanced public evidence')
            elif c==',' and not stack:break
            j+=1
        need(j>start and not quoted and not stack,'incomplete public value')
        if key in allowed:result[key]=decode(text[start:j])
        i=ws(j);need(i<len(text) and text[i] in ',}','public value delimiter required')
        if text[i]=='}':i+=1;break
        i=ws(i+1);need(i<len(text) and text[i]!='}','trailing public comma')
    need(ws(i)==len(text),'trailing public evidence')
    return result


def public_gpu_evidence(output,files):
    """Only producer public telemetry; all generations, private outcomes and tensors remain opaque."""
    prefix='launch/gpu/';selected={};errors=[];services={}
    scalars={'utc','outer_elapsed_seconds','service_elapsed_seconds','policy_id','registered_pid',
        'positive_generations','first_verified_monotonic','last_gpu_monotonic','last_generation_monotonic',
        'started_monotonic','closed_monotonic','process_group_closed','post_exit_gpu_empty','cuda_interval_ms','error'}
    for pid in POLICIES:
        stem='controller/phase/'+pid+'/'
        names=sorted(n[len(prefix):] for n in files if n.startswith(prefix+stem) and
            (re.fullmatch(r'telemetry-\d+\.json',n[len(prefix+stem):]) or n[len(prefix+stem):]=='summary.json'))
        need(len(names)<=20000,'bounded public metadata inventory required; retain raw originals')
        positive_memory=[];positive_generations=0;cuda_interval=None;registered=set();samples=0
        for name in names:
            item=files[prefix+name]
            try:
                v=public_fields(read_metadata(output/name,item['sha256']),scalars|{'gpu_process_sample','uncertainties'})
                for k in scalars&set(v):need(type(v[k]) in (str,int,float,bool,type(None)),'public scalar required')
                need(v.get('policy_id')==pid,'public service identity differs')
                process=v.get('registered_pid')
                if process is not None:need(type(process) is int and process>0,'registered PID invalid');registered.add(process)
                count=v.get('positive_generations')
                if count is not None:
                    need(type(count) is int and 0<=count<=576,'bounded recorded generation count required')
                    positive_generations=max(positive_generations,count)
                if name.endswith('/summary.json'):
                    interval=v.get('cuda_interval_ms')
                    if type(interval) in (int,float) and math.isfinite(interval) and interval>0:cuda_interval=interval
                sample=v.pop('gpu_process_sample',None)
                if sample is not None:
                    samples+=1
                    need(type(sample) is dict,'public GPU sample required')
                    # Retain only known sample fields in summary; full original JSON stays opaque in custody.
                    sample={k:sample[k] for k in ('returncode','owned_rows') if k in sample}
                    v['gpu_process_sample']=sample
                    if sample.get('returncode')==0 and type(sample.get('owned_rows')) is list:
                        for row in sample['owned_rows']:
                            if not isinstance(row,str):continue
                            parts=[part.strip() for part in row.split(',')]
                            if len(parts)!=3 or type(process) is not int or parts[0]!=str(process):continue
                            try:memory=float(parts[2])
                            except ValueError:continue
                            if math.isfinite(memory) and memory>0:positive_memory.append(memory)
                selected[name]=dict(sha256=item['sha256'],reported=v)
            except (ValueError,KeyError,TypeError,OSError) as exc:errors.append(name+': '+str(exc))
        if len(registered)>1:errors.append(pid+': recorded owned PID changed')
        services[pid]=dict(registered_pids=sorted(registered),nvidia_samples=samples,
            positive_owned_memory_rows=len(positive_memory),owned_memory_mib_max=max(positive_memory) if positive_memory else None,
            recorded_positive_generations=positive_generations,reported_cuda_interval_ms=cuda_interval,
            independent_signal_types_present=bool(positive_memory) and positive_generations>0 and len(registered)==1,
            utilization_percent=None)
    return dict(acceptance=False,reported_metadata=selected,services=services,errors=errors,
        all_three_services_have_reported_work_signals=all(v['independent_signal_types_present'] for v in services.values()),
        utilization_percent=None,utilization_note='Owned NVIDIA process memory plus recorded positive generations are distinct reported signals; not SM utilization percent. Missing/unreliable signals remain uncertain. Independent runtime and cleanup audit still required.',
        generation_records_decoded=False,scored_outcomes_decoded=False,adapter_tensors_decoded=False,runtime_qualified=False)


def upstream_disagreements(actual,preserved,preserved_directories):
    """Original accepted bytes stay fixed; GPU appends only the three frozen campaign attempts."""
    errors=[]
    def allowed(label,name):
        return label=='cpu' and any(name==p or name.startswith(p+'/') for p in
            ('cpu/worker/artifacts/campaign/policy-05','cpu/worker/artifacts/campaign/policy-06','cpu/worker/artifacts/campaign/policy-07'))
    for label,expected in preserved.items():
        current={n[len(label)+1:]:v for n,v in actual['files'].items() if n.startswith(label+'/')}
        dirs={n[len(label)+1:] for n in actual['directories'] if n.startswith(label+'/')}
        prior_dirs=set(preserved_directories[label])
        if any(current.get(n)!=v for n,v in expected.items()):errors.append(label+': original accepted bytes missing/changed')
        if any(not allowed(label,n) for n in set(current)-set(expected)):errors.append(label+': unexpected added files')
        if not prior_dirs<=dirs:errors.append(label+': original accepted directory missing')
        if any(not allowed(label,n) for n in dirs-prior_dirs):errors.append(label+': unexpected added directories')
    return errors


def committed_sidecar(relative,pin_value,commit):
    path=Path(relative)
    need(not path.is_absolute() and '..' not in path.parts and path.parts,'safe committed sidecar path required')
    data=read_metadata(REPO/path,pin_value)
    result=subprocess.run(['git','--no-replace-objects','show',commit+':'+path.as_posix()],cwd=REPO,capture_output=True,timeout=20)
    need(result.returncode==0 and result.stdout==data,'independently pinned sidecar/full commit differs')
    return data


def accounting_extension(observation,baseline,job,intent_pin,result_pin):
    prior=[r for r in observation['related_accounting'] if r[0]!=job]
    current=[r for r in observation['related_accounting'] if r[0]==job]
    rows_ok=(len(prior)==45 and len(current)==1 and len(observation['related_accounting'])==46
        and normalize(prior)==normalize(baseline['related_accounting'])
        and normalize(current)==normalize([observation['parent_accounting']])
        and all(r[2].split()[0] in TERMINAL for r in observation['related_accounting']))
    journals={**baseline['journal_pins'],ROOT+'/submission.intent.json':intent_pin,
              ROOT+'/submission.result.json':result_pin}
    journals_ok=(len(baseline['journal_pins'])==92 and len(journals)==94 and observation['journal_pins']==journals)
    return rows_ok,journals_ok


def validate_remote_intent(data, expected_pin, local_intent, claim_pin):
    need(sha(data)==expected_pin, 'authenticated remote intent bytes differ')
    remote=decode(data)
    additions={'remote_utc','fresh_readiness'}
    need(type(local_intent) is dict and not (set(local_intent)&additions)
         and type(remote) is dict and set(remote)==set(local_intent)|additions,
         'remote intent fields differ from local intent plus explicit additions')
    need(raw({k:remote[k] for k in local_intent})==raw(local_intent),
         'authenticated remote intent differs from original local intent')
    need(pin(claim_pin) and remote['existing_namespace_claim_sha256']==claim_pin,
         'authenticated remote intent namespace claim differs')
    need(type(remote['remote_utc']) is str and bool(remote['remote_utc'])
         and type(remote['fresh_readiness']) is dict, 'remote intent augmentation malformed')


STREAM_HELPER_SHA='fab01ad840e4e73ef0fc2136fd2eeb12b1033256e80a8f96a392afb2d50b758a'
STREAM_REVIEW_SHA='5058426e9dccaaf210eb2969a8623a31123f13dfefaa43c57e975e5800819371'


def load_stream_helper(source):
    need(sha(source)==STREAM_HELPER_SHA,'independently reviewed stream helper differs')
    module=types.ModuleType('pinned_campaign_stream_transport')
    module.__file__='<independently-committed-stream-custody>'
    exec(compile(source,module.__file__,'exec'),vars(module))
    return module


def stream_request(before):
    roots={label:path for label,path,flag in (
        ('launch',ROOT,'root_present'),('cpu',CPU_ROOT,'cpu_present'),('training',TRAIN_ROOT,'training_present'),('token',TOKEN_ROOT,'token_present'),('common',COMMON_ROOT,'common_present'),('failed01',FAILED_ROOT,'failed_present')) if before[flag]}
    singles={label:path for label,path,flag in (
        ('namespace.json',REMOTE_NAMESPACE,'namespace_present'),('original-namespace.json',OLD_REMOTE_NAMESPACE,'original_namespace_present')) if before[flag]}
    return dict(roots=roots,single_files=singles,
        inventory=dict(files=before['files'],directories=sorted(before['directories'])))


def compare_observations(before,after):
    # Same complete comparisons as the original collector, before materialization.
    need(after['files']==before['files'] and sorted(after['directories'])==sorted(before['directories'])
         and all(after[k]==before[k] for k in ('cpu_present','training_present','token_present'))
         and after['common_present']==before['common_present'] and after['failed_present']==before['failed_present']
         and after['root_present']==before['root_present'] and after['namespace_present']==before['namespace_present']
         and after['original_namespace_present']==before['original_namespace_present']
         and after['original_hardlink_groups']==before['original_hardlink_groups']
         and after['parent_accounting']==before['parent_accounting']
         and after['journal_pins']==before['journal_pins']
         and after['upstream_pins']==before['upstream_pins'] and after['upstream_errors']==before['upstream_errors']
         and normalize(after['related_accounting'])==normalize(before['related_accounting']),
         'second remote bytes/journals/terminal accounting differ')


def mirror_attempt(source,destination,copy_file):
    """Preserve every archive/argv/partial receipt as new independent bytes, never overwrite."""
    source,destination=Path(source),Path(destination)
    if not source.exists():return
    need(not source.is_symlink(),'transport attempt symlink forbidden')
    destination.mkdir(mode=0o700,exist_ok=False)
    for path in sorted(source.rglob('*')):
        need(not path.is_symlink(),'transport evidence symlink forbidden')
        target=destination/path.relative_to(source)
        if path.is_dir():target.mkdir(mode=0o700)
        else:copy_file(path,target)
    need(inventory(source)==inventory(destination),'whole transport archive/receipt mirror differs')


def stream_transfer(before,*,observe,save,helper,helper_source,external,local,copy_file,coordinator_bytes=0):
    """Transport only. Caller retains terminal/locks/full downstream acceptance gates."""
    need(sha(helper_source)==STREAM_HELPER_SHA,'stream source pin differs')
    external,local=Path(external),Path(local)
    need(external.is_dir() and local.is_dir() and external!=local,'two previously exclusively claimed capsules required')
    need(not any(os.path.lexists(p/'remote') for p in (external,local)),
         'raw materialization roots must remain absent; never remove/replace a precreated root')
    request=raw(stream_request(before));expected=helper.request_check(decode(request));bound=helper.archive_bound(expected)
    size=sum(v['bytes'] for v in before['files'].values())
    # Conservatively budget both copies AND both retained full archives on each filesystem.
    for parent in (external,local):
        fs=os.statvfs(parent)
        need(fs.f_bavail*fs.f_frsize>2*size+2*bound+coordinator_bytes+2*1024**3,'insufficient complete stream custody space')
    command=['bash',HELPER,'run',shlex.join(['python3','-B','-c',helper_source.decode(),'emit','--request-sha256',sha(request)])]
    save('stream-request.json',decode(request));save('stream-command.json',command)
    save('stream-before.json',before)
    for dest in (external,local):write(dest/'stream-emitter.py',helper_source)
    save('stream-intent.json',dict(helper_sha256=STREAM_HELPER_SHA,helper_review_sha256=STREAM_REVIEW_SHA,
        request_sha256=sha(request),command_sha256=sha(raw(command)),archive_bound_bytes=bound,
        transport_timeout_seconds=1800,copy_roots=[str(external/'remote'),str(local/'remote')],
        acceptance=False,retry_allowed=False))
    attempt=external/'stream-attempt';mirror=local/'stream-attempt';original_error=None
    try:
        helper.capture(command,request,attempt,1800)
        capture_pin=fingerprint(attempt/'capture.json',sole_link=True)['sha256']
        after=observe('inventory_after_transport.json')
        compare_observations(before,after)  # Includes journals/queue gate/upstream/accounting, not only bytes.
        save('stream-after.json',after)
        result=helper.materialize(attempt,capture_pin,external/'stream-before.json',sha(raw(before)),
            external/'stream-after.json',sha(raw(after)),external/'remote',local/'remote')
        need(result['status']=='transport_verified_pending_collector_gates' and result['acceptance'] is False,
             'transport does not establish acceptance')
        actual=inventory(external/'remote')
        need(actual==inventory(local/'remote')==dict(files=before['files'],directories=sorted(before['directories'])),
             'whole raw namespace/empty-directory two-copy custody differs')
        save('stream-transport.json',dict(helper_sha256=STREAM_HELPER_SHA,helper_review_sha256=STREAM_REVIEW_SHA,
            capture_sha256=capture_pin,materialization_sha256=fingerprint(attempt/'materialization.json',sole_link=True)['sha256'],
            archive=fingerprint(attempt/'archive.tar',sole_link=True),acceptance=False))
        return actual,after
    except BaseException as exc:
        original_error=exc
        raise
    finally:
        try:mirror_attempt(attempt,mirror,copy_file)
        except BaseException as secondary:
            try:save('stream-mirror-failure.json',dict(type=type(secondary).__name__,message=str(secondary),
                original_error=None if original_error is None else dict(type=type(original_error).__name__,message=str(original_error)),
                original_archive_preserved=True,acceptance=False,retry_allowed=False))
            except BaseException:pass
            if original_error is None:raise


def main():
    ap=argparse.ArgumentParser(description=__doc__)
    for name in ('job-id','packet-sha256','submission-result-sha256','local-intent-sha256','packet-commit','collector-sha256','collector-repository-path','collector-review','collector-review-sha256','cpu-terminal-custody','cpu-custody-inventory-sha256','packet-review','packet-review-sha256','stream-helper-repository-path','stream-helper-review-repository-path'):ap.add_argument('--'+name,required=True)
    a=ap.parse_args();need(re.fullmatch('[1-9][0-9]*',a.job_id) is not None,'exact current job ID required')
    packet_raw=read_metadata(LAUNCH/'packet.json',a.packet_sha256);packet=decode(packet_raw)
    result_raw=read_metadata(LAUNCH/'submission.result.json',a.submission_result_sha256);result=decode(result_raw)
    need(re.fullmatch('[0-9a-f]{40}',a.packet_commit) is not None,'full eventual packet commit required')
    need(sha(Path(__file__).read_bytes())==a.collector_sha256,'independently reviewed collector source pin required')
    need(packet['schema']=='ace-scientific-campaign-gpu-launch-v1' and packet['remote_root']==ROOT
         and result.get('job_id')==a.job_id and result.get('returncode')==0 and result.get('ambiguous') is False
         and pin(result.get('intent_sha256')),'unambiguous original packet/job/result required')
    intent_raw=read_metadata(LAUNCH/'submission.intent.json',a.local_intent_sha256);intent=decode(intent_raw)
    pins={**packet['new_input_files'],'packet.json':a.packet_sha256}
    collector_path=Path(a.collector_repository_path)
    need(not collector_path.is_absolute() and '..' not in collector_path.parts and collector_path.suffix=='.py',
         'explicit safe collector repository path required')
    own=read_metadata(Path(__file__),a.collector_sha256)
    git=subprocess.run(['git','--no-replace-objects','show',a.packet_commit+':'+collector_path.as_posix()],cwd=REPO,capture_output=True,timeout=20)
    need(git.returncode==0 and git.stdout==own,'standalone collector must equal independently pinned full packet commit bytes')
    collector_review=Path(a.collector_review).absolute();cr=read_metadata(collector_review,a.collector_review_sha256)
    git=subprocess.run(['git','--no-replace-objects','show',a.packet_commit+':'+str(collector_review.relative_to(REPO))],cwd=REPO,capture_output=True,timeout=20)
    need(cr.strip() and git.returncode==0 and git.stdout==cr,'independent collector review must be in packet commit')
    need(intent['packet_sha256']==a.packet_sha256 and intent['remote_root']==ROOT and intent['pins']==pins
         and intent['packet_commit']==a.packet_commit,'current local submission lineage differs')
    need(all(type(n) is str and not Path(n).is_absolute() and '..' not in Path(n).parts and pin(h) for n,h in pins.items()),
         'safe complete input pin roster required')
    # Verify immutable local packet/Git bytes without loading any project/author callable.
    for n,h in pins.items():
        data=read_metadata(LAUNCH/n,h)
        git=subprocess.run(['git','--no-replace-objects','show',a.packet_commit+':'+str((LAUNCH/n).relative_to(REPO))],
                           cwd=REPO,capture_output=True,timeout=20)
        need(git.returncode==0 and git.stdout==data==read_metadata(LAUNCH_EXT/n,h),'committed packet mirrors differ')
    review=Path(a.packet_review).absolute();review_raw=read_metadata(review,a.packet_review_sha256)
    git=subprocess.run(['git','--no-replace-objects','show',a.packet_commit+':'+str(review.relative_to(REPO))],
                       cwd=REPO,capture_output=True,timeout=20)
    need(review_raw.strip() and git.returncode==0 and git.stdout==review_raw and intent['review_sha256']==a.packet_review_sha256,
         'independent original packet review/commit required')
    # Reuse the exact corrected coordinator's stdlib metadata-only admission.
    # All packet/Git/mirror bytes above have already been independently authenticated.
    builder_raw=read_metadata(LAUNCH/'build_packet.py',BUILDER_SHA)
    need(pins['build_packet.py']==BUILDER_SHA,'reviewed corrected campaign coordinator required')
    b=types.ModuleType('captured_campaign_metadata');b.__file__=str(LAUNCH/'build_packet.py')
    exec(compile(builder_raw,b.__file__,'exec'),vars(b))
    supplied={n:read_metadata(LAUNCH/b.metadata_name(n),pins[b.metadata_name(n)]) for n in b.METADATA}
    ctx=b.authenticate(supplied)  # Pure original metadata; no builder main, science or source/model import.
    baseline_pin=pins['cpu-baseline.json'];baseline=ctx['metadata']['cpu-baseline']
    accepted=ctx['metadata']['cpu-acceptance'];upstream=ctx['metadata']['cpu-disposition']
    cpu_result=ctx['metadata']['cpu-result'];cpu_packet=ctx['metadata']['cpu-packet']
    collection=ctx['metadata']['collection-acceptance']
    need(packet['baseline_sha256']==intent['baseline_sha256']==baseline_pin
         and packet['cpu_job_id']==intent['cpu_job_id']==accepted['job_id']
         and packet['cpu_acceptance_sha256']==intent['cpu_acceptance_sha256']==pins['cpu-acceptance.json'],
         'accepted45/92 CPU campaign/intent bindings differ')
    need(packet['resources']==intent['resources']==RESOURCES and packet['limits']==intent['limits']==LIMITS,
         'unchanged GPU campaign resource/limit contract required')
    need(packet['source_commit']==intent['source_commit']==b.SOURCE_COMMIT
         and packet['operational_amendment_sha256']==pins['operational-amendment.json']
         and packet['gpu_packet_sha256']==pins['inputs/packet.json']
         and packet['cpu_packet_sha256']==pins['cpu-packet.json']
         and packet['worlds']==24 and packet['cells']==192
         and packet['gpu_policy_ids']==list(POLICIES) and packet['new_training_updates']==0,
         'exact frozen scientific campaign packet required')
    need(a.job_id not in [ctx['metadata'][n+'-result']['job_id'] for n in ('collection','token','training','cpu')]+['35407428'],
         'distinct current campaign job required')
    original_files=ctx['observations']['cpu']['files']
    # Full accepted CPU capsule is independently pinned, including both original inventories.
    cpu_custody=Path(a.cpu_terminal_custody).resolve(strict=True)
    custody_raw=read_metadata(cpu_custody/'custody-inventory.json',a.cpu_custody_inventory_sha256)
    custody=decode(custody_raw);cpu_custody_before=inventory(cpu_custody)
    actual_capsule=dict(files={n:v for n,v in cpu_custody_before['files'].items() if n!='custody-inventory.json'},directories=cpu_custody_before['directories'])
    matches=[v for k,v in custody['copies'].items() if Path(k).resolve()==cpu_custody]
    need(custody['identical'] is True and len(matches)==1 and matches[0]==actual_capsule,
         'complete independently pinned original CPU campaign custody capsule required')
    for name,h in [('disposition.json',pins['cpu-disposition.json']),('inventory_transport.json',pins['cpu-inventory.json'])]:
        need(cpu_custody_before['files'][name]['sha256']==h,'CPU capsule metadata differs')
    need(inventory(cpu_custody/'remote')['files']==original_files,'complete accepted CPU raw capsule differs')
    # This existing pure byte validator checks complete120 CPU cells, opaque bundle/attempt/source bytes,
    # matching numerical plan and all five CPU attempts. It never decodes private outcomes or imports project code.
    opaque_cpu_inputs=b.admit_cpu_bytes(ctx,cpu_custody/'remote');del opaque_cpu_inputs
    upstream_pins=ctx['upstream_pins']
    need(packet['original_cpu_inputs']==upstream_pins,'complete original CPU/history input roster differs')
    preserved={};preserved_directories={}
    for label,stage in [('cpu','cpu'),('training','training'),('token','token'),('common','collection')]:
        observed=ctx['observations'][stage]['files']
        preserved[label]={n[len('launch/'):]:v for n,v in observed.items() if n.startswith('launch/')}
        preserved_directories[label]=[n[len('launch/'): ] for n in ctx['observations'][stage]['directories'] if n.startswith('launch/')]
        need(preserved[label],'complete upstream root required: '+label)
    # The accepted collection transport must preserve the failed first collection's whole original root.
    preserved['failed01']={n[len('failed01/'):]:v for n,v in ctx['observations']['collection']['files'].items() if n.startswith('failed01/')}
    preserved_directories['failed01']=[n[len('failed01/'): ] for n in ctx['observations']['collection']['directories'] if n.startswith('failed01/')]
    need(preserved['failed01'],'complete failed collection01 root required')
    for path,h in upstream_pins.items():
        found=[(label,root) for label,root in UPSTREAM_ROOTS.items() if path.startswith(root+'/')]
        need(len(found)==1,'explicit upstream input root differs')
        label,root=found[0]
        need(preserved[label][path[len(root)+1:]]['sha256']==h,'upstream input/full original root differs')
    # Helper and independent review are standalone committed sidecars, never child-source members.
    helper_source=committed_sidecar(a.stream_helper_repository_path,STREAM_HELPER_SHA,a.packet_commit)
    helper_review=committed_sidecar(a.stream_helper_review_repository_path,STREAM_REVIEW_SHA,a.packet_commit)
    recovery_bindings=dict(recovery_authority_sha256=pins['recovery-authority.json'],original_namespace_claim_sha256=OLD_CLAIM_SHA)
    need(intent['existing_namespace_claim_sha256']==packet['namespace_claim_sha256']==pins['namespace-claim.json']
         and intent['namespace_admission_sha256']==pins['namespace-admission.json']
         and all(intent.get(k)==v for k,v in recovery_bindings.items()) and intent['new_namespace_claimed'] is False,
         'current GPU intent namespace/acceptance joins differ')
    locks=[];claimed=[];sealed=False;started=time.monotonic();cpu=time.process_time()
    def save(name,value):
        data=raw(value)
        for dest in claimed:write(dest/name,data)
    def run_saved(name,command,*,source=None,timeout):
        try:
            p=subprocess.run(command,input=source,capture_output=True,text=True,timeout=timeout)
            transport=dict(command=command,returncode=p.returncode,stdout=p.stdout,stderr=p.stderr,utc=utc())
        except subprocess.TimeoutExpired as exc:
            txt=lambda x:x.decode(errors='replace') if isinstance(x,bytes) else x
            transport=dict(command=command,returncode=None,timeout=True,stdout=txt(exc.stdout),stderr=txt(exc.stderr),utc=utc())
        if source is not None:transport['python_source']=source
        save(name,transport);need(transport['returncode']==0,'failed/partial custody retained: '+name)
        return transport
    source='\n'.join(k+'='+repr(v) for k,v in dict(ROOT=ROOT,NAMESPACE=REMOTE_NAMESPACE,JOB=a.job_id,
        TERMINAL=TERMINAL,OLD_NAMESPACE=OLD_REMOTE_NAMESPACE,UPSTREAM_PINS=upstream_pins,COMMON_ROOT=COMMON_ROOT,FAILED_ROOT=FAILED_ROOT,CPU_ROOT=CPU_ROOT,TRAIN_ROOT=TRAIN_ROOT,TOKEN_ROOT=TOKEN_ROOT).items())+'\n'+REMOTE_OBSERVATION
    def observe(name):
        transport=run_saved(name,['bash',HELPER,'run','python3 -'],source=source,timeout=240)
        v=decode(transport['stdout'])
        need(v.get('terminal_gate') is True and not v.get('observation_error'),
             'terminal inventory unavailable: '+str(v.get('observation_error')))
        return v
    def copy_file(src,dst):
        with Path(src).open('rb') as source_file,Path(dst).open('xb') as target:
            shutil.copyfileobj(source_file,target,1024**2);target.flush();os.fsync(target.fileno())
        return str(dst)
    try:
        for name in ('ace-delivery-controller.lock','ace-foundation-controller.lock'):
            lock=BASE/name;need(lock==lock.resolve(),'coordinator lock alias')
            f=os.fdopen(os.open(lock,os.O_RDWR|os.O_NOFOLLOW),'r+')
            try:fcntl.flock(f,fcntl.LOCK_EX|fcntl.LOCK_NB)
            except BaseException:f.close();raise
            locks.append(f)
        need(all(not os.path.lexists(p) for p in (LOCAL,EXT)),'terminal custody already claimed; never retry')
        for dest in (EXT,LOCAL):
            dest.mkdir(mode=0o700);claimed.append(dest)
            for sub in ('coordinator','namespaces'):(dest/sub).mkdir(mode=0o700)
            write(dest/'pull_terminal.py',Path(__file__).read_bytes())
            write(dest/'stream_custody.py',helper_source);write(dest/'stream_custody_review.md',helper_review)
        save('collector-intent.json',dict(utc=utc(),job_id=a.job_id,packet_sha256=a.packet_sha256,
            submission_result_sha256=a.submission_result_sha256,remote_root=ROOT,remote_namespace=REMOTE_NAMESPACE,
            local_namespace=str(LOCAL_NAMESPACE),collector_sha256=sha(Path(__file__).read_bytes()),
            accepted_cpu_root=CPU_ROOT,accepted_collection_root=COMMON_ROOT,preserved_failed_root=FAILED_ROOT,
            collector_repository_path=a.collector_repository_path,collector_review_sha256=a.collector_review_sha256,
            cpu_custody_inventory_sha256=a.cpu_custody_inventory_sha256,
            stream_helper_sha256=STREAM_HELPER_SHA,stream_helper_review_sha256=STREAM_REVIEW_SHA,
            stream_helper_repository_path=a.stream_helper_repository_path,stream_helper_review_repository_path=a.stream_helper_review_repository_path,
            packet_commit=a.packet_commit,local_intent_sha256=a.local_intent_sha256,original_local_namespace=str(OLD_LOCAL_NAMESPACE),
            original_remote_namespace=OLD_REMOTE_NAMESPACE,recovery_bindings=recovery_bindings,
            retry_allowed=False,acceptance=False))
        for dest in claimed:
            write(dest/'collector-review.md',cr)
        shutil.copytree(cpu_custody,EXT/'upstream-cpu-custody',copy_function=copy_file)
        need(inventory(cpu_custody)==inventory(EXT/'upstream-cpu-custody')==cpu_custody_before,'accepted CPU custody changed during copy')
        # Keep complete local and external coordinator histories, not just their successful receipts.
        coordinator={}
        for label,original in (('local-launch',LAUNCH),('external-launch',LAUNCH_EXT)):
            before=inventory(original)
            shutil.copytree(original,EXT/'coordinator'/label,copy_function=copy_file)
            need(inventory(original)==inventory(EXT/'coordinator'/label)==before,'coordinator changed during copy')
            coordinator[label]=before
        local_claim_present=os.path.lexists(LOCAL_NAMESPACE)
        if local_claim_present:
            claim_raw=read_metadata(LOCAL_NAMESPACE)
            for dest in claimed:write(dest/'namespaces/local.namespace.json',claim_raw)
        else:claim_raw=None
        save('local-namespace-observation.json',dict(path=str(LOCAL_NAMESPACE),present=local_claim_present,
            sha256=None if claim_raw is None else sha(claim_raw)))
        original_claim_raw=read_metadata(OLD_LOCAL_NAMESPACE) if os.path.lexists(OLD_LOCAL_NAMESPACE) else None
        if original_claim_raw is not None:
            for dest in claimed:write(dest/'namespaces/original-local.namespace.json',original_claim_raw)
        save('original-local-namespace-observation.json',dict(path=str(OLD_LOCAL_NAMESPACE),
            present=original_claim_raw is not None,sha256=None if original_claim_raw is None else sha(original_claim_raw)))
        before=observe('inventory_transport.json')
        size=sum(v['bytes'] for v in before['files'].values())
        helper=load_stream_helper(helper_source)
        actual,after=stream_transfer(before,observe=observe,save=save,helper=helper,helper_source=helper_source,
            external=EXT,local=LOCAL,copy_file=copy_file,
            coordinator_bytes=sum(v['bytes'] for info in coordinator.values() for v in info['files'].values())
                +sum(v['bytes'] for v in cpu_custody_before['files'].values()))
        (LOCAL/'upstream-cpu-custody').mkdir(mode=0o700)
        for sub in ('coordinator','upstream-cpu-custody'):
            for path in (EXT/sub).iterdir():
                target=LOCAL/sub/path.name
                if path.is_dir():shutil.copytree(path,target,copy_function=copy_file)
                else:copy_file(path,target)
            need(inventory(EXT/sub)==inventory(LOCAL/sub),'second independent byte copy differs')
        errors=[]
        if inventory(cpu_custody)!=cpu_custody_before:errors.append('original accepted CPU custody changed')
        errors.extend(upstream_disagreements(actual,preserved,preserved_directories))
        if before['upstream_pins']!=upstream_pins or before['upstream_errors']:
            errors.append('accepted original CPU/collection input bytes changed/missing')
        if actual['files'].get('original-namespace.json',{}).get('sha256')!=OLD_CLAIM_SHA:
            errors.append('original remote namespace claim missing/changed')
        if original_claim_raw is None or sha(original_claim_raw)!=OLD_CLAIM_SHA:
            errors.append('original local registry missing/changed')
        if original_claim_raw is not None and (not os.path.lexists(OLD_LOCAL_NAMESPACE)
                or fingerprint(OLD_LOCAL_NAMESPACE)['sha256']!=sha(original_claim_raw)):
            errors.append('original local registry changed during collection')
        if not before['root_present']:errors.append('original remote root missing')
        mismatches=[n for n,h in pins.items() if actual['files'].get('launch/'+n,{}).get('sha256')!=h]
        if mismatches:errors.append('remote original input/packet pin disagreement')
        if actual['files'].get('launch/submission.result.json',{}).get('sha256')!=a.submission_result_sha256:
            errors.append('remote current result pin differs')
        if actual['files'].get('launch/submission.intent.json',{}).get('sha256')!=result['intent_sha256']:
            errors.append('remote current intent pin differs')
        expected_claim=intent.get('existing_namespace_claim_sha256')
        if claim_raw is None or not pin(expected_claim) or sha(claim_raw)!=expected_claim:
            errors.append('separate local namespace claim missing/different')
        if actual['files'].get('namespace.json',{}).get('sha256')!=expected_claim:
            errors.append('separate remote namespace claim missing/different')
        try:
            remote_intent_raw=read_metadata(EXT/'remote/launch/submission.intent.json',result['intent_sha256'])
            validate_remote_intent(remote_intent_raw,result['intent_sha256'],intent,expected_claim)
        except (ValueError,TypeError,KeyError,OSError) as exc:
            errors.append('authenticated remote/local intent lineage disagreement: '+str(exc))
        if claim_raw is not None:
            claim=decode(claim_raw)  # Coordinator metadata only; never task/descriptors.
            if not (claim.get('realization_root')==REALIZATION_ROOT
                    and claim.get('freeze_sha256')==pins.get('freeze.json')
                    and claim.get('namespace_admission_sha256')==pins.get('namespace-admission.json')):
                errors.append('namespace claim packet/freeze binding differs')
            if not (all(claim.get(k)==v for k,v in recovery_bindings.items())
                    and claim.get('claim_kind')=='explicit_pre_draw_recovery02'
                    and claim.get('local_registry')==str(LOCAL_NAMESPACE)
                    and claim.get('remote_registry')==REMOTE_NAMESPACE
                    and claim.get('retry_allowed') is False and claim.get('replacement_worlds') is False):
                errors.append('namespace recovery authority/failed-attempt binding differs')
        accounting_ok,journal_ok=accounting_extension(before,baseline,a.job_id,result['intent_sha256'],a.submission_result_sha256)
        if not accounting_ok:errors.append('exact45 prior plus current46th accounting row differs')
        if not journal_ok:errors.append('exact92 prior plus current94 journals differ')
        steps=before['results']['steps']
        step_parents=[r.split('|') for r in (steps.get('stdout') or '').splitlines() if r.startswith(a.job_id+'|')]
        if steps['returncode']!=0 or len(step_parents)!=1 or normalize([step_parents[0][:8]])!=normalize([before['parent_accounting']]):
            errors.append('full job/step accounting missing or allocation row disagrees')
        for label,original in (('local-launch',LAUNCH),('external-launch',LAUNCH_EXT)):
            if inventory(original)!=coordinator[label]:errors.append(label+' changed while custody was collected')
            captured=coordinator[label]['files']
            if any(captured.get(n,{}).get('sha256')!=h for n,h in pins.items()):errors.append(label+' input pin disagreement')
            if captured.get('submission.result.json',{}).get('sha256')!=a.submission_result_sha256:
                errors.append(label+' current submission result differs')
            if captured.get('submission.intent.json',{}).get('sha256')!=sha(intent_raw):
                errors.append(label+' original local intent differs')
        if local_claim_present and fingerprint(LOCAL_NAMESPACE)['sha256']!=sha(claim_raw):errors.append('local namespace changed')
        allocation=resources(before,a.job_id,EXT/'remote/launch/gpu',actual['files'])
        if after['results']['details']!=before['results']['details']:
            errors.append('scheduler request evidence changed between reads')
        try:
            observed_cost=cost(before['related_accounting']);prior_cost=cost(baseline['related_accounting'])
            need(prior_cost==(baseline['closed_cpu_seconds'],baseline['closed_gpu_slice_seconds']), 'baseline total/row mismatch')
            need(observed_cost==(prior_cost[0]+allocation['allocated_cpu_seconds'],prior_cost[1]+allocation['gpu_slice_seconds']), 'actual full-chain cost mismatch')
            need(observed_cost[0]+3600<=57600 and observed_cost[1]<=7200,'actual cumulative resource ceiling exceeded')
        except (ValueError,TypeError,KeyError) as exc:
            errors.append('actual accounting unresolved: '+str(exc));accounting_ok=False
        errors.extend(allocation['errors'])
        marker_names=['terminal.json','failure.json','controller/phase/terminal.json','controller/phase/failure.json',
            'controller/phase/cleanup-hold-intent.json','controller/failure.json']
        for policy in POLICIES:
            marker_names += [f'controller/phase/{policy}/summary.json',f'controller/phase/{policy}/fallback-cleanup.json',
                f'controller/phase/{policy}/post-exit-gpu.json']
            marker_names += [f'services/{policy}/{sub}/{name}.json' for sub in ('worker','launch') for name in ('terminal','failure')]
        markers={n:actual['files'].get('launch/gpu/'+n) for n in marker_names}
        failure_markers={n:v for n,v in actual['files'].items() if (n.startswith('launch/gpu/') or
            any(n.startswith('cpu/cpu/worker/artifacts/campaign/policy-'+i+'/') for i in ('05','06','07')))
            and (n.endswith('/failure.json') or n.endswith('/publication-interruption.json') or n.endswith('/cleanup-failure.json'))}
        complete_markers=all(markers[n] is not None for n in ('terminal.json','controller/phase/terminal.json'))
        reported=public_gpu_evidence(EXT/'remote/launch/gpu',actual['files'])
        # Missing GPU work/cleanup evidence is unknown, not proof of idleness or success.
        save('public-gpu-evidence.json',reported)
        outcome='terminal_custody_review_pending' if complete_markers else 'terminal_partial_outputs_preserved'
        if allocation['scheduler_state'].split()[0]!='COMPLETED' or allocation['scheduler_exit']!='0:0' or failure_markers:
            outcome='terminal_failed_outputs_preserved'
        if errors:outcome='terminal_custody_with_binding_disagreements'
        disposition=dict(schema='ace-scientific-campaign-gpu-terminal-custody-v1',utc=utc(),status=outcome,
            job_id=a.job_id,packet_sha256=a.packet_sha256,submission_result_sha256=a.submission_result_sha256,
            custody_bytes_verified=True,current_lineage_verified=not errors,errors=errors,input_pin_mismatches=mismatches,
            remote_root=ROOT,output_root=ROOT+'/gpu',remote_files=actual['files'],remote_directories=actual['directories'],
            raw_files=len(actual['files']),raw_bytes=size,original_hardlink_groups=before['original_hardlink_groups'],
            hardlink_custody='All original names copied as independent local bytes; original alias metadata retained.',
            namespace_local_sha256=None if claim_raw is None else sha(claim_raw),
            namespace_remote_sha256=actual['files'].get('namespace.json',{}).get('sha256'),
            recovery_bindings=recovery_bindings,cpu_acceptance_sha256=pins['cpu-acceptance.json'],
            cpu_custody_inventory_sha256=a.cpu_custody_inventory_sha256,
            training_acceptance_sha256=pins['training-acceptance.json'],token_acceptance_sha256=pins['token-acceptance.json'],
            collection_acceptance_sha256=pins['collection-acceptance.json'],
            operational_amendment_sha256=pins['operational-amendment.json'],preserved_upstream_roots=preserved,preserved_upstream_directories=preserved_directories,
            authorized_campaign_append_roots=['cpu/cpu/worker/artifacts/campaign/policy-'+n for n in ('05','06','07')],
            original_input_pins=upstream_pins,upstream_inputs_verified=before['upstream_pins']==upstream_pins and not before['upstream_errors'],
            original_namespace_local_sha256=None if original_claim_raw is None else sha(original_claim_raw),
            original_namespace_remote_sha256=actual['files'].get('original-namespace.json',{}).get('sha256'),
            exact_prior_accounting_matched=accounting_ok,exact_prior_and_current_journals_matched=journal_ok,
            observed_related_jobs=len(before['related_accounting']),observed_submission_journals=len(before['journal_pins']),
            allocation=allocation,closed_cpu_seconds=(baseline['closed_cpu_seconds']+allocation['allocated_cpu_seconds']) if accounting_ok else None,
            closed_gpu_slice_seconds=(baseline['closed_gpu_slice_seconds']+allocation['gpu_slice_seconds']) if accounting_ok and allocation['gpu_slice_seconds'] is not None else None,
            preparation_allowance_cpu_seconds=3600,
            cpu_admission_after_release=(baseline['closed_cpu_seconds']+3600+allocation['allocated_cpu_seconds']) if accounting_ok else None,
            cpu_ceiling_seconds=57600,gpu_ceiling_seconds=7200,output_marker_metadata=markers,failure_marker_metadata=failure_markers,
            public_gpu_evidence_sha256=sha(raw(reported)),development_payloads_read=0,scored_outcomes_decoded=False,
            adapter_tensors_decoded=False,scientific_qualified=False,runtime_qualified=False,training_execution_qualified=False,acceptance=False,retry_allowed=False,
            collector_wall_seconds=time.monotonic()-started,collector_process_cpu_seconds=time.process_time()-cpu,
            cost_scope='Local collector process only; subprocess/remote costs not inferred. Actual Slurm allocation costs are separate, not utilization.',
            acceptance_scope='Custody and actual accounting only; retained claims, work signals and exit0 do not qualify runtime, training, utility or science.')
        save('disposition.json',disposition)
        need(not errors,'full bytes retained but bindings disagree; independent reconciliation required')
        inventories={str(dest):inventory(dest) for dest in claimed}
        need(inventories[str(EXT)]==inventories[str(LOCAL)],'complete two-copy capsule differs')
        save('custody-inventory.json',dict(copies=inventories,identical=True,
             excludes='custody-inventory.json itself',acceptance=False))
        need(inventory(EXT)==inventory(LOCAL),'final capsule readback differs')
        sealed=True
        print(raw({k:v for k,v in disposition.items() if k not in ('remote_files','remote_directories')}).decode())
    except BaseException as exc:
        if claimed and not sealed:
            partial_errors=[]
            if len(claimed)==2:
                for sub in ('remote','coordinator','upstream-cpu-custody','stream-attempt'):
                    src=EXT/sub;dst=LOCAL/sub
                    if not src.exists():continue
                    try:
                        for p in sorted(src.rglob('*')):
                            need(not p.is_symlink(),'partial symlink retained only in original copy')
                            q=dst/p.relative_to(src)
                            if p.is_dir():q.mkdir(parents=True,exist_ok=True)
                            elif not q.exists():q.parent.mkdir(parents=True,exist_ok=True);copy_file(p,q)
                            else:need(fingerprint(q)==fingerprint(p),'partial mirror conflict; never overwrite')
                    except BaseException as secondary:partial_errors.append(str(secondary))
            try:save('collector_failure.json',dict(utc=utc(),type=type(exc).__name__,message=str(exc),
                retry_allowed=False,acceptance=False,partial_custody_preserved=True,partial_mirror_errors=partial_errors))
            except BaseException:pass
        raise
    finally:
        if claimed and not sealed:
            try:
                inventories={str(dest):inventory(dest) for dest in claimed}
                same=len(claimed)==2 and inventories[str(EXT)]==inventories[str(LOCAL)]
                name='custody-failure-inventory.json'
                save(name,dict(copies=inventories,identical=same,excludes=name+' itself',acceptance=False))
            except BaseException:pass
        for f in reversed(locks):fcntl.flock(f,fcntl.LOCK_UN);f.close()


if __name__=='__main__':main()
