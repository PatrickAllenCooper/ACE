"""New campaign collector glue checks only; fabricated metadata/opaque local bytes."""
import ast,copy,importlib.util,json,os,shlex,shutil,types,unittest
from pathlib import Path
from unittest import mock
HERE=Path(__file__).resolve().parent
FIXTURES=Path(os.environ['CAMPAIGN_COLLECTOR_FIXTURES']).resolve()
def load(name,path):
 spec=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m
C=load('campaign_collector_new',HERE/'pull_terminal.py')
H=load('accepted_stream_helper',HERE/'stream_custody.py')
class CampaignCollector(unittest.TestCase):
 def test_campaign_48minute_profile_and_46job94journal_extension(self):
  job='9000046';t='cpu=4,node=1,mem=15G,gres/gpu=1,gres/gpu:a100_3g.20gb=1'
  row=[job,'ace_llm_scientific_campaign_gpu01','COMPLETED','0:0','4','2880','ucb736_asc2',t]
  obs=dict(parent_accounting=row,results=dict(details=dict(returncode=0,stdout=f'{job}|aa100|gpu-testing|48|{t}|paco0228|\n'),job=dict(returncode=0,stdout=f'JobId={job} Requeue=0 Restarts=0')))
  resource=C.resources(obs,job,Path('/not-read'),{})
  self.assertTrue(resource['resource_contract_matched']);self.assertEqual((resource['allocated_cpu_seconds'],resource['gpu_slice_seconds']),(11520,2880))
  bad=copy.deepcopy(obs);bad['results']['details']['stdout']=bad['results']['details']['stdout'].replace('|48|','|45|')
  self.assertFalse(C.resources(bad,job,Path('/not-read'),{})['resource_contract_matched'])
  bad=copy.deepcopy(obs);bad['parent_accounting'][4]='8'
  mismatch=C.resources(bad,job,Path('/not-read'),{})
  self.assertFalse(mismatch['resource_contract_matched']);self.assertEqual(mismatch['allocated_cpu_seconds'],23040)
  rows=[[str(1000+i),'ace_llm_prior','FAILED' if i==0 else 'COMPLETED','1:0' if i==0 else '0:0','2','126' if i==0 else '1','ucb736_asc2','cpu=2,node=1,mem=7680M'] for i in range(45)]
  journals={f'/fabricated/prior-{i}':str(i).zfill(64) for i in range(92)}
  baseline=dict(related_accounting=copy.deepcopy(rows),journal_pins=journals)
  obs.update(related_accounting=rows+[row],journal_pins={**journals,C.ROOT+'/submission.intent.json':'a'*64,C.ROOT+'/submission.result.json':'b'*64})
  self.assertEqual(C.accounting_extension(obs,baseline,job,'a'*64,'b'*64),(True,True))
  self.assertEqual(C.cost(obs['related_accounting']),(252+88+11520,2880))
  obs['related_accounting'][0][5]='0'
  self.assertFalse(C.accounting_extension(obs,baseline,job,'a'*64,'b'*64)[0])
  obs['journal_pins']['/fabricated/prior-1']='c'*64
  self.assertFalse(C.accounting_extension(obs,baseline,job,'a'*64,'b'*64)[1])
 def test_only_three_gpu_attempt_appends_preserve_original_cpu_bytes(self):
  old={'cpu':{'cpu/worker/artifacts/campaign/campaign.json':dict(bytes=4,sha256='a'*64),'inputs/packet.json':dict(bytes=3,sha256='b'*64)},'training':{'adapter.pt':dict(bytes=2,sha256='c'*64)}}
  dirs={'cpu':['cpu','cpu/worker','cpu/worker/artifacts','cpu/worker/artifacts/campaign','inputs'],'training':[]}
  actual=dict(files={label+'/'+n:v for label,files in old.items() for n,v in files.items()},directories=['cpu','training']+['cpu/'+n for n in dirs['cpu']])
  for index in ('05','06','07'):
   prefix='cpu/cpu/worker/artifacts/campaign/policy-'+index
   actual['directories'].append(prefix);actual['files'][prefix+'/failure.json']=dict(bytes=5,sha256='d'*64)
  self.assertEqual(C.upstream_disagreements(actual,old,dirs),[])
  bad=copy.deepcopy(actual);bad['files']['cpu/inputs/packet.json']['sha256']='e'*64
  self.assertTrue(C.upstream_disagreements(bad,old,dirs))
  bad=copy.deepcopy(actual);bad['files']['cpu/cpu/worker/artifacts/campaign/policy-08/new.json']=dict(bytes=1,sha256='f'*64)
  self.assertTrue(C.upstream_disagreements(bad,old,dirs))
  bad=copy.deepcopy(actual);bad['directories'].remove('cpu/inputs')
  self.assertTrue(C.upstream_disagreements(bad,old,dirs))
 def test_three_service_signals_leave_scores_generations_and_tensors_opaque(self):
  root=FIXTURES/'telemetry';root.mkdir();files={}
  for i,pid in enumerate(C.POLICIES):
   base='controller/phase/'+pid+'/'
   for n,v in [('telemetry-00000.json',dict(policy_id=pid,registered_pid=700+i,positive_generations=1,gpu_process_sample=dict(returncode=0,owned_rows=[f'{700+i}, GPU-toy, 123']))),('summary.json',dict(policy_id=pid,registered_pid=700+i,positive_generations=1,cuda_interval_ms=5.5,process_group_closed=True,post_exit_gpu_empty=True,generation_evidence={'OPAQUE_SENTINEL':[1,2]},private_scores={'OPAQUE_SENTINEL':3}))]:
    p=root/(base+n);p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(v));files['launch/gpu/'+base+n]=C.fingerprint(p)
   p=root/('services/'+pid+'/worker/generation-0000.json');p.parent.mkdir(parents=True);p.write_bytes(b'OPAQUE_SENTINEL nondecoded fabricated bytes');files['launch/gpu/'+str(p.relative_to(root))]=C.fingerprint(p)
  original=C.decode
  def guarded(data):
   self.assertNotIn('OPAQUE_SENTINEL',data.decode() if isinstance(data,bytes) else data);return original(data)
  with mock.patch.object(C,'decode',side_effect=guarded):result=C.public_gpu_evidence(root,files)
  self.assertTrue(result['all_three_services_have_reported_work_signals']);self.assertFalse(result['acceptance']);self.assertIsNone(result['utilization_percent'])
  missing={n:v for n,v in files.items() if '/dpo_llm/telemetry-' not in n}
  with mock.patch.object(C,'decode',side_effect=guarded):result=C.public_gpu_evidence(root,missing)
  self.assertFalse(result['all_three_services_have_reported_work_signals']);self.assertEqual(result['services']['dpo_llm']['positive_owned_memory_rows'],0)
 def test_stream_six_roots_two_claims_and_exact_independent_archive_copies(self):
  root=FIXTURES/'transport';root.mkdir();source=root/'source';source.mkdir();ext=root/'external';local=root/'local';ext.mkdir();local.mkdir()
  labels=('launch','cpu','training','token','common','failed01')
  for label in labels:
   p=source/label;p.mkdir();(p/'empty').mkdir();(p/'opaque.bin').write_bytes(b'fabricated\x00'+label.encode())
  for name in ('namespace.json','original-namespace.json'):(source/name).write_bytes(b'opaque claim')
  before=dict(**C.inventory(source),**{k:True for k in ('root_present','cpu_present','training_present','token_present','common_present','failed_present','namespace_present','original_namespace_present')},original_hardlink_groups=[],parent_accounting=[],journal_pins={},upstream_pins={},upstream_errors={},related_accounting=[])
  source_bytes=(HERE/'stream_custody.py').read_bytes();calls=[]
  def capture(command,request,attempt,timeout):
   calls.append(command);self.assertEqual(command[:3],['bash',C.HELPER,'run']);self.assertEqual(shlex.split(command[3]),['python3','-B','-c',source_bytes.decode(),'emit','--request-sha256',C.sha(request)])
   attempt.mkdir();C.write(attempt/'request.json',request);C.write(attempt/'command.json',C.raw(command))
   with (attempt/'archive.tar').open('xb') as f:emitted=H.emit(C.decode(request),f)
   C.write(attempt/'stderr.log',(json.dumps(emitted)+'\n').encode())
   C.write(attempt/'capture.json',C.raw(dict(status='captured_pending_inventory_verification',returncode=0,request_sha256=C.sha(request),command_sha256=C.sha(C.raw(command)),**{n:C.fingerprint(attempt/n) for n in ('archive.tar','stderr.log')})))
  def save(n,v):
   for dest in (ext,local):C.write(dest/n,C.raw(v))
  helper=types.SimpleNamespace(capture=capture,materialize=H.materialize,request_check=H.request_check,archive_bound=H.archive_bound)
  changes={key:str(source/label) for key,label in zip(('ROOT','CPU_ROOT','TRAIN_ROOT','TOKEN_ROOT','COMMON_ROOT','FAILED_ROOT'),labels)}
  changes.update(REMOTE_NAMESPACE=str(source/'namespace.json'),OLD_REMOTE_NAMESPACE=str(source/'original-namespace.json'))
  with mock.patch.multiple(C,**changes):
   actual,after=C.stream_transfer(before,observe=lambda _:copy.deepcopy(before),save=save,helper=helper,helper_source=source_bytes,external=ext,local=local,copy_file=shutil.copyfile)
  self.assertEqual(len(calls),1);self.assertEqual(C.inventory(ext),C.inventory(local));self.assertEqual(set(C.decode((ext/'stream-request.json').read_bytes())['roots']),set(labels))
  self.assertNotEqual((ext/'stream-attempt/archive.tar').stat().st_ino,(local/'stream-attempt/archive.tar').stat().st_ino)
  self.assertFalse(C.decode((ext/'stream-transport.json').read_bytes())['acceptance'])
  after['training_present']=False
  with self.assertRaisesRegex(ValueError,'second remote'):C.compare_observations(before,after)

if __name__=='__main__':unittest.main(verbosity=2)
