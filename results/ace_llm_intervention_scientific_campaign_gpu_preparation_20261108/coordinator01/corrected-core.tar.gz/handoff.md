# GPU campaign coordinator R1 correction

Initial source and 1-required review preserved in predecessor/ and initial-review.md. Only builder joins mapping changes: token predecessor still binds collection packet/result/disposition/baseline, but no longer demands a collection-inventory.json member that TOKEN does not produce. The independently supplied collection-inventory remains mandatory and fully validated by the existing complete-history checks; it is now also byte-joined to the original training packet's actual collection-inventory.json capture. No invented member or upstream packet mutation. Launcher, monitor, argument interface, frozen child source, resources and science unchanged.

One NEW focused AST/metadata test passed; no closed tests repeated. It reads captured actual TOKEN/training producer rosters, exercises matching/mismatching independent inventory pins, proves the joins mapping is the sole builder AST change, and confirms launcher/monitor bytes unchanged. It executes only an isolated metadata assignment and fabricated validation, never a project or coordinator callable. Retained evidence: /Users/pat/.codex/tmp/ace-gpu-campaign-r1-check-q4zz1bf6. Runtime/custody/actual packet acceptance remains future. No build, remote action or commit.

Exact pins: handoff.json. Kuhn focused R1 recheck requested before use.
