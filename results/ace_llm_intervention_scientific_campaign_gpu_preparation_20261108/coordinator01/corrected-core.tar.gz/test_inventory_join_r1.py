import ast
import copy
from pathlib import Path
import unittest
HERE=Path(__file__).resolve().parent
class InventoryJoin(unittest.TestCase):
 def test_actual_producer_rosters_and_independent_inventory_pin(self):
  tree=ast.parse((HERE/'build_packet.py').read_text())
  assignment=next(n for n in ast.walk(tree) if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='joins' for t in n.targets))
  ns={};exec(compile(ast.Module(body=[assignment],type_ignores=[]),'isolated_metadata_join','exec'),ns)
  joins=ns['joins']
  token=ast.parse((HERE/'producer-snapshots/token-build.py').read_text())
  training=ast.parse((HERE/'producer-snapshots/training-build.py').read_text())
  def constants(t):return {n.value for n in ast.walk(t) if isinstance(n,ast.Constant) and isinstance(n.value,str)}
  self.assertNotIn('collection-inventory',constants(token))
  self.assertIn('collection-inventory',constants(training))
  self.assertNotIn('collection-inventory.json',joins['token'])
  self.assertEqual(joins['training']['collection-inventory.json'],'collection-inventory')
  pins={v:str(i).zfill(64) for i,v in enumerate(sorted({v for fields in joins.values() for v in fields.values()}),1)}
  packets={prefix:{n:pins[k] for n,k in fields.items()} for prefix,fields in joins.items()}
  def validate():
   for prefix,fields in joins.items():
    for name,key in fields.items():
     if packets[prefix][name]!=pins[key]:raise ValueError('independent pin differs')
  validate()
  packets['training']['collection-inventory.json']='f'*64
  with self.assertRaisesRegex(ValueError,'independent pin'):validate()
  # Confirm only the reviewed mapping changed; all other source AST stays identical.
  old=ast.parse((HERE/'predecessor/build_packet.py').read_text())
  for t in (tree,old):
   n=next(n for n in ast.walk(t) if isinstance(n,ast.Assign) and any(isinstance(x,ast.Name) and x.id=='joins' for x in n.targets));n.value=ast.Constant(None)
  self.assertEqual(ast.dump(tree),ast.dump(old))
  for name in ('launch_once.py','monitor_once.py'):
   self.assertEqual((HERE/name).read_bytes(),(HERE/'predecessor'/name).read_bytes())
if __name__=='__main__':unittest.main(verbosity=2)
