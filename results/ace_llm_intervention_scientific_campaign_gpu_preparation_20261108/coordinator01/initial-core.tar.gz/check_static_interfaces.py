"""Read-only AST/Git/JSON checks; never execute coordinator or production callables."""
from pathlib import Path
import ast,hashlib,json,subprocess,time,traceback
ROOT=Path(__file__).parent
REPO=Path('/Users/pat/code/ACE')

def sha(b):return hashlib.sha256(b).hexdigest()
def constants(path):
    tree=ast.parse(path.read_bytes());nodes={}
    for n in tree.body:
        if isinstance(n,ast.Assign):
            for t in n.targets:
                if isinstance(t,ast.Name):nodes[t.id]=n.value
    def get(key):return value(nodes[key])
    def value(n):
        if isinstance(n,ast.Constant):return n.value
        if isinstance(n,ast.Name):return get(n.id)
        if isinstance(n,ast.Dict):return {value(k):value(v) for k,v in zip(n.keys,n.values)}
        if isinstance(n,(ast.List,ast.Tuple,ast.Set)):
            vals=[value(x) for x in n.elts];return list(vals) if isinstance(n,ast.List) else tuple(vals) if isinstance(n,ast.Tuple) else set(vals)
        if isinstance(n,ast.Call) and isinstance(n.func,ast.Name) and n.func.id=='dict' and not n.args:return {k.arg:value(k.value) for k in n.keywords}
        raise ValueError('not a static constant '+ast.dump(n))
    return tree,get

out=ROOT/'metadata02';out.mkdir();start=time.monotonic();cpu=time.process_time();checks=[]
r=dict(target_execution=False,project_imports=False,remote_actions=0,packet_built=False,checks=checks)
try:
    trees={};pins={}
    for name in ('build_packet.py','launch_once.py','monitor_once.py'):
        data=(ROOT/name).read_bytes();(out/name).write_bytes(data);pins[name]=sha(data)
        tree,get=constants(ROOT/name);trees[name]=tree
        if name!='build_packet.py':ast.parse(get('REMOTE_COMMON' if name=='launch_once.py' else 'REMOTE'))
    checks.append('three coordinators and both embedded remote programs parse without execution')
    tree,get=constants(ROOT/'build_packet.py')
    fraw=(REPO/'results/ace_llm_intervention_scientific_contract_20261108/candidate03/scientific-freeze.json').read_bytes();f=json.loads(fraw)
    assert sha(fraw)==get('FIXED')['freeze'];s=next(s for s in f['stages'] if s['stage']=='gpu_campaign')
    assert s['entry']==get('ENTRY') and s['entry_sha256']==get('ENTRY_SHA') and s['remote_root']==get('ROOT')
    assert s['deadlines']==get('LIMITS') and s['wall_seconds']==get('RESOURCES')['wall_seconds']==2880
    assert {k:s[k] for k in ('account','partition','qos','memory_mib','gpus','gpu_type')}=={k:get('RESOURCES')[k] for k in ('account','partition','qos','memory_mib','gpus','gpu_type')}
    assert s['cpus']==get('RESOURCES')['requested_cpus']==get('RESOURCES')['max_allocated_cpus']==4
    checks.append('actual pinned freeze/entry/resource/limit interface matches exact2880-second GPU stage')
    closure=f['stage_closure']['stages']['GPUcampaign'];cc=f['stage_closure']['stages']['CPUcampaign']
    source=subprocess.check_output(['git','--no-replace-objects','show',get('SOURCE_COMMIT')+':scripts/research/'+get('ENTRY')],cwd=REPO)
    assert sha(source)==get('ENTRY_SHA')
    producer=ast.parse(source);astfields=next(n for n in ast.walk(producer) if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='fields' for t in n.targets) and isinstance(n.value,ast.Set))
    expected_fields=ast.literal_eval(astfields.value)
    make=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='make_packet')
    packet=next(n.value for n in ast.walk(make) if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='packet' for t in n.targets))
    assert {k.arg for k in packet.keywords}==expected_fields
    extra={'qualify_llm_intervention_scientific_campaign_gpu.py','qualify_llm_intervention_model_service.py','supervise_llm_intervention_checkpoint_gpu.py','llm_intervention_scientific_gpu_phase.py','llm_intervention_scientific_service_evidence.py'}
    assert set(closure['source_names'])==set(cc['source_names'])|extra
    assert set(closure['input_source_files'])==set(cc['input_source_files'])|extra
    checks.append('existing production packet exact-key schema and unchanged CPU+five-GPU source closure')
    cpu_root=Path('/tmp/ace-scientific-cpu-campaign-authoring-7sihtfq3')
    expected={'build_packet.py':'4f9aeefe929d89f70fd98a93d8368fbe1b150b4ef7189e2a7f258f306325e19e','launch_once.py':'d2b731024b9dbc567f5254fa6b9ba65875909a9309c4c0dec88c735cdc08cec0','monitor_once.py':'354cab58ecf5416293ee8464f133906d4cd05e6f080e47ff5a8160a0e93e0b5e'}
    for n,h in expected.items():
        data=(cpu_root/n).read_bytes();assert sha(data)==h;(out/('cpu-'+n)).write_bytes(data)
    cp=ast.parse((cpu_root/'build_packet.py').read_bytes());build=(ROOT/'build_packet.py').read_text()
    assert "gpuout=stages['gpu_campaign']['remote_root']+'/gpu'" in (cpu_root/'build_packet.py').read_text()
    assert "cpu_inputs=CPU_ROOT+'/inputs',cpu_output=CPU_ROOT+'/cpu'" in build and "gpu_inputs=ROOT+'/inputs',gpu_output=ROOT+'/gpu'" in build
    checks.append('stable CPU authoring pins and exact original CPU/service output path interface')
    p=json.loads((REPO/'results/ace_llm_intervention_scientific_collection_20261108/launch02/packet.json').read_bytes())
    for name,h in get('FIXED').items():
        if name=='operational-adoption-review':
            assert p['new_input_files']['operational-review.md']=='2d472a124d471c3ebe8fdcc9aaea2bdcec5a949486432ec26127886ca65952cc';continue
        file='failure-baseline.json' if name=='collection-failure-baseline' else name+('.md' if name=='freeze-review' else '.json')
        assert p['new_input_files'][file]==h,(file,h)
    checks.append('actual immutable collection02 authority names/pins, distinct prior design vs later adoption review')
    assert [(n,c,j) for n,_,c,j,*_ in get('STAGES')]==[('collection',42,86),('token',43,88),('training',44,90),('cpu',45,92)]
    remote=constants(ROOT/'launch_once.py')[1]('REMOTE_COMMON')
    assert "+17520<=57600" in remote and "+2880<=7200" in remote
    assert sum(isinstance(n,ast.Constant) and n.value=='sbatch' for n in ast.walk(trees['launch_once.py']))==0 # sbatch exists only in captured remote source text
    assert (ROOT/'launch_once.py').read_text().count("['sbatch','--parsable'")==1
    monitor=constants(ROOT/'monitor_once.py')[1]('REMOTE')
    assert 'gpu/controller/phase/' in monitor and 'telemetry-' in monitor and 'generation-' not in monitor and 'journal.jsonl' not in monitor
    checks.append('future45/92 admission, full remaining caps, one sbatch and bounded public monitor paths')
    r.update(status='passed',source_pins=pins,checks_count=len(checks),stable_cpu_interface_pins=expected)
except BaseException:
    r.update(status='failed',error=traceback.format_exc())
r.update(wall_seconds=time.monotonic()-start,process_cpu_seconds=time.process_time()-cpu)
(out/'receipt.json').write_text(json.dumps(r,indent=2,sort_keys=True)+'\n');print(json.dumps(r,indent=2))
if r['status']!='passed':raise SystemExit(1)
