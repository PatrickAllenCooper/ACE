from pathlib import Path
root=Path(__file__).parent
s=(root/'predecessors/training-launch_once.py').read_text()
s=s.replace('scientific GPU training','scientific GPU campaign').replace('accepted CPU tokens','accepted CPU campaign').replace('exact frozen scientific training','exact frozen scientific campaign')
s=s.replace("packet['schema']=='ace-scientific-training-gpu-launch-v1'", "packet['schema']==b.OUTER_VERSION")
s=s.replace("packet['deadlines']==b.DEADLINES","packet['limits']==b.LIMITS")
a=s.index("        prepared_raw=b.read(");z=s.index("        b.need(local==b.LOCAL",a)
s=s[:a]+"        ctx=b.authenticate(supplied);m=ctx['metadata']\n        cpu_data=b.admit_cpu_bytes(ctx,Path(packet['cpu_remote_custody']))\n"+s[z:]
s=s.replace("ctx['pins']['baseline']","ctx['pins']['cpu-baseline']")
s=s.replace("               and packet['collection_job_id']==m['collection-result']['job_id']\n",'')
s=s.replace("local/'inputs/training.json'","local/'inputs/packet.json'").replace("b.LOCAL/'inputs/training.json'","b.LOCAL/'inputs/packet.json'").replace("pins['inputs/training.json']","pins['inputs/packet.json']")
s=s.replace("b.make_packet(ctx,prepared_raw,packet['prepared_sha256'],packet['plan_sha256'],supplied)","b.make_packet(ctx,cpu_data,supplied)")
s=s.replace("'captured scientific training input/plan/resource contract differs'","'captured campaign input/resource contract differs'")
s=s.replace("baseline=m['baseline']","baseline=m['cpu-baseline']").replace("archive=stage['archive'],manifest=stage['manifest']","archive=m['cpu-packet']['archive'],manifest=m['cpu-packet']['manifest']")
s=s.replace("model_directory=stage['model_directory'],model_files=stage['model_files']","model_directory=m['cpu-packet']['model_directory'],model_files=m['cpu-packet']['model_files']")
s=s.replace("original_namespace_claim_sha256=b.ORIGINAL_CLAIM_SHA)","original_namespace_claim_sha256=b.ORIGINAL_CLAIM_SHA,\n            cpu_root=b.CPU_ROOT,cpu_roster={n.removeprefix('launch/'):v['sha256'] for n,v in ctx['observations']['cpu']['files'].items() if n.startswith('launch/')})")
s=s.replace("ace_llm_intervention_scientific_training_gpu*","ace_llm_intervention_scientific_campaign_gpu*").replace('existing training root','existing campaign GPU root').replace('ACE scientific GPU training readiness','ACE scientific GPU campaign readiness')
s=s.replace('resources=b.RESOURCES,deadlines=b.DEADLINES','resources=b.RESOURCES,limits=b.LIMITS')
s=s.replace("root/'training'","root/'gpu'").replace('existing training attempt','existing GPU campaign attempt')
s=s.replace('>=2700','>=2880').replace('2700s','2880s').replace("+14400","+15120").replace("+2700","+2880")
# Actual historical charge includes typed and aggregate GPU TRES without double-counting.
a=s.index(" need(sum(int(r[4])");z=s.index(" journals=",a)
s=s[:a]+" need(cost(rows)==(C['baseline']['closed_cpu_seconds'],C['baseline']['closed_gpu_slice_seconds']),'closed costs changed')\n need(C['baseline']['closed_cpu_seconds']+17520<=57600 and C['baseline']['closed_gpu_slice_seconds']+2880<=7200,'full remaining GPU/finalizer caps exceed budget')\n"+s[z:]
a=s.index('def duration(s):')
# Static source copy only, not import/execution.
b=(root/'build_packet.py').read_text();cost=b[b.index('def cost(rows):'):b.index('def history(')]
s=s[:a]+cost+s[a:]
a=s.index(" for path,h in C['cpu_inputs'].items():")
s=s[:a]+" cpu_root=pathlib.Path(C['cpu_root'])\n need(cpu_root.is_dir() and cpu_root==cpu_root.resolve(),'original CPU root alias/missing')\n members=list(cpu_root.rglob('*'))\n need(len(members)<=262144 and not any(p.is_symlink() for p in members),'bounded ordinary CPU custody required')\n need({str(p.relative_to(cpu_root)) for p in members if p.is_file()}==set(C['cpu_roster']),'complete original CPU custody roster changed')\n"+s[a:]
# Ensure exact admission bytes reconstructed, not just packet source inputs.
a=s.index("        b.need(packet['original_cpu_inputs']")
s=s[:a]+"        b.need(b.read(b.LOCAL/'inputs/admission.json',pins['inputs/admission.json'])==b.raw(b.admission(ctx,stage)), 'stage admission differs')\n"+s[a:]
(root/'launch_once.py').write_text(s)
