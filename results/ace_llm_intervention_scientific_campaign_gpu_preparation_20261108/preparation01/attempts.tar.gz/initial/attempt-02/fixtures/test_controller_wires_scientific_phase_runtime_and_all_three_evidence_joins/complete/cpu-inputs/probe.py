# inert toy packet probe, never executed
