"""New fabricated inventory-interface regressions only; no scientific payloads."""
from pathlib import Path
import ast
import copy
import hashlib
import importlib.util
import json
import unittest

spec=importlib.util.spec_from_file_location('collection_builder',Path(__file__).with_name('build_packet.py'))
b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)

class InventoryMetadata(unittest.TestCase):
    def fixture(self):
        root='/scratch/alpine/paco0228/ACE/results/ace_llm_intervention_scientific_realization_20261108_02'
        job='99999999';prefix='launch/realization/session/worker/task/'
        names=[prefix+'terminal.json','launch/submission.intent.json','launch/submission.result.json']
        names += [prefix+f'world-{i:03d}.json' for i in range(56)]
        names += [f'launch/fabricated-metadata-{i}.json' for i in range(331-len(names))]
        files={n:dict(bytes=100,sha256=hashlib.sha256(n.encode()).hexdigest()) for n in names}
        files[names[-1]]['bytes']+=5292431-sum(v['bytes'] for v in files.values())
        obs=dict(files=files,root_present=True,terminal_gate=True,parent_accounting=[job,'ace_llm_scientific_realize02',
            'COMPLETED','0:0','2','43','ucb736_asc2','cpu=2,mem=7.50G,node=1'])
        transport=dict(returncode=0,stdout=json.dumps(obs),stderr='',python_source=f'ROOT={root!r}\nJOB={job!r}\n')
        accepted=dict(job_id=job,realization_terminal_sha256=files[names[0]]['sha256'])
        disposition=dict(job_id=job,remote_root=root,output_root=root+'/realization',raw_files=331,raw_bytes=5292431)
        result=dict(job_id=job,intent_sha256=files[names[1]]['sha256'])
        return transport,accepted,disposition,result,files[names[2]]['sha256'],root

    def call(self,values,accepted_pin=True):
        transport,accepted,d,result,result_pin,root=values
        blob=b.raw(transport);h=b.sha(blob);accepted=copy.deepcopy(accepted)
        if accepted_pin:accepted['inventory_transport_sha256']=h
        return b.realization_files(blob,h,accepted,d,result,result_pin,root)

    def test_actual_shape_without_disposition_filemap(self):
        v=self.fixture();self.assertNotIn('remote_files',v[2])
        files=self.call(v)
        self.assertEqual(len(files),331);self.assertEqual(sum(x['bytes'] for x in files.values()),5292431)
        self.assertIn('launch/realization/session/worker/task/world-055.json',files)
        self.assertNotIn('remote_files',v[2])  # No repair or mutation of the supplied disposition.

    def test_independent_pin_and_transport_gate(self):
        v=self.fixture()
        for invalid in ({},{'inventory_transport_sha256':'f'*64}):
            with self.subTest(accepted=invalid),self.assertRaises(ValueError):
                q=list(copy.deepcopy(v));q[1].update(invalid);self.call(q,accepted_pin=False)
        for change in ('returncode','terminal_gate','root_present','observation_error'):
            q=list(copy.deepcopy(v));t=q[0];o=json.loads(t['stdout'])
            if change=='returncode':t[change]=1
            elif change=='observation_error':o[change]={'message':'incomplete'}
            else:o[change]=False
            t['stdout']=json.dumps(o)
            with self.subTest(change=change),self.assertRaises(ValueError):self.call(q)
        raw=b.raw(v[0]);a=dict(v[1],inventory_transport_sha256=b.sha(raw))
        with self.assertRaises(ValueError):b.realization_files(raw+' '.encode(),b.sha(raw),a,*v[2:])

    def test_literal_root_job_and_terminal_accounting(self):
        for change in ('wrong-root','wrong-job','duplicate-root','nonliteral-root','wrong-row','nonterminal'):
            q=list(self.fixture());t=q[0];o=json.loads(t['stdout'])
            if change=='wrong-root':t['python_source']=t['python_source'].replace(q[-1],'/different/root')
            elif change=='wrong-job':t['python_source']=t['python_source'].replace(q[3]['job_id'],'123')
            elif change=='duplicate-root':t['python_source']+='ROOT='+repr(q[-1])+'\n'
            elif change=='nonliteral-root':t['python_source']='ROOT=str("/not-executed")\nJOB="99999999"\n'
            elif change=='wrong-row':o['parent_accounting'][0]='123'
            else:o['parent_accounting'][2]='RUNNING'
            t['stdout']=json.dumps(o)
            with self.subTest(change=change),self.assertRaises(ValueError):self.call(q)

    def test_count_bytes_and_three_required_pin_joins(self):
        for change in ('count','bytes','terminal','intent','result'):
            q=list(self.fixture());t=q[0];o=json.loads(t['stdout'])
            if change=='count':q[2]['raw_files']-=1
            elif change=='bytes':q[2]['raw_bytes']-=1
            else:
                name={'terminal':'launch/realization/session/worker/task/terminal.json',
                      'intent':'launch/submission.intent.json','result':'launch/submission.result.json'}[change]
                o['files'][name]['sha256']='e'*64
            t['stdout']=json.dumps(o)
            with self.subTest(change=change),self.assertRaises(ValueError):self.call(q)

if __name__=='__main__':unittest.main(verbosity=2)
