# Generic scientific collection packet authoring — NOT a concrete launch handoff

2026-11-08. Concrete finalization is paused at the parent's request. The parent reports realization35402725 failed after4s at the strict resolved-output guard, before output creation, with no scientific draw yet established pending independent failure audit. Its39 jobs/80 journals and11048 CPU/1601 GPU seconds must remain in the eventual chain. Those reported facts are not manufactured into an acceptance or baseline here.

The pre-amendment drafts are preserved in `pre-infra-amendment/`, and their syntax evidence remains in `static01/`. Current scripts remove the concrete57a3/f97cb/35402725 acceptance assumptions. Amended full freeze/source/root/namespace pins and successful realization acceptance remain absent. `static02-generic/` contains source snapshots and syntax-only results. No builder, launcher, monitor, project helper, model, tokenizer, world generation, collection, remote action or test suite ran. No repository source, Git index or commit was changed.

## Draft files

- `build_packet.py` SHA256 `7d61650559abc5dbcb9ef0179f7670209a0b0a23ad279be966d13c1452c1a4d5`.
- `launch_once.py` SHA256 `53cc4416cfd4518c8dc17549b88e3d6efb3623896b84ed07ec1d4b485db62d54`.
- `monitor_once.py` SHA256 `b621addc3df3af1013543189dac03941f5cf3a131c8a688351e7c66cf48658d6`.

These are generic authoring pins only. Path semantics remain subject to the parent's infrastructure correction and independent review; this draft does not choose `/scratch` versus `/gpfs` or qualify either on compute nodes. Parent owns the original realization launcher/monitor timeout fixes and collector semantic-intent correction; none of those files were edited for this collection task.

## Proposed builder API

Each of the following is a **required** `--NAME PATH --NAME-sha256 SHA256` pair:

```
freeze
freeze-review
adoption
namespace-admission
namespace-claim
realization-acceptance
realization-disposition
baseline
predecessor-baseline
realization-packet
realization-result
```

Also require `--realization-task PATH`, pointing to the accepted local custody task directory. No science data exists or is read during authoring. The future builder opens only its `terminal.json` and exactly `world-000.json`..`world-031.json`. It does not traverse the task directory, open world032..055, invoke realization, or import project/scientific modules. Complete56-entry terminal metadata establishes original IDs/order without exposing development coefficients.

The combined contract supplies `source_commit`, source/helper pins, `stage_closure.stages.collect`, `original_proposal`, `stages.collect`, `stages.realize` and runtime metadata. Sources, including CPU03's probe artifact, are read from the full frozen Git commit using `--no-replace-objects`. The corrected narrow AST constant resolver handles named helper dictionary keys without module execution. The collect stage remains exactly23 source files,900s,2CPU,7680MiB,zeroGPU,asc2/acpu/cpu-normal,no-requeue, with startup120/work850/cleanup875/hard890. No concrete entry/source pin is silently substituted for the future amendment.

The plain-JSON `configuration(row)` function mirrors the existing pinned `assembly_recipe`/`configuration_payload` public fields; it does not call either helper or fit anything. The actual worker revalidates each configuration pin before collection. All32 training rows,160 snapshots and3584 planned pairs are retained;9216 response attempts and10240 cost units remain caps, not observed success claims.

## Existing acceptance and baseline joins

The realization acceptance must contain the unchanged CPU outer's required fields:

- `status="accepted"`, integer `required_findings=0`, `complete_custody_verified=true`.
- `realization_terminal_sha256`, `freeze_sha256`, `namespace_admission_sha256`.

This draft additionally requires these metadata joins (extra unrelated acceptance metadata is allowed): `job_id`, `disposition_sha256`, `namespace_claim_sha256`, `realization_packet_sha256`. They refer to the separately independently pinned inputs above. The actual result must be unambiguous; the disposition must establish matching custody, source/input lineage, namespace, exact prior rows/journals, requested/actual resource match and `COMPLETED 0:0`. Failed35402725 cannot satisfy this acceptance gate. No acceptance is written by these scripts.

`predecessor-baseline` is the independently supplied baseline frozen before the later successful realization, including retained earlier failures. Its pin must match `freeze.admission_accounting.baseline_sha256`. `baseline` is the independently supplied accepted post-realization record, never generated here. Required fields follow the existing baseline pattern: `terminal_jobs`, `submission_journals`, `related_accounting`, `journal_pins`, `closed_cpu_seconds`, `closed_gpu_slice_seconds`, `cpu_admission_seconds`, `preparation_allowance_cpu_seconds=3600`, `outstanding_reservation=0`, caps57600/7200. `input_pins.predecessor`, `.acceptance` and `.disposition` bind the predecessor and the actual realization acceptance/custody.

The post-realization baseline must be the exact predecessor row/pin set plus one actual accepted job and its two journals. Counts and charges derive from those supplied records. There is no assumed39/80 successful baseline or invented future40/82 record. Existing failed jobs/journals cannot be omitted, and the live coordinator must reconcile the entire actual chain twice.

The namespace descriptor and claim are the originals of the eventual **successful** independently accepted realization. They bind its packet, freeze, ordered32/24 IDs, and explicitly supplied registry locations. Existing local and remote claim bytes must agree with that independent pin. Neither builder nor launcher creates, changes, adopts a new, or deletes any namespace registry. Earlier failed-attempt registries are untouched.

## Packet layout / future launcher

Roots come from the amended frozen `stages.collect` row: repository_root/launch01, exclusive_external_root and remote_root. The output is `ROOT/collection`. The root `packet.json` is the outer launch manifest; `inputs/packet.json` and `inputs/admission.json` are the fixed-mode CPU supervisor packet/admission. `inputs/collection-packet.json` and `inputs/collection-admission.json` are the inner collection glue inputs, whose exact output is `ROOT/collection/session/worker/task`. Raw charged collection evidence remains below `.../task/collection`. The supervisor input roster is60 files:23 captured sources plus37 required data/inner admission files. No development payload is included.

Future launcher API, after independent concrete packet review and parent commit:

```
python3 -B <PACKET>/launch_once.py --packet-directory <PACKET> \
  --packet-commit FULL_COMMIT --packet-sha256 OUTER_SHA \
  --packet-review COMMITTED_REVIEW --packet-review-sha256 REVIEW_SHA
```

Both existing coordinator locks cover authentication, readiness, transfer/readback and ONE sbatch. The launcher compares all original accounting rows/full journal pins, current accepted namespace and original accepted32 training files/terminal twice, requires no active ACE job and live resource feasibility, and checks complete current packet bytes. It uses the supplied actual baseline plus only1800 CPU/0 GPU reservation and existing3600 preparation allowance. All costs/failures stay represented. Exclusive roots/intents prohibit retries. Failed and ambiguous transports/submission preserve available stdout/stderr and intent evidence; no registry is recreated or replaced.

Future monitor API adds `--packet-directory <PACKET>` to `--packet-sha256`, `--submission-result-sha256`, `--evidence-directory NEW_EXCLUSIVE_DIR`. It performs one read-only scheduler/output-marker observation, preserves timeout output and never accepts a run or reads scientific outcome JSON. No collection terminal collector is authored in this scope.

## Remaining parent inputs

Resolve and independently review the infrastructure/path amendment and original failure audit; supply the successor full freeze/adoption/source closure and predecessor baseline; execute and independently accept a successful realization under that contract; then supply its accepted task bytes, claim, disposition, packet/result and post-realization baseline. Only then align any changed metadata fields/path semantics, finalize/review the concrete collection packet, and consider submission. This authoring handoff authorizes none of those actions and does not ask for new scientific tuning or model work.
