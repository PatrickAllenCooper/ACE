# Collection02 operational consumer interface (authoring, not authority)

Existing13 metadata pairs from collection01 remain required, including original freeze/adoption/namespace, accepted realization, baseline40 and predecessor39. Additional required `--NAME PATH --NAME-sha256 SHA256` pairs:

- collection-failure-acceptance
- no-response-proof
- failure-baseline
- failure-disposition
- failure-inventory (terminal01/inventory_transport.json)
- failure-readback (terminal01/inventory_after_transport.json)
- failure-custody-inventory (terminal01/custody-inventory.json)
- operational-amendment
- operational-review
- operational-guide
- diagnosis

Also `--failure-custody PATH` to the complete accepted terminal01 capsule, and existing `--realization-task PATH` to accepted realization02 task custody. No build may run until independent failure acceptance, no-response proof, actual41/84 baseline and reviewed authority exist. All unknown pins below are mandatory independently supplied values, never defaults.

`operational-amendment` must equal this exact object (extra keys rejected); replace placeholders with independently authenticated file hashes. `failed_packet_sha256` is the original failed outer packet pin from disposition. Original freeze/adoption and both namespace claims are unchanged; this is an additional collection-only authority, not a rewritten scientific freeze.

```json
{
  "schema": "ace-scientific-collection-operational-amendment-v1",
  "status": "adopted",
  "stage": "collect",
  "recovery_id": "collection02",
  "freeze_sha256": "15602614ef9d7e9a3e21027e7495f891c98ba32a2b6b0ee9857e5b71d5e5e66d",
  "source_commit": "a9346022f145cc29439325b6f291597b2e6ec037",
  "entry_sha256": "e5235f16dd17c72e0310004e7bd8df636008c789db8f793212d528fabfd587f8",
  "failed_job_id": "35407428",
  "failed_packet_sha256": "<SHA256 of packet_sha256>",
  "failed_root": "/scratch/alpine/paco0228/ACE/results/ace_llm_intervention_scientific_collection_20261108_01",
  "recovery_root": "/scratch/alpine/paco0228/ACE/results/ace_llm_intervention_scientific_collection_20261108_02",
  "failure_acceptance_sha256": "<SHA256 of collection-failure-acceptance>",
  "no_response_proof_sha256": "<SHA256 of no-response-proof>",
  "failure_disposition_sha256": "<SHA256 of failure-disposition>",
  "failure_inventory_sha256": "<SHA256 of failure-inventory>",
  "failure_readback_sha256": "<SHA256 of failure-readback>",
  "failure_custody_inventory_sha256": "<SHA256 of failure-custody-inventory>",
  "baseline_sha256": "<SHA256 of failure-baseline>",
  "realization_acceptance_sha256": "<SHA256 of realization-acceptance>",
  "realization_baseline_sha256": "<SHA256 of baseline>",
  "namespace_admission_sha256": "<SHA256 of namespace-admission>",
  "namespace_claim_sha256": "<SHA256 of namespace-claim>",
  "original_namespace_claim_sha256": "58033e812390731ad08c83b7236e6e47893de3a3488cf4602d5c42809a51fa29",
  "original_deadlines": {
    "startup": 120,
    "work": 850,
    "cleanup": 875,
    "hard": 890
  },
  "deadlines": {
    "startup": 300,
    "work": 850,
    "cleanup": 875,
    "hard": 890
  },
  "resources": {
    "account": "ucb736_asc2",
    "partition": "acpu",
    "qos": "cpu-normal",
    "cpus": 2,
    "memory_mib": 7680,
    "gpus": 0,
    "requeue": false,
    "wall_seconds": 900
  },
  "review_sha256": "<SHA256 of operational-review>",
  "guide_sha256": "<SHA256 of operational-guide>",
  "diagnosis_sha256": "<SHA256 of diagnosis>",
  "required_findings": 0,
  "scientific_inputs_unchanged": true,
  "other_stages_unchanged": true,
  "one_submission_only": true,
  "automatic_retry_allowed": false,
  "replacement_worlds_allowed": false
}
```

Published failure records are consumed unchanged. Acceptance exact pin `00c4557a5c681904e823441ac8bb99f4dc5e169c0c7e41e764018a1e4e7af5ee`: schema `ace-scientific-collection-failure-acceptance-v1`, status `accepted_failed_before_response`, job_id `35407428`, failure_accepted true, collection_accepted false, required_findings0, complete_custody_verified true, source_control_flow_and_traceback_verified true, two_remote_inventories_matched true. Transport/custody hashes are read from its existing `evidence_pins` map, not invented top-level fields. It has owned_worker_spawned false and collection_invoked false.

Proof exact pin `59c21d63644cf7ae9765b3ff374538f2c614694dc383583f1e7661c301700998`: existing status `verified_failed_before_collection_worker`, failed_job_id `35407428`, failure_acceptance_sha256 and accounting_sha256 join the above records; source_commit and source_pins[CPU entry] join originala934/e523, freeze_sha256 original156026 and realization_acceptance_sha256 original5e28. The existing proof has no schema field; none is required or manufactured. Its nested proof.owned_worker_not_spawned, collection_not_invoked, worker_session_not_created and synchronous_stage_did_not_return must be true. Exact zeros in both published records: environment_response_attempts, environment_responses, unknown_return_attempts, scientific_worlds_generated, records_created, pairs_created, scientific_response_cost_units, training_updates; proof additionally model_loads/tokenizer_calls/policy_updates0. Missing or unknown charges reject.

Both published records retain `node_local_partial_runtime_cleanup_verified=false` and `runtime_qualified_for_this_execution=false`; recovery does not upgrade them. The signal number was not explicitly recorded; startup SIGALRM is strongly supported, not treated here as a directly observed fact. Published failure/proof fields are not changed, supplemented, or replaced by this coordinator.

Failure baseline follows existing actual-accounting fields,41jobs/84journals,11386CPU/1601GPU,14986CPU including3600prep,0outstanding. Required `input_pins.predecessor`=original40baseline69cc..., `.acceptance`=new failure acceptance, `.disposition`=failed disposition. Full rows/journals must be unchanged40 plus failed35407428; both inventory readbacks must match all146raw/2336700bytes. The existing accepted realization5e28... and40baseline69cc... remain separately authenticated.

Newpacket root collection02, launch02/external-02. Inner collection packet and every training/source/realization input must equal original failed input byte pins. Only collection admission output and parent output/deadline/path change. No new namespace, response, world, method or production source.

The supplied operational review must be exact SHA `2d472a124d471c3ebe8fdcc9aaea2bdcec5a949486432ec26127886ca65952cc`; diagnosis exact SHA `61dc39510dfa1d50787ba451f90b180f275e057fadf670422f55729d50b28e24`.

Actual failure baseline exact pin: `eeec362db1990d5cf1fb7945708293842dc9b9283a2777697e6840ad5a2c147b`. Authority fields above are unchanged after alignment to published audit schemas.
