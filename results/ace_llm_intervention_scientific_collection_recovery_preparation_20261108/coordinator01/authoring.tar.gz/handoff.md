# Collection02 recovery coordinator handoff

Stable BUILD/LAUNCH/MONITOR and collector authoring, ready for independent coordinator review. All four source files are complete. No actual packet build, remote call, submission, descriptor read, response, model/tokenizer, production-source edit or commit occurred. Original collection01 tree remains frozen. The partial GPU authoring remains untouched after its explicit NOT_READY.json note at `/tmp/ace-scientific-training-gpu-packet-authoring-m82o03gg`.

## Exact authority and preserved scope

Original scientific freeze15602614... and sourcea9346022... remain unchanged. Source entrye5235f16... and collection2bc87234... remain unchanged. Accepted realization5e28e1aa... and its40/82 baseline69cc9778... are authenticated as original inputs. Both existing namespace claims remain read-only. No world regeneration, new namespace, replacement input or method change.

Only collection startup120→300 and exclusive collection02 root differ. Work850/cleanup875/hard890 retain the same absolute start;2CPU7680MiB900sec,zeroGPU,asc2/acpu/cpu-normal,no-requeue remain unchanged. All remaining stage caps remain frozen. Inner collection packet and every original training/source/realization input are checked against the accepted failed attempt byte pins; only the collection admission output and supervisor output/deadline/path change.

Operational authority exact SHA `fa94858dfc19c8b15c82acde167ad8fe9991d0c863c32444d017743079617855` is supplied independently. Parent reports exact-amendment review0required SHA `db2a672a4f0222a06a46d1e61ebc5bdc22b869640f570e19d36a0f699a1ddbaf`; authority bytes themselves are not rewritten. Its original design-review binding2d472... is preserved. Consumer interface and authority fields are in `consumer-interface.md`.

Actual failure acceptance00c455..., no-response proof59c21..., baselineeeec... use their published schemas/fields; no fictional fields were added. Unknown/nonzero response attempts/costs or any worker/collection invocation reject. Worker/session absence is corroboration, not sole proof; the independent source/traceback boundary is required. Node-local partial runtime cleanup remains unverified and the failed runtime unqualified. Startup SIGALRM is strongly supported, not explicitly recorded.

Failure baseline includes all41jobs/84journals,11386CPU/1601GPU,3600prep,0outstanding. New1800CPU/0GPU reservation admits16786CPU/1601GPU. Full unchanged remaining-stage ceilings are checked against57600CPU/7200GPU; no failed cost disappears.

## Consumer API

Builder keeps all13 original metadata path+SHA pairs and adds required pairs for:
`collection-failure-acceptance`, `no-response-proof`, `failure-baseline`, `failure-disposition`, `failure-inventory`, `failure-readback`, `failure-custody-inventory`, `operational-amendment`, `operational-review`, `operational-guide`, `diagnosis`.

Each is `--NAME PATH --NAME-sha256 SHA256`. Also supply `--failure-custody` pointing to complete accepted collection01 terminal capsule, plus existing `--realization-task` for accepted realization02 task custody. The child still receives only32 training descriptors; development payloads are neither opened nor staged. Existing metadata pair names remain as documented in the reviewed collection01 handoff.

The only filename alias in amendment01 is `failure-acceptance.json` → CLI `--collection-failure-acceptance`. `operational-review` is the unchanged design review pinned by the authority. The separate exact-amendment review is retained by parent and the concrete coordinator/packet review process; no new field is imposed on the exact authority object. The diagnosis clarification remains outside that immutable authority as parent recorded it.

Launch API unchanged: `--packet-directory`, `--packet-commit`, `--packet-sha256` (outer), `--packet-review`, `--packet-review-sha256`. Existing two locks cover full committed packet authentication, exact41 rows/all84 journals, no active ACE, site feasibility, namespace/realization pins and all146 failed raw objects, twice before ONE sbatch. Only the accepted failed collection01 root may preexist. Existing/ambiguous attempts are preserved; no blind retry. Remote original failed root is read-only.

Monitor API unchanged: `--packet-directory`, `--packet-sha256`, `--submission-result-sha256`, `--evidence-directory` exclusive. Monitor bytes are unchanged from01 and use the new pinned packet root.

## Paths and complete collector

New remote root `/scratch/alpine/paco0228/ACE/results/ace_llm_intervention_scientific_collection_20261108_02`; repository `results/ace_llm_intervention_scientific_collection_20261108/launch02`; external `ACE-LLM-intervention-scientific-collection-20261108-02`. No original01 mutation.

Output remains `ROOT/collection`; worker task `ROOT/collection/session/worker/task`; raw charged collection `.../task/collection`. Outer `ROOT/packet.json`; supervisor `ROOT/inputs/packet.json`; inner collection `ROOT/inputs/collection-packet.json`.

Collector CLI unchanged: `--job-id`, `--packet-sha256` (outer), `--submission-result-sha256`. Destinations repositoryterminal02/external `ACE-LLM-intervention-scientific-collection-terminal-20261108-02`. Copies complete current ROOT to remote/launch and complete failed01 ROOT to remote/failed01, plus both namespace claims and coordinator histories; two full remote inventories/readbacks and independent two-copy custody. Failed146-file roster maps exactly against accepted inventory, including all55 old phase records. New actual terminal accounting must preserve41/84 plus current job/two journals (42/86). All source, runtime, cleanup, logs, response attempts/failures are retained. Public160-record/3584-pair and charge reports remain metadata, not independent acceptance. Missing counts remain unresolved, never zero. Collector does not revisit development payloads or upgrade old cleanup. Recovery authority and no-response evidence remain bound in its disposition.

## New bounded verification

`metadata01/` retains exact source snapshots, checker, stdout/stderr and receipt. The checker invoked only the NEW recovery metadata validator on independently pinned published records; it did not call builder main/admit, source helpers, descriptor readers, build, launch, monitor or collector. All146 objects/2336700bytes metadata and exactauthorityfa948... matched. All four scripts and embedded remote snippets parsed/compiled. No old tests or reviews repeated. This is interface verification, not independent coordinator review or execution qualification.

Predecessor01 scripts are preserved byte-for-byte in `predecessor01/`; the earlier hypothetical failure schema/interface is preserved in `before-actual-proof-schema/`. Complete diff: `collection02-vs01.diff`.

## Stable source pins

- `build_packet.py`: `a4e58643fee5feef49d52d332cf7fd01ded7e02da9cadc37b5a928b4a4adbb6e`
- `launch_once.py`: `0286fbf3f53b8806f0a54d297d4d92bf24b9d8bdb03e5fc045b3681bd0b4a61f`
- `monitor_once.py`: `b621addc3df3af1013543189dac03941f5cf3a131c8a688351e7c66cf48658d6`
- `pull_terminal.py`: `5d2bdfdfb47d1d728c5d3d5823f322cd378804979de1dd084a77f7e5ddf0974e`
