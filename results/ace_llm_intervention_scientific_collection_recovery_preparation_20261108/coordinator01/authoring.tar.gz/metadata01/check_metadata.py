from pathlib import Path
import ast,hashlib,importlib.util,json,time
root=Path(__file__).resolve().parent
start=time.monotonic();cpu=time.process_time()
spec=importlib.util.spec_from_file_location('new_recovery_metadata',root/'build_packet.py');b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
original=Path('/Users/pat/code/ACE/results/ace_llm_intervention_scientific_collection_20261108/launch01')
amendment=Path('/Users/pat/code/ACE/results/ace_llm_intervention_scientific_collection_recovery_preparation_20261108/amendment01')
supplied={};paths={}
for name in b.METADATA:
 filename=('failure-acceptance' if name=='collection-failure-acceptance' else name)+('.md' if name in ('freeze-review','operational-review','operational-guide') else '.json')
 path=(amendment if name in b.RECOVERY_METADATA else original)/filename
 supplied[name]=path.read_bytes();paths[name]=str(path)
pins={n:b.sha(v) for n,v in supplied.items()}
assert pins['operational-amendment']=='fa94858dfc19c8b15c82acde167ad8fe9991d0c863c32444d017743079617855'
assert all(pins[n]==h for n,h in b.EXPECTED_METADATA_PINS.items())
m={n:b.decode(v) for n,v in supplied.items() if n not in ('freeze-review','operational-review','operational-guide')}
b.SOURCE_COMMIT=m['freeze']['source_commit'];b.FREEZE_SHA=pins['freeze']
result=b.validate_collection_recovery(supplied,m,pins)
for name in ('build_packet.py','launch_once.py','monitor_once.py','pull_terminal.py'):
 tree=ast.parse((root/name).read_bytes());compile(tree,name,'exec')
 for node in ast.walk(tree):
  if isinstance(node,ast.Constant) and isinstance(node.value,str) and node.value.lstrip().startswith(('import pathlib,','from pathlib import Path\n','need(root.parent','need(not os.path.lexists(root/')):
   compile(node.value,name+':embedded','exec')
print(json.dumps(dict(scope='Only NEW metadata consumer joins and syntax; no builder main, descriptor reads, source helpers, remote actions or stage execution',matched=True,authority_sha256=result['authority_sha256'],raw_files=len(result['files']),raw_bytes=sum(v['bytes'] for v in result['files'].values()),metadata_paths=paths,metadata_pins=pins,source_pins={n:b.sha((root/n).read_bytes()) for n in ('build_packet.py','launch_once.py','monitor_once.py','pull_terminal.py')},wall_seconds=time.monotonic()-start,process_cpu_seconds=time.process_time()-cpu,independent_acceptance=False,packet_builds=0),indent=2))
