fixture_value = 1
