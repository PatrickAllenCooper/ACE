# Scientific CPU preparation glue — review handoff

Only two new repository files; no closed helpers or collection-wrapper source changed, no commit. Independent review and actual scientific CPU preparation remain outstanding.

## Stable source pins

- `scripts/research/prepare_llm_intervention_scientific_training_cpu.py`: `225c89d322d7c312da5d2e242db068129cb83f6e0b728a0c6c211dcee0804838`
- `scripts/research/test_prepare_llm_intervention_scientific_training_cpu.py`: `6d029232508d10410ff1bf34218957c87063655a9b7ec3c9c7938c771ca6d800`

## Verification retained

`attempt02/run.json`, `stderr.log`, `stdout.log`, `source-pins.json`, source-before/source-after snapshots, original proposal bytes and all fabricated test artifacts are preserved. 16/16 new stdlib-only tests passed; 0.746272583 wall seconds, 0.715337 CPU seconds, 40,943,616 bytes peak RSS on macOS. No source changed during execution. Earlier 14-test passing run remains in attempt01; inspection-attempt01.json retains the failed static AST inspection. No failed test run is hidden or overwritten. No old tests, actual tokenizer, model, scientific world/response, remote operation or entrypoint execution ran.

Tests cover complete 160/3584 association; strict exposure D=128, partial D=7 and retained D=0 failure before tokenizer creation; unchanged bridge mode and matched numerical exposure; token/EOS/context and raw-record binding; changed/reordered/missing records/pairs/receipts; acceptance/source/namespace/accounting gates; exact six-file token directory; full-tree mutations/symlinks; explicit CPU-only allocation contract; caller deadlines, cleanup-before-validation, changed packet, exclusive failure publication and static project import closure. Engine/exposure/ranker/tokenizer APIs are explicit doubles; they do not certify real tokenizer results or end-to-end staged runtime execution.

## Packet and launch integration

Entrypoint CLI (future admitted execution only):

`<staged-or-parent-python> -I -B -c <accepted diagnostic BOOTSTRAP> <flat-inputs>/prepare_llm_intervention_scientific_training_cpu.py <entry-byte-sha256> --packet <flat-inputs>/packet.json --packet-sha256 <independent-packet-byte-sha256> --source-commit <full-captured-commit> --output <new-exclusive-output>`

No resource defaults authorize execution. Caller provides exact `resources` (account ucb736_asc2, partition acpu, qos cpu-normal, cpus, memory_mib, wall_seconds, gpus=0, requeue=false) and absolute-from-parent-start `deadlines` (startup < work < cleanup < hard < wall). Actual allocation is checked before child launch; accepted archive staging, full CPU runtime checks and owned-group cleanup are reused. Entry and closure must be captured from the supplied committed revision by the outer builder; the entry cannot independently prove Git ancestry from a flat directory.

Packet schema `ace-scientific-training-preparation-cpu-v1`; exact fields/rosters are PACKET_KEYS and packet_shape() in source. `files` is a flat byte-pin map for the source closure, pinned closed helpers (including externally supplied probe.py), proposal.json and collection-acceptance.json. `source_names` is sorted(service.SOURCE_NAMES union EXTRA_SOURCES). Original proposal byte and semantic pins remain distinct and fixed. Original twelve-path protocol pins remain distinct from current execution-source pins. Archive, manifest and original-runtime identity use the existing diagnostic's fixed accepted pins.

`collection.root` must be the original inner collector tree, i.e. the collection/ directory from the new wrapper, containing intent.json, plan.json, inventory.json, terminal.json and all original journals/rows. Its complete file byte-pin map is `collection.files`. The separate pinned acceptance is schema `ace-scientific-collection-acceptance-v1`, status accepted, required_findings integer zero, scope policy_train, complete_custody_verified=true, accounting_complete=true, and `collection` exactly equals the packet object. That object additionally binds freeze_sha256, realization_acceptance_sha256, world_pins, configuration_pins, source_pins and namespaces. Parent's independent acceptance must establish wrapper/runtime/custody/accounting and provide this contract; a collection exit/terminal alone is insufficient. No acceptance is manufactured here.

Use mutually disjoint absolute flat-input, original-collection, six-file tokenizer and output directories (siblings are fine). This is stricter than launch layouts that place output beneath flat inputs. Stage exactly config.json, generation_config.json, tokenizer_config.json, tokenizer.json, merges.txt and vocab.json. Keep the accepted seven-file map including the known model.safetensors hash only in `model_files`; tokenizer identity is its semantic digest. No weights or adapters may be in the staged tokenizer directory. Loading is local-only and trust_remote_code=False.

## Outputs and limits

Success retains original selected core/record/receipt bytes, fixed exposure, complete LLM plan and matched numerical plan, runtime evidence, allocation/stage/cleanup evidence and terminal byte pins. Whole original collection tree remains immutable and checked before/after, including journals. Both plans retain all records/unexposed pairs. 160 SFT then D strict DPO pairs (1..128), checkpoints (159,159+D), explicit qwen_screen_singletons / canonical_selected_unpadded. D=0, overflow or any later failure retains evidence without recollection. Preparation performs no fit, responses or model loading; qualification flags remain false.

Bounds: original tree <=65,536 files / 2 GiB, individual tree file <=64 MiB; each record <=1 MiB, all record+receipt bytes <=64 MiB; stored tokens <=4,194,304; output readers <=256 MiB; flat-source/packet captures <=16 MiB per file. These are explicit safety limits, not measured full-run capacity guarantees. Actual future runtime/tokenization, resource sizing, independent acceptance and packet review are required. Pipeline doubles do not substitute for those checks.
