# First scientific tokenization — source preparation only

Ready for independent authoring review, 2026-11-08. Three future scripts only; no packet build, registry/output claim, runtime staging, tokenization, model-weight read, scientific draw, remote command, submission or commit was performed. No project callable was invoked. Actual collection acceptance and the next accounting baseline are still required before building. No fake acceptance, job ID, elapsed time, cost or future pin is supplied.

## Files and exact scope

- `build_packet.py`: future local builder; metadata authentication, opaque local collection-custody hashing, six public tokenizer file copies, committed source capture, exclusive two-copy publication under both existing controller locks. No remote operation even during future build.
- `launch_once.py`: future once-only launcher; committed concrete packet/review, both locks, two full live reconciliations and byte readbacks, one sbatch, retained ambiguity without retry. Existing original/recovery registries remain read-only.
- `monitor_once.py`: future single bounded scheduler/output-marker observation; no output JSON decode, scientific acceptance or retry.
- `static01.json`: retained syntax-only AST/compile result, including embedded remote Python; no tests or target execution.
- `predecessors/`: independent byte copies of the nearby collection authoring patterns used for derivation. Originals were not edited. The older screen-prompt CPU authoring was read for comparison; no code from its project-importing builder/readiness is executed here.
- `derivation.json`, `inventory.json`: authoring provenance and byte pins, not a scientific admission schema.

All final pins are in `inventory.json`. Authoring location is exclusive `/tmp/ace-scientific-tokenization-authoring-nvsnb064`. No repository source/helper or accepted artifact was changed, and no new worker helper closure file was added.

## Fixed adopted contract

Freeze `15602614ef9d7e9a3e21027e7495f891c98ba32a2b6b0ee9857e5b71d5e5e66d`, source commit `a9346022f145cc29439325b6f291597b2e6ec037`, entry `prepare_llm_intervention_scientific_training_cpu.py` SHA256 `47bbf574269b9187f1237e4a9731115228b06bbb5ab65937df3e0f14bd37b8f3`. Candidate03 `stage_closure.token` supplies exactly32 production source files;28 are `source_names`, four helpers sit outside that work roster. The builder captures sources from Git with replacement objects disabled and uses static constant extraction only.

Profile:3CPU,11520MiB,600s,zeroGPU,ucb736_asc2/acpu/cpu-normal,one node/task,no requeue; startup120/work550/cleanup570/hard590. CPU reservation1800 seconds. Admission is **actual accepted closedCPU +3600 preparation +1800 reservation**, with actual closedGPU unchanged and ceilings57600CPU/7200GPU. No future collection charge is inferred. Parent reports actual realization02 acceptance/baseline now exist (40jobs/82journals,11134CPU/1601GPU), but complete independent CLI pins remain required; these reported costs and abbreviated pins are not embedded as defaults.

Future locations, copied from the frozen tokenize stage:

- ROOT `/scratch/alpine/paco0228/ACE/results/ace_llm_intervention_scientific_tokenization_20261108_01`.
- Repository `results/ace_llm_intervention_scientific_tokenization_20261108/launch01`.
- External `ACE-LLM-intervention-scientific-tokenization-20261108-01` under the established results BASE.
- Worker packet `ROOT/inputs/packet.json`;34 worker file pins =32 sources + unchanged proposal + independent collection acceptance. There is **no separate worker admission file/CLI argument**: the frozen preparer's exact `PACKET_KEYS` is used.
- Outputs `ROOT/preparation`; child `ROOT/preparation/session/worker`; prepared artifacts `.../worker/artifacts/{exposure.json,llm-prepared.json,numerical-plan.json,terminal.json}` as actually produced. Candidate/failure/partial outputs must be preserved too.

## Required future builder arguments

For **every** name below provide `--NAME PATH --NAME-sha256 FULL_SHA256` (no defaults):

```
freeze                 freeze-review
adoption               namespace-admission
recovery-authority     failure-baseline
namespace-claim        realization-acceptance
realization-disposition realization-packet
realization-result     realization-baseline
collection-acceptance  collection-disposition
collection-packet      collection-result
baseline
```

Additionally:

- `--collection-custody PATH`: independently retained **raw policy_train collection subtree**, corresponding exactly to remote `...scientific_collection_20261108_01/collection/session/worker/task/collection`. The builder hashes its entire accepted map, bounded at65536 regular files/2GiB/64MiB per member; no record/receipt payload is decoded or copied into a new private subset.
- `--tokenizer-directory PATH`: local snapshot containing exactly `config.json`, `generation_config.json`, `tokenizer_config.json`, `tokenizer.json`, `merges.txt`, `vocab.json`. Each file must match the frozen model map. A directory containing weights or any seventh member rejects. No downloads are implemented.

`failure-baseline` is the fixed accepted39/80 record63cd36df…; `realization-baseline` is independently accepted40/82; `baseline` is future independently accepted41/84. The builder joins both actual successful CPU jobs to their predecessors using full normalized rows and complete journal maps, preserving failed35402725 and all earlier history. Each baseline's `input_pins.predecessor`, `.acceptance`, `.disposition` must name the separately supplied records. It never creates or repairs a baseline.

## Explicit interface assumptions for parent integration

These are **consumer requirements for future real records**, not fabricated producer records or a replacement acceptance schema. If the future collector/acceptance uses another field name/layout, reconcile and review the source interface before build; do not synthesize missing authority or edit original evidence to satisfy this authoring.

1. Realization acceptance uses the existing accepted contract: status `accepted`, integer `required_findings=0`, `complete_custody_verified=true`, `job_id`, `disposition_sha256`, `realization_packet_sha256`, `realization_terminal_sha256`, freeze/namespace/claim pins. Complete56 realization is established by that independent acceptance; this builder does not read any world descriptor, including the24 development payloads. The supplied disposition retains the failed41-object custody and original claim bindings.
2. Collection acceptance uses the frozen preparer's existing `ace-scientific-collection-acceptance-v1`, status `accepted`, scope `policy_train`, integer findings0, complete custody/accounting true, and exact `collection` object. For the outer accounting join it also supplies `job_id`, `disposition_sha256`, `collection_packet_sha256`. Additional metadata is allowed. The `collection` object's exact eight keys are `root`, `files`, `freeze_sha256`, `realization_acceptance_sha256`, `world_pins`, `configuration_pins`, `source_pins`, `namespaces`; the three per-world maps cover exactly training IDs202611070000..031. Original protocol12 plus collection helper source pins are preserved.
3. Both dispositions expose the established `remote_files` map with `{bytes,sha256}` entries under `launch/`, current packet/result/job/root pins, `custody_bytes_verified`, `current_lineage_verified`, empty `errors`/`input_pin_mismatches`, exact prior accounting/journal flags, observed row/journal counts, and `allocation`. Allocation fields match existing collector records: resources matched, empty errors, COMPLETED/0:0, actual CPU count/elapsed/allocated seconds, GPU count/seconds, raw AllocTRES. The collection acceptance file map must equal the **entire** `launch/collection/session/worker/task/collection/` subtree. No samples or truncation.
4. Upstream actual successful allocations remain the frozen2CPU/7680MiB/noGPU profiles, realization<=300s and collection<=900s, and distinct jobs. Exact prior rows/journals plus actual new rows/results must yield40/82 then41/84. These checks authenticate existing outcomes; they do not assert either outcome before independently accepted records arrive.
5. The collection outer packet remains the frozen collection-authoring shape with `new_input_files` binding the same realization acceptance, namespace claim, freeze and namespace descriptor. Production source commit staysa934…; any future infrastructure amendment requires explicit source/contract reconciliation, not a CLI bypass to newer HEAD.

## Privacy and scientific invariants

The collection root remains at its original remote location and read-only. Only its pinned acceptance/metadata enters the token packet; the whole original file map is authenticated before each launch readiness, without decoding payloads. Development descriptor/response payloads are never opened. The public original proposal remains byte-identical, including its prospective schedule metadata.

Exactly six tokenizer files are staged under `ROOT/tokenizer`, which is the worker packet's `model_directory`. The seven-file model map retains the frozen `model.safetensors` hash for semantic model identity, but no weight bytes are opened, copied, transferred or loaded. The launcher hashes only the six explicit public origin files, then verifies their staged hashes and exact directory membership. It does not invoke a tokenizer.

The accepted worker alone, inside the allocated CPU stage, validates all160 records/3584 retained comparisons, selects the fixed strict DPO exposure, rejects D=0 without rescue/recollection, and constructs the matched LLM/numerical plans. Selection/token IDs/token lengths are not computed by builder/launcher/monitor. The stage performs no LLM weights/inference/training or new environment responses. Worker logic and methods are unchanged; no local numerical/model import or source-worker call was used in authoring.

## Future launch and monitor interface

Launcher, only after independent concrete packet review and commit:

```
python3 -B <launch01>/launch_once.py --packet-directory <launch01> \
  --packet-commit FULL_COMMIT --packet-sha256 OUTER_SHA \
  --packet-review COMMITTED_REVIEW_PATH --packet-review-sha256 REVIEW_SHA
```

Both existing controller locks cover all authority/pin validation and operations. All packet members and review must match the supplied commit and external mirror. Existing controller/build-failure/intent/result or any tokenization remote root prevents a second attempt. Both live reconciliations require no active ACE job, exact41 rows/84 journal hashes, currentasc2/acpu/cpu-normal3CPU feasibility, original runtime archive metadata/manifest, both existing registry hashes, upstream journals/realization terminal, and the complete unchanged collection tree. Six original tokenizer files are also pinned. New source/input/tokenizer transfers get full hash readback. Original namespaces are never claimed, rewritten, adopted or removed. One exclusive local intent, then one exclusive remote intent and one sbatch; ambiguous/failed transport retains stdout/stderr/state and forbids automatic retry.

Remote coordinator bound240s/local transport255s accommodate complete opaque collection hashing; scheduler-query bounds20s and sbatch25s remain finite. These are coordinator limits, not extra Slurm allocation or measured runtime promises. Transfer groups are root metadata, child inputs and six tokenizer files; no recursive scientific-data transfer.

Monitor, only after an unambiguous original result:

```
python3 -B <launch01>/monitor_once.py --packet-directory <launch01> \
  --packet-sha256 OUTER_SHA --submission-result-sha256 ORIGINAL_RESULT_SHA \
  --evidence-directory NEW_EXCLUSIVE_OBSERVATION_DIRECTORY
```

It captures one scheduler observation and output-marker presence/hashes, never private prepared content, acceptance or retry. Parent controls early/periodic monitoring and diagnosis. A future terminal collector must preserve the entire ROOT, complete original collection custody, exact claims, both copies and second readback, and reconcile42jobs/86journals with actual token CPU cost even on failure. No terminal collector or acceptance record is authored here; that interface remains a separate bounded task.

## Validation and remaining gates

`static01.json` records syntax-only parsing/compilation of the three files and embedded remote source strings:0.010936 processCPU seconds,0.010941666 elapsed,zero tests/packet builds/remote actions/scientific draws. This is not a fabricated execution test or runtime qualification. The previous seven alias methods, three delta methods, worker tests and closed reviews were not repeated.

Before any build: independent authoring review; actual full collection custody/acceptance; exact41/84 baseline; reconciliation of the explicit consumer field assumptions above; independently supplied public tokenizer snapshot. Before launch: concrete packet review and full commit binding, fresh live checks under both locks, and explicit parent launch decision. No current acceptance, reservation, result or success is inferred by this handoff.
