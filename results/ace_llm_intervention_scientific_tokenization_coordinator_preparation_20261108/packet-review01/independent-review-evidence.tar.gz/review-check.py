from pathlib import Path
import os,stat,hashlib,json,subprocess,ast,shlex,tempfile,datetime,traceback
REPO=Path('/Users/pat/code/ACE');R=REPO/'results/ace_llm_intervention_scientific_tokenization_20261108/launch01';E=Path('/Users/pat/ACE_Study_Results/2026-10-peter-baseline/ACE-LLM-intervention-scientific-tokenization-20261108-01')
OUT=Path(tempfile.mkdtemp(prefix='ace-scientific-tokenization-packet01-review-',dir='/tmp'))
Path('/tmp/ace-scientific-tokenization-packet01-review-current.txt').write_text(str(OUT)+'\n')
def sha(data):return hashlib.sha256(data).hexdigest()
def read(p):return Path(p).read_bytes()
def H(p):return sha(read(p))
def J(n):return json.loads(read(R/n))
def digest(x):return sha(json.dumps(x,sort_keys=True,separators=(',',':'),allow_nan=False).encode())
checks=[];pins={};result={'scope':'independent concrete metadata/bytes only','target_callables_executed':False,'tests_rerun':False,'remote_actions':False,'private_scientific_payloads_decoded':False}
def check(ok,label):
 if not ok:raise ValueError(label)
 checks.append(label)
def inv(root):
 files={};dirs=[];ids={}
 for p in sorted(root.rglob('*')):
  s=p.lstat();n=p.relative_to(root).as_posix()
  if stat.S_ISDIR(s.st_mode):dirs.append(n);continue
  if not stat.S_ISREG(s.st_mode) or s.st_nlink!=1:raise ValueError('non-independent packet member '+n)
  data=read(p);after=p.lstat()
  if (s.st_ino,s.st_size,s.st_mtime_ns,s.st_ctime_ns)!=(after.st_ino,after.st_size,after.st_mtime_ns,after.st_ctime_ns):raise ValueError('changed packet member '+n)
  files[n]={'bytes':len(data),'sha256':sha(data)};ids[n]=(s.st_dev,s.st_ino)
 return files,dirs,ids
try:
 outer=J('packet.json');inner=J('inputs/packet.json');f=J('freeze.json');a=J('collection-acceptance.json');b=J('baseline.json');prior=J('collection-failure-baseline.json');disp=J('collection-disposition.json');cp=J('collection-packet.json');cr=J('collection-result.json')
 check(H(R/'packet.json')=='a831737c6bc24a3b38269e36fa347ed3934c7803e7e18b0738881ac0b8fc323d','independent outer pin')
 check(H(R/'inputs/packet.json')=='101d88f3ff15ed322273d63ad281de05afd921754102a907f7232ac000801e7b','independent inner pin')
 pins={**outer['new_input_files'],'packet.json':H(R/'packet.json')}
 lf,ld,li=inv(R);ef,ed,ei=inv(E)
 check(set(lf)==set(ef)==set(pins) and lf==ef and ld==ed,'exact whole two-copy packet membership and bytes')
 check(all(lf[n]['sha256']==p and li[n]!=ei[n] for n,p in pins.items()),'every outer member pin and independent inode')
 check(not any((R/n).exists() or (E/n).exists() for n in ['controller.json','submission.intent.json','submission.result.json','launcher_failure.json','build-failure.json']),'no captured build failure/controller/submission artifacts')
 hand=json.loads(read('/tmp/ace-token-stream-transport-authoring-kpeci6s1/handoff.json'))
 check(all(pins[n]==hand['pins'][n] for n in ['build_packet.py','launch_once.py','monitor_once.py','pull_terminal.py','stream_custody.py','stream_custody_review.md']),'all six independently reviewed coordinator/helper members')
 check(pins['stream_custody.py']=='fab01ad840e4e73ef0fc2136fd2eeb12b1033256e80a8f96a392afb2d50b758a' and pins['stream_custody_review.md']=='5058426e9dccaaf210eb2969a8623a31123f13dfefaa43c57e975e5800819371','reviewed helper and independent review pins')
 check(pins['freeze.json']=='15602614ef9d7e9a3e21027e7495f891c98ba32a2b6b0ee9857e5b71d5e5e66d' and outer['source_commit']==inner['source_commit']==f['source_commit']=='a9346022f145cc29439325b6f291597b2e6ec037','original source commit and adopted freeze')
 stage=next(s for s in f['stages'] if s['stage']=='tokenize');cl=f['stage_closure']['stages']['token']
 resources={k:stage[k] for k in ['account','cpus','gpus','memory_mib','partition','qos','requeue','wall_seconds']}
 check(resources==outer['resources']==inner['resources'] and inner['deadlines']==outer['deadlines']==stage['deadlines']==dict(startup=120,work=550,cleanup=570,hard=590),'frozen CPU resource/deadline contract')
 check(resources['cpus']==3 and resources['memory_mib']==11520==3*3840 and resources['wall_seconds']==600 and resources['gpus']==0,'three CPUs at saved3840MiB-per-CPU ceiling, noGPU')
 check(outer['remote_root']==stage['remote_root'] and outer['local_root']==str(R) and outer['external_root']==str(E)==stage['exclusive_external_root'],'exact frozen stage roots')
 check(inner['source_names']==cl['source_names'] and len(inner['source_names'])==28 and len(cl['input_source_files'])==32 and len(inner['files'])==34,'exact28 loaded/32 captured source/34 input closure')
 check(set(inner['files'])==set(cl['input_source_files'])|{'proposal.json','collection-acceptance.json'} and {n.removeprefix('inputs/'):p for n,p in pins.items() if n.startswith('inputs/') and n!='inputs/packet.json'}==inner['files'],'inner file map exactly joined to outer inputs')
 source_map={}
 for n,pin in cl['input_source_files'].items():
  origin='results/ace_llm_intervention_campaign_artificial_20261108/cpu03/inputs/probe.py' if n=='probe.py' else 'scripts/research/'+n
  check(inner['files'][n]==pin==f['source_pins'][origin], 'captured source authority '+n)
  data=subprocess.check_output(['git','--no-replace-objects','show',f['source_commit']+':'+origin],cwd=REPO)
  check(sha(data)==pin and data==read(R/'inputs'/n),'full-commit captured bytes '+n);source_map[origin]=pin
 check(outer['source_pins']==source_map,'outer original source map exactly captured closure')
 proposal_path=f['original_proposal']['path'];proposal_raw=subprocess.check_output(['git','--no-replace-objects','show',f['source_commit']+':'+proposal_path],cwd=REPO)
 check(proposal_raw==read(R/'inputs/proposal.json') and sha(proposal_raw)==f['original_proposal']['sha256'] and digest(json.loads(proposal_raw))==f['original_proposal']['semantic_sha256'],'original public proposal byte/semantic pin')
 check(inner['runtime']==f['runtime'] and inner['runtime_source']==f['runtime_source'] and inner['archive']==dict(path=f['runtime_archive_path'],sha256=f['runtime_archive_sha256']) and inner['manifest']==dict(path=f['runtime_manifest_path'],sha256=f['runtime_manifest_sha256']),'qualified runtime/archive/manifest metadata unchanged')
 check(inner['model_files']==f['model_files'] and inner['model_directory']==outer['remote_root']+'/tokenizer','frozen model identity with tokenizer-only path')
 check(set(inner['tokenizer_files'])==set(f['model_files'])-{'model.safetensors'} and len(inner['tokenizer_files'])==6 and {n.removeprefix('tokenizer/'):p for n,p in pins.items() if n.startswith('tokenizer/')}==inner['tokenizer_files'],'exact six public tokenizer bytes, no weights staged')
 check(all(v==f['model_files'][n] for n,v in inner['tokenizer_files'].items()),'tokenizer file pins equal frozen model metadata')
 actual_accept=REPO/'results/ace_llm_intervention_scientific_collection_20261108/acceptance02'
 check(read(actual_accept/'acceptance.json')==read(R/'collection-acceptance.json') and H(actual_accept/'acceptance.json')=='e217199099b81480f0e85c09f0432b60dd5edb2aad1b6b30c8ed86ca736e34e5','actual independent collection02 acceptance bytes')
 check(read(actual_accept/'accounting.json')==read(R/'baseline.json') and H(actual_accept/'accounting.json')=='ab8efc04b63d1598b5416a1c62f2c346b3fef5ab46842119b3a62ed89c3de62b','actual independent42/86 baseline bytes')
 check(a['status']=='accepted' and a['required_findings']==0 and a['complete_custody_verified'] is a['accounting_complete'] is a['owned_worker_cleanup_verified'] is True and a['scientific_qualified'] is False,'collection-only accepted scope and qualification')
 check(a['records']==160 and a['retained_pairs']==3584 and a['collection_accounting']['total_reserved_cost_units']==10240 and a['collection_accounting']['unknown_return_attempts']==0,'accepted full160/3584 schedule and retained charged history')
 check(inner['collection']==a['collection'] and inner['files']['collection-acceptance.json']==pins['collection-acceptance.json']==outer['collection_acceptance_sha256'],'original accepted whole collection binding')
 c=a['collection'];prefix='launch/collection/session/worker/task/collection/'
 fmap={n[len(prefix):]:v for n,v in disp['remote_files'].items() if n.startswith(prefix)}
 check({n:v['sha256'] for n,v in fmap.items()}==c['files'] and len(fmap)==outer['collection_custody']['files']==30418 and sum(v['bytes'] for v in fmap.values())==outer['collection_custody']['bytes']==164050995 and digest(c['files'])==outer['collection_custody']['files_sha256'],'whole accepted collection inventory metadata, no response payload read')
 check(a['job_id']==outer['collection_job_id']==cr['job_id']==disp['job_id']=='35409614' and cr['returncode']==0 and cr['ambiguous'] is False,'exact original completed collection job/result')
 check(a['collection_packet_sha256']==pins['collection-packet.json']==disp['packet_sha256'] and a['disposition_sha256']==pins['collection-disposition.json'] and disp['submission_result_sha256']==pins['collection-result.json'],'collection original packet/result/disposition joins')
 check(b['input_pins']['acceptance']==pins['collection-acceptance.json'] and b['input_pins']['disposition']==pins['collection-disposition.json'] and b['input_pins']['predecessor']==pins['collection-failure-baseline.json'],'accepted baseline authority joins')
 current=[v for v in b['related_accounting'] if v[0]=='35409614'];earlier=[v for v in b['related_accounting'] if v[0]!='35409614']
 check(len(current)==1 and earlier==prior['related_accounting'] and len(b['related_accounting'])==b['terminal_jobs']==42 and current[0][2:6]==['COMPLETED','0:0','2','800'],'unchanged41 predecessors plus actual800-second2CPU collection')
 jp={**prior['journal_pins'],cp['remote_root']+'/submission.intent.json':cr['intent_sha256'],cp['remote_root']+'/submission.result.json':pins['collection-result.json']}
 check(b['journal_pins']==jp and len(jp)==b['submission_journals']==86,'exact84 prior plus2 original collection journals')
 cpu=gpu=0
 for row in b['related_accounting']:
  assert row[4].isdigit() and row[5].isdigit()
  pairs=[v.split('=',1) for v in row[7].split(',') if v];t=dict(pairs);assert len(t)==len(pairs)
  count=int(row[4]);seconds=int(row[5]);assert t or count==seconds==0
  gs={k:v for k,v in t.items() if k.startswith('gres/')};assert all(v.isdigit() and (k=='gres/gpu' or k.startswith('gres/gpu:')) for k,v in gs.items())
  typed=sum(int(v) for k,v in gs.items() if k.startswith('gres/gpu:'));g=int(gs['gres/gpu']) if 'gres/gpu' in gs else typed
  if 'gres/gpu' in gs and any(k.startswith('gres/gpu:') for k in gs):assert g==typed
  cpu+=count*seconds;gpu+=g*seconds
 check((cpu,gpu)==(b['closed_cpu_seconds'],b['closed_gpu_slice_seconds'])==(12986,1601),'actual full42-row cost arithmetic including failures')
 ad=outer['admission'];check(ad==dict(candidate_cpu_reservation=1800,candidate_gpu_reservation=0,ceiling_cpu_seconds=57600,ceiling_gpu_seconds=7200,closed_cpu_seconds=12986,closed_gpu_slice_seconds=1601,preparation_allowance_cpu_seconds=3600,prior_jobs=42,prior_journals=86,total_cpu_seconds=18386,total_gpu_seconds=1601),'single preparation allowance plus exact candidate reservation')
 remaining=[s for s in f['stages'] if s['stage'] in ['tokenize','train','cpu_campaign','gpu_campaign','finalize']]
 projected_cpu=cpu+3600+sum(s['cpus']*s['wall_seconds'] for s in remaining);projected_gpu=gpu+sum(s['gpus']*s['wall_seconds'] for s in remaining)
 check(projected_cpu<=57600 and projected_gpu<=7200,'remaining frozen stage caps fit global ceilings')
 check(J('adoption.json')['freeze_sha256']==pins['freeze.json'] and J('adoption.json')['review_sha256']==pins['freeze-review.md'] and J('adoption.json')['status']=='adopted','independent original freeze adoption')
 check(outer['operational_amendment_sha256']==a['operational_amendment_sha256']==pins['operational-amendment.json']=='fa94858dfc19c8b15c82acde167ad8fe9991d0c863c32444d017743079617855' and outer['collection_failure_acceptance_sha256']==a['collection_failure_acceptance_sha256']==pins['collection-failure-acceptance.json'] and outer['no_response_proof_sha256']==a['no_response_proof_sha256']==pins['no-response-proof.json'],'collection-only amendment and failed01 lineage preserved')
 check(outer['science_equality']['scientific_inputs_unchanged'] is True and pins['collection-science-packet.json']==outer['science_equality']['original_science_packet_sha256']=='a86dfd705dba2ca213c3ac25884c3e3deca177e00d8ce8be72732a3baf878c35','unchanged collection scientific packet, no recovery re-freeze')
 claim=J('namespace-claim.json');base=E.parent
 check(pins['namespace-claim.json']==outer['namespace_claim_sha256']==a['namespace_claim_sha256']=='40c0937c623d9473a413347125d3bc35648955132c4cf2394f055d4b228fed6a' and H(base/'ACE-LLM-intervention-scientific-screen-20261107.namespace-recovery02.json')==pins['namespace-claim.json'],'physical local recovery claim unchanged')
 check(H(base/'ACE-LLM-intervention-scientific-screen-20261107.namespace.json')=='58033e812390731ad08c83b7236e6e47893de3a3488cf4602d5c42809a51fa29' and outer['namespace_claimed'] is False,'original local claim preserved, no new namespace claim')
 job=(R/'job.sbatch').read_text();argv=shlex.split(job[job.index('exec ')+5:]);diag=ast.parse(read(R/'inputs/qualify_llm_intervention_runtime_metadata.py'))
 bootstrap=next(ast.literal_eval(n.value) for n in diag.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='BOOTSTRAP' for t in n.targets))
 expected=[inner['runtime_source']+'/bin/python','-I','-B','-c',bootstrap,outer['remote_root']+'/inputs/'+stage['entry'],stage['entry_sha256'],'--packet',outer['remote_root']+'/inputs/packet.json','--packet-sha256',pins['inputs/packet.json'],'--source-commit',f['source_commit'],'--output',outer['remote_root']+'/preparation']
 check(argv==expected,'exact bootstrap/entry/source/packet/output Slurm argv')
 directives=[l for l in job.splitlines() if l.startswith('#SBATCH ')]
 check('#SBATCH --cpus-per-task=3' in directives and '#SBATCH --mem=11520M' in directives and '#SBATCH --time=00:10:00' in directives and '#SBATCH --no-requeue' in directives and not any('--gres' in x or '--gpus' in x for x in directives) and "export CUDA_VISIBLE_DEVICES=''" in job,'actual sbatch CPU/memory/wall/noGPU/no-requeue declarations')
 final_lf,final_ld,_=inv(R);final_ef,final_ed,_=inv(E);check((final_lf,final_ld)==(lf,ld)==(final_ef,final_ed),'both copies unchanged through concrete review')
 result.update(status='passed',required_findings=0,outer_sha256=pins['packet.json'],inner_sha256=pins['inputs/packet.json'],members=len(lf),packet_bytes=sum(v['bytes'] for v in lf.values()),directories=ld,captured_source_count=32,worker_inputs=34,public_tokenizer_files=6,closed_cpu_seconds=cpu,closed_gpu_seconds=gpu,candidate_cpu_admission=18386,remaining_projected_cpu_seconds=projected_cpu,remaining_projected_gpu_seconds=projected_gpu,checks=checks)
 for n in pins:
  dst=OUT/'packet'/n;dst.parent.mkdir(parents=True,exist_ok=True)
  with dst.open('xb') as stream:stream.write(read(R/n))
  assert H(dst)==pins[n]
 (OUT/'packet-inventory.json').write_text(json.dumps(dict(files=lf,directories=ld),indent=2,sort_keys=True)+'\n')
except BaseException:
 result.update(status='review_check_failed',checks=checks,error=traceback.format_exc())
finally:
 result['utc']=datetime.datetime.now(datetime.timezone.utc).isoformat()
 (OUT/'metadata-review.json').write_text(json.dumps(result,indent=2,sort_keys=True)+'\n')
 (OUT/'review-check.py').write_bytes(Path(__file__).read_bytes())
 print(json.dumps({k:v for k,v in result.items() if k!='checks'},indent=2));print('evidence',OUT)
