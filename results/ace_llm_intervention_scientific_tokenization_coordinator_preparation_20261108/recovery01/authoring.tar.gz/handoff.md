# Token01 prospective recovery coordinator handoff

Ready for new independent source review only. All work is in `/tmp/ace-scientific-tokenization-recovery-authoring-qa7ojemp`. No packet was built; no source callable, tokenizer, model, scientific work, remote command, submit, test, staging or commit was performed. The actual collection01 failure was not re-audited. Static source parsing/compilation and byte/metadata checks are the only validation here.

## Preservation and source pins

The complete initial token authoring tree is copied without modification to `initial01/`; `initial01-closed-review.md` preserves the closed independent review. `preservation.json` pins every original file. The original `/tmp/ace-scientific-tokenization-authoring-nvsnb064` remains unchanged. Parent's initial01 repository archive is untouched. Superseded local builder drafts, collector predecessor and the first/amended collection02 interface snapshots remain in this tree. No review disposition for these NEW sources is asserted.

- Builder `88320878518532419ad3450823de72ba67df9935764fd7fd5cf0c2ba9055bb34`
- Once launcher `e18721500f2686fd4dca819a18d4f4509e1c5703fc1f5a900ac465b7e0e5b3b4`
- Monitor `0b3041fc5154b434c71e35c7d32beb7885ffac0ddeaa0f6fbcfa8d26bda6b68c` (byte-identical to initial01)
- Standalone terminal collector `8a710320e506c0e3eee2917bcb55eabf2d06bde2536f344e1286a17aed133ee6`

Each script has a corresponding `.diff`. Collector is derived from separately reviewed collection01 collector754efa82…, captured as `collector-predecessor.py`. It is stdlib-only and imports no builder or production module. It will be packaged as a root-only coordinator member in both future launch mirrors and committed with the concrete packet; it is not a worker input and is never called by sbatch.

## Fixed science and operational authority

Scientific freeze15602614ef9d7e9a3e21027e7495f891c98ba32a2b6b0ee9857e5b71d5e5e66d and sourcea9346022f145cc29439325b6f291597b2e6ec037 remain fixed. Token entry47bbf574… and its32-source input closure/28 work-source names remain unchanged. Token01 roots are unchanged and unbuilt, including ROOT `/scratch/alpine/paco0228/ACE/results/ace_llm_intervention_scientific_tokenization_20261108_01`, repositorylaunch01 and original exclusive external token01 name. Worker inputs remain32 sources + original proposal + independent collection acceptance; no extra worker admission or metadata field is injected.

Token allocation remains3CPU11520MiB600seconds,zeroGPU,ucb736_asc2/acpu/cpu-normal,no requeue,deadlines120/550/570/590. The collection-only startup300 amendment is NOT applied to token. No improved token staging/runtime performance is inferred from the upstream recovery.

Exact collection02 authorityfa94858dfc19c8b15c82acde167ad8fe9991d0c863c32444d017743079617855 is mandatory with independent CLI pin. Its original design review2d472a12…, guideb6a1290b… and diagnosis61dc3951… remain pinned. The separate exact-authority reviewdb2a672a4f0222a06a46d1e61ebc5bdc22b869640f570e19d36a0f699a1ddbaf is a separate required `operational-adoption-review` input, not a new field inserted into the immutable authority. Kuhn's final handoff/consumer-interface are retained as `collection02-final-*`; the interface now consumes the published failure/proof fields unchanged.

## Actual lineage, then mandatory future success

The builder requires the full original39/80 → accepted realization40/82 → failed collection41/84 → future accepted collection02 42/86 chain. Known full pins remain required CLI values even where also hardcoded for rejection on mismatch:

- Realization acceptance5e28e1aa… and40/82 baseline69cc9778….
- Actual failed35407428 acceptance00c4557a…, no-response proof59c21d63…, dispositionfd3a52be…, and baselineeeec362d… (11386CPU/1601GPU,14986CPU with preparation).
- Original failure packet, submission result, both remote inventories and custody inventory.
- Original failed supervisor packet and both admissions, unchanged inner scientific packet.
- Adopted operational amendment and independently pinned reviews.
- **Future** collection02 actual acceptance, disposition, outer packet, submission result, supervisor packet, both admissions, complete raw collection custody and independent42/86 baseline. No job ID, pin, elapsed time, cost, success flag or acceptance is defaulted or invented.

All32 training world/configuration/namespace maps remain bound to the same accepted realization. Every predecessor row is normalized and compared in full, including unique IDs/TRES keys; every prior journal hash is retained plus exactly the new intent/result. Counts supplement these exact equality checks, not replace them. Failed252CPU remains charged. Future collection CPU charge is2×actual recorded elapsed, noGPU,<=900seconds, with COMPLETED0:0 and independent acceptance. Token admission adds only1800CPU reservation and the single3600CPU preparation allowance to actual closed costs;57600CPU/7200GPU ceilings remain enforced.

The published failure acceptance status is `accepted_failed_before_response`; proof status is `verified_failed_before_collection_worker` and has no schema field. The consumer uses their actual field names, positive source/traceback proof, integer zeros and existing evidence_pins map. It preserves `node_local_partial_runtime_cleanup_verified=false` and runtime qualification false. There is no generic missing-output success inference.

## Exact before/after science comparison

`collection_science_equality` binds original/future supervisor metadata to each respective outer packet, checks the same60 supervisor input names, and requires all59 unchanged source/training/proposal/realization files byte-identical. The sole changed input is collection-admission.json, itself compared as the same object with only its output root changed. Original inner collection-packet.json must be identical bytes in both attempts. Original/future supervisor fields are identical after removing only output, deadlines and the separately compared file map. Outer admission changes only output/deadlines and the corresponding supervisor packet pin. Production source maps, resources, original records/pairs/attempt/cost bounds and development-staging zero agree exactly. Accepted world/configuration pins must match the unchanged inner science packet. The future comparison result is retained in the future token outer packet and revalidated by the launcher.

No descriptor values, responses, labels, training records, selected DPO set or token IDs are generated/decoded by this comparison. Private accepted collection bytes are only fully hashed. `science-invariants.json` records unchanged token/freeze metadata; it does not pretend future producer bytes have already been checked.

## Arguments and files

`argument-map.json` lists all38 mandatory metadata path+SHA pairs. Call each as `--NAME PATH --NAME-sha256 FULL_SHA`. Entries with null path/pin are unresolved future evidence; no runnable build command is supplied before that evidence exists. The legacy `failure-baseline` means original realization failure39/80; the new `collection-failure-baseline` means actual collection failure41/84. Kuhn's collection02 outer packet calls the latter `failure-baseline.json`; that filename alias is explicitly checked.

Additional mandatory directories:

- `--failed-remote-custody`: original collection01 terminal01/remote, complete opaque146-file map.
- `--collection-custody`: future accepted collection02 `remote/launch/collection/session/worker/task/collection`.
- `--tokenizer-directory`: parent-captured `/Users/pat/ACE_Study_Results/2026-10-peter-baseline/ACE-LLM-intervention-scientific-tokenizer-input-20261108-01/tokenizer`. Exactly six public files must match frozen hashes again at use. No weights are copied/read; the frozen weight hash remains metadata only. No search/download was repeated here.

Collection02 remote ROOT is `/scratch/alpine/paco0228/ACE/results/ace_llm_intervention_scientific_collection_20261108_02`; token upstream collection binding points to its `/collection/session/worker/task/collection` subtree. No prior root/claim is reused as a new output.

## Launch, monitor and collector

Launch CLI remains initial01: packet-directory/full packet-commit/outer packet-sha256/packet-review path+SHA. Both locks, full commit/mirror verification, exclusive roots/intents, both readiness/pre-sbatch exact accounting/journal/site checks and once-only sbatch remain. Both passes additionally fingerprint the entire immutable failed collection01 root, alongside complete accepted collection02 tree and current namespace/upstream metadata. Operational/failure/proof/review pins and the science-equality record are bound into packet and local/remote intent. No ambiguous retry, claim mutation or output adoption is introduced. Monitor API/bytes are unchanged and remains read-only.

Standalone collector CLI requires independently supplied `--job-id`, `--packet-sha256`, `--submission-result-sha256`, `--local-intent-sha256`, `--packet-commit`, `--collector-sha256`, `--packet-review`, `--packet-review-sha256`. Its source must equal its concrete packet/Git member as well as the supplied self pin. It captures complete coordinator histories under both locks and requires conclusive current terminal/no active related ACE job. It never submits/cancels/requeues or runs a model/tokenizer.

Future collector destinations are repository tokenization terminal01 and external `ACE-LLM-intervention-scientific-tokenization-terminal-20261108-01`. Whole tokenROOT→remote/launch, whole accepted collection02ROOT→remote/common, whole failed collection01ROOT→remote/failed01, plus both separate namespace claims. All evolving/private/candidate/failure/runtime/resource/cleanup files are copied without selective filtering or private JSON decoding. Original realization readback is an explicit36-file training-only allowlist, not a traversal of development worlds. Both full remote inventories/readbacks and both independent local copies must match; original upstream full file maps must remain unchanged. Hardlink names become separate local regular bytes with original link metadata retained, symlinks reject. Failures/partial transfers remain preserved; no automatic collector retry.

Exact42 predecessor rows/all86 journals plus actual token job/two journals must yield43/88. Allocation observations check3CPU11520MiB600s/noGPU and charge actual CPU×elapsed even on failure. Worker/outer success markers only produce `terminal_custody_review_pending`; all acceptance/tokenization/training/scientific flags stay false. Only public terminal counts/pins are decoded after full custody. Prepared records, exposure, token IDs, numerical arrays and model outputs are never interpreted by this collector. Full independent actual token/runtime/cleanup acceptance remains required separately.

## Verification and remaining gates

`static01.json` records AST/symbol/compile checks of all four scripts and embedded remote strings. `static02.json` checks only the subsequent root-only collector packaging delta. Neither executed target code or ran tests. Initial token constants/monitor bytes and original tree preservation were independently compared as AST/bytes. Static checks do not establish runtime success or an independent review verdict.

Remaining gates: new independent coordinator/collector review; actual successful collection02 full custody/acceptance42/86 and actual costs; any producer-field reconciliation explicitly reviewed; concrete token build/review/full Git binding; fresh launch checks. No packet/root/output/namespace/reservation has been created by this source preparation.
