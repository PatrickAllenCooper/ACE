from pathlib import Path
import hashlib,json,shutil,datetime
root=Path(Path('/tmp/ace-token01-startup-diagnosis-current.txt').read_text().strip())
diag=Path('/var/folders/rp/5fry8hzd6r79lbs65w92n8b00000gn/T/ace-token01-failure-diagnostic-n_wunx1o')
(root/'partial-diagnostic').mkdir();(root/'partial-diagnostic/raw').mkdir()
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
for name in ['transport.json','source.py']:shutil.copyfile(diag/name,root/'partial-diagnostic'/name)
t=json.loads((diag/'transport.json').read_bytes());assert t['returncode']==0
v=json.loads(t['stdout']);assert v['scope']=='partial diagnostic, not complete custody'
expected={'preparation/failure.json':'acc3c88781d333719154cf2f774bb6633e9cc99b87e62bf4ec54a74c529ae03a','logs/35415334.err':'6dc0407e0ab1db4e0b148b585a4a63d9ef378cfcd7bcad4c74fc57f7bd0700a1'}
for name,h in expected.items():
 row=v['files'][name];data=row['text'].encode();assert len(data)==row['bytes'] and hashlib.sha256(data).hexdigest()==row['sha256']==h
 p=root/'partial-diagnostic/raw'/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data)
f=json.loads(v['files']['preparation/failure.json']['text'])
assert f['type']=='ValueError' and f['message']=='original absolute deadlines required'
launch=Path('/Users/pat/code/ACE/results/ace_llm_intervention_scientific_tokenization_20261108/launch01')
inner=launch/'inputs/packet.json'
if not inner.exists():
 packet=json.loads((launch/'packet.json').read_bytes())
 choices=[p for p in (launch/'inputs').glob('*.json') if hashlib.sha256(p.read_bytes()).hexdigest()=='101d88f3ff15ed322273d63ad281de05afd921754102a907f7232ac000801e7b']
 assert len(choices)==1;inner=choices[0]
p=json.loads(inner.read_bytes());assert p['deadlines']==dict(startup=120,work=550,cleanup=570,hard=590)
shutil.copyfile(inner,root/'metadata/inner-packet.json')
old=json.loads((root/'preliminary.json').read_bytes())
receipt={**old,'status':'actual_pinned_partial_failure_trace_source_diagnosis','failure_bytes_not_yet_read':False,'diagnostic_transport_sha256':sha(diag/'transport.json'),'diagnostic_source_sha256':sha(diag/'source.py'),'inner_packet_sha256':sha(inner),'observed_exception':dict(type=f['type'],message=f['message'],traceback=f['traceback']),'observed_zero_flags':{k:f[k] for k in ['environment_responses','training_updates','inference_calls','model_weights_loaded','explicit_cuda_api_called']},'failure_before_worker_spawn':True,'recorded_sigalrm':False,'startup_expired_at_supervise_source_deduction':True,'exact_elapsed_at_guard_not_recorded_in_supplied_diagnostic':True,'latency_root_cause':'not established','node_local_runtime_cleanup_verified':False,'complete_failure_acceptance':False,'complete_terminal_custody':False,'proposed_operational_delta':dict(startup_old=120,startup_new=300,work=550,cleanup=570,hard=590,wall_seconds=600,cpus=3,memory_mib=11520,gpus=0,original_monotonic_origin_preserved=True,scientific_source_changes=0),'utc':datetime.datetime.now(datetime.timezone.utc).isoformat()}
(root/'diagnosis.json').write_text(json.dumps(receipt,indent=2,sort_keys=True)+'\n')
(root/'diagnosis.md').write_text('''# TOKEN01 startup failure — bounded actual-trace diagnosis

**Confirmed first failure:** `ValueError: original absolute deadlines required`, before worker spawn. Exact1337-byte failure receipt SHA `acc3c88781d333719154cf2f774bb6633e9cc99b87e62bf4ec54a74c529ae03a` and1275-byte Slurm stderr SHA `6dc0407e0ab1db4e0b148b585a4a63d9ef378cfcd7bcad4c74fc57f7bd0700a1` were independently recomputed from the parent's partial diagnostic. This is not a recorded SIGALRM. Original error and raw transport/source are retained. Full custody and independent actual-failure acceptance remain pending.

The frozen47bb entry calls `ownership.supervise` at line536 after parent input authentication, runtime staging, stage receipt and provenance publication. The1c084 owned helper rejects its first precondition at lines121–124, before `Popen` line139, worker logs or startup marker. The source and captured inputs match full frozen commita9346022f145cc29439325b6f291597b2e6ec037. The actual inner packet remains101d88f3ff15ed322273d63ad281de05afd921754102a907f7232ac000801e7b, with120/550/570/590 deadlines.

The parent supplies the original finite monotonic start and offsets120,550,590. Their ordering is valid and hard−work=40≥5. With the monotonic clock, the remaining failing condition is `now < started+120`: startup had expired on entering supervision. This is a source-grounded deduction from the observed guard, not a measured exact elapsed value. The supplied diagnostic contains no phase timings; the saved first inventory shows stage/provenance outputs and102 phase receipts but no session files. It does not establish whether collection verification, archive reads/extraction, receipt fsync, provenance work or another delay consumed the window. Do not attribute this to filesystem contention or a specific operation without the phase evidence.

The failure reports zero environment responses, updates and inference, and no loaded model weights/CUDA API. Those are declared failure fields; the observed pre-Popen boundary separately supports that this worker never ran. The partial diagnostic returned no attempt.json. Full absence/custody accounting and no-response proof belong to the independent audit. No staged-runtime deletion is proven or claimed.

**Proposed narrow operational amendment:** TOKEN02 startup120→300 only; work550/cleanup570/hard590, wall600,3CPU11520MiB/noGPU unchanged. The existing ordered-deadline API accepts this; no frozen worker/helper/scientific source edit or clock reset is needed. Retain all160 records/3584 pairs, exposure/seed/plan rules, accepted original collection, source/tokenizer/runtime pins, output schemas and quotas. Use a new exclusive TOKEN02 root/intent; keep TOKEN01 and both namespace registries unchanged. Bind the independently accepted failed attempt, original complete custody, proven no-worker/no-response evidence, actual extended baseline and separately reviewed operational authority. This note is not that authority.

Startup300 leaves250 seconds from the latest permitted work-start to work550, versus430 previously. Earlier startup may leave more. The proposed change grants no additional wall/CPU budget or completion guarantee. Preserve existing cleanup behavior and hard590; do not extend work or shrink required outputs to rescue the run. Fixed512MiB parent diagnostic RSS checks and exact allocation gates also remain unchanged.

**Provisional arithmetic from the saved Slurm row:** failed35415334 is3CPU×129s=387CPU,0GPU. Closed totals become13373CPU/1601GPU,43jobs/88journals; with the single3600 preparation allowance16973CPU. Release TOKEN01's unused1413CPU reservation but retain its387 actual charge. One fresh600-second retry reserves1800CPU, giving18773CPU admission. All remaining frozen stage caps plus that retry project55493CPU/7181GPU, leaving2107CPU/19GPU. These figures require the independent failed-attempt accounting seal; they are not future actual costs.

The old accepted-TOKEN43/88 contract is obsolete. If one TOKEN02 succeeds next, its acceptance baseline is44/90, GPU training45/92, CPU campaign46/94, GPU campaign47/96, finalization48/98. Require actual complete rows/journals and explicit failed-TOKEN lineage in every affected coordinator/collector. Update the TOKEN root and preserve its failed capsule; simply changing counts or treating failed43/88 as successful preparation is insufficient. No worker acceptance-schema change is implied by these historical count changes.

`source-diagnosis-preliminary.md` and preliminary.json preserve the earlier source-only assessment. diagnosis.json contains exact pins and structured observations. No tests, remote probes, collector rerun, tokenizer/model/scientific execution, production edits or commits occurred. A later phase-timing supplement may refine latency localization after full custody; it must preserve this observed exception.
''')
shutil.copyfile(__file__,root/'record-diagnosis.py')
files={}
for p in sorted(root.rglob('*')):
 if p.is_file():files[p.relative_to(root).as_posix()]=dict(bytes=p.stat().st_size,sha256=sha(p))
(root/'inventory.json').write_text(json.dumps(dict(files=files,excludes='inventory.json itself',acceptance=False),indent=2,sort_keys=True)+'\n')
print(json.dumps(dict(root=str(root),diagnosis_sha256=sha(root/'diagnosis.json'),document_sha256=sha(root/'diagnosis.md'),inventory_sha256=sha(root/'inventory.json')),indent=2))
