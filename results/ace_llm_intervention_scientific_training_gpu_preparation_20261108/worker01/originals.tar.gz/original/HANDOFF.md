# Scientific GPU worker source handoff

Only new files `scripts/research/llm_intervention_scientific_training_gpu_worker.py` and `scripts/research/test_llm_intervention_scientific_training_gpu_worker.py`. No old worker, engine, CPU preparation or shared-helper edits; no commits. Other agents' concurrent changes were left untouched.

- `llm_intervention_scientific_training_gpu_worker.py` SHA256 `351b48588248589a686a84f11d73abe34248cdb466e396873bf746afe39f5bec`
- `test_llm_intervention_scientific_training_gpu_worker.py` SHA256 `05610cc090d84022b75e29278a3e46b760fad03493195679e752606e386d77bd`
- `llm_intervention_screen_training_gpu_worker.py` SHA256 `ecf9d7099d2a038fba01f2eddf93d93680fe675396a7d21d248ad81f2892c53d`

## Stable interface and authority

`run_training(prepared, model_directory, output_path, observer, journal, *, prepared_sha256, plan_sha256)`

`validate_outputs(root, prepared, *, prepared_sha256, plan_sha256)`

The prepared pin is the byte SHA256 of canonical JSON plus LF, matching CPU Journal output; the plan pin is semantic SHA256(canonical(plan)). Both must come independently from the accepted complete scientific CPU preparation. The worker does not manufacture acceptance. Parent authenticates capture/source commit, complete CPU acceptance, base model files, runtime, namespace/allocation/deadlines/telemetry, owns process cleanup, then calls run_training. Root must be empty/new under journal.output; saved validator never deserializes tensors. There is no CLI or default resource request. Include the pinned accepted `llm_intervention_screen_training_gpu_worker.py` in the caller's captured closure for its stdlib scoring/disposal helpers; heavy dependencies remain the existing engine/runtime closure. No runtime source rewriting, function-global patching or shared framework.

Complete scientific shape: exact fixed 32-world/160-record policy_train roster, all 3,584 pairs retained, 160 SFT followed by the saved D strict pairs (1..128), no D=0 rescue or new pair selection. Plan/exposure/pins must agree exactly; CPU acceptance remains authority for matched-view/tokenizer correctness, and engine.fit revalidates the unchanged plan. Explicit qwen_screen_singletons and full exact accepted numeric recipe, 112 rank-8 q/v matrices / 1,146,880 parameters, seed 109, continuous AdamW and fixed SFT reference. Checkpoints at 159 and 159+D.

One unchanged engine.fit call; post-fit full legal-command scoring on all records before disposal and on final reload; selected post-SFT reference pairs replayed on SFT reload in original chosen/rejected order (2D singleton forwards). Each checkpoint performs all 160 record generations plus first-record repeat: 322 total. Saved validator reconstructs exact evidence membership from the pinned schedule, per-step optimizer receipts, layers×rows recomputation, checkpoint byte/signature bindings, full ordered scores/generation tokens, reload signatures, cleanup receipts and timing/memory evidence. Qualification flags remain false pending parent independent whole-run review.

## New tests and preserved evidence

Ten distinct new stdlib tests passed. attempt02 ran the initial eight in 4.871367833s wall, 4.66429s CPU, 53,297,152 bytes peak RSS. attempt03-new-boundaries ran only the two additions in 0.544953709s wall, 0.51376s CPU, 65,667,072 bytes peak RSS. AST comparison confirmed the original eight methods unchanged. Total test wall 5.416321542s, CPU 5.17805s. No source changed during either run.

- Complete independently constructed fabricated D=128 bundle: 288 steps, 322 generations, 1,184 before/final legal scores, 256 reference singleton forwards, >=11,648 decoder recomputations.
- Complete D=1 bundle: 161 steps, still 322 generations/1,184 scores, 2 reference singleton forwards, >=4,536 recomputations.
- D=7 input and all retained/unselected pairs; D=0/roster/scope/recipe/checkpoint/exposure rejection; full prompt/EOS/legal membership; reference/gradient/optimizer/step/score/repeat/cleanup mutations; extra attempts/generations and opaque checkpoint corruption; bad pins fail before heavy imports and retain failure.
- Larger-than-old-limit 5 MiB JSON evidence, duplicate/nonfinite JSON and symlink rejection; isolated source wiring confirms single engine.fit and all-record replay.

attempt01 retains the initial test-file SyntaxError, original source snapshots, logs and resources. It was corrected before attempt02; no artifact deleted or overwritten. Each attempt has stdout/stderr, run.json, source-before/source-after and pins. Negative mutation originals and changed bytes are also retained. All tensor files are opaque fabricated bytes. No existing test methods, actual tokenizer/model/training/worlds/responses or remote execution ran. Literal protocol roster IDs were used as schema constants, never drawn or realized.

`lifecycle-static-comparison.json` records AST equality of the complete run_training body against the accepted shape worker, except its docstring and training_start event's step counts. Independent validators and scientific input gate are new source to review.

## Limits

This is source and fabricated evidence validation, not actual GPU qualification. Successful heavy execution was not run or mocked end-to-end. The accepted 4/2 shape result does not establish 160+D wall time, capacity, runtime, throughput or scientific results. Parent still owns concrete packet, source/runtime authentication, resource admission, observations, deadlines, telemetry and complete independent acceptance. Reader limit is now 256 MiB per JSON file; original CPU raw-record/token bounds remain enforced. No weights were opened or models initialized during this task.
