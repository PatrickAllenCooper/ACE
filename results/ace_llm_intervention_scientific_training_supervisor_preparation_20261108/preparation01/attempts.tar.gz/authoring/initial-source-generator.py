from pathlib import Path
p=Path('scripts/research/qualify_llm_intervention_screen_training_gpu.py')
s=p.read_text()
head=s[s.index('from __future__'):s.index('CAPACITY_PACKET_SHA')]
head=head.replace('import resource','import resource\nimport re').replace("VERSION = 'ace-full-shape-singleton-training-gpu-v1'", "VERSION = 'ace-scientific-training-gpu-supervisor-v1'").replace("ENTRY = 'qualify_llm_intervention_screen_training_gpu.py'", "ENTRY = 'supervise_llm_intervention_scientific_training_gpu.py'").replace("WORKER = 'llm_intervention_screen_training_gpu_worker.py'", "WORKER = 'llm_intervention_scientific_training_gpu_worker.py'")
source=s[s.index('SOURCE_NAMES ='):s.index('EXTRA_DATA =')].replace('SUPERVISOR, WORKER, ENTRY,', "SUPERVISOR, WORKER, ENTRY, 'llm_intervention_screen_training_gpu_worker.py',")
prep=s[s.index('PREPARATION_SOURCES ='):s.index('INDEPENDENT =')]
helpers=s[s.index('def need('):s.index('def packet_shape(')]
loader=s[s.index('class CapturedSources'):s.index('def child(')]
child=s[s.index('def child('):s.index('def validate_worker(')].replace('llm_intervention_screen_training_gpu_worker import','llm_intervention_scientific_training_gpu_worker import').replace('PREPARED_SHA',"packet['files']['prepared.json']").replace('CPU_ACCEPTANCE_SHA',"packet['files']['cpu-acceptance.json']").replace('PLAN_SHA',"packet['plan_sha256']").replace('artificial_training_complete','scientific_training_complete')
validator=Path('/tmp/ace-scientific-gpu-reused-fragments.txt').read_text().split('def validate_worker(',1)[1]
readers=s[s.index('def progress_records('):s.index('def parent(')]
intro='''"""One independently admitted scientific GPU training allocation on saved CPU tokens.

No admission is synthesized here. The caller supplies packet and admission byte
pins; the latter binds an independent CPU acceptance, freeze, namespace, reviewed
source closure, resource/deadline profile, site readiness evidence and output.
The acceptance schema is an input contract for a FUTURE actual CPU result, not
an assertion that such an acceptance currently exists. No tokenization, world
access, resampling, retries, scheduler submission or scientific qualification.

Invoke through the existing pinned diagnostic BOOTSTRAP. Runtime/model checks
and the full stdlib saved-worker validator reuse the accepted shape supervisor.
This source and its artificial tests do not qualify an allocation or execution.
"""
'''
constants='''
EXTRA_DATA = {'prepared.json', 'cpu-packet.json', 'cpu-acceptance.json',
              'llm_intervention_runtime_archive.py'}
INDEPENDENT = {GPU:GPU_SHA, SUPERVISOR:SUPERVISOR_SHA, CPU:CPU_SHA, DIAGNOSTIC:DIAGNOSTIC_SHA,
    WORKER:'ab2c999a35b247e03df87dce9f19d771c50f84747381bfbc0ed980e9c832a878',
    'llm_intervention_screen_training_gpu_worker.py':'ecf9d7099d2a038fba01f2eddf93d93680fe675396a7d21d248ad81f2892c53d'}
RESOURCES = dict(account='ucb736_asc2', partition='aa100', qos='gpu-testing',
    requested_cpus=4, max_allocated_cpus=4, memory_mib=15360,
    wall_seconds=2700, gpus=1, gpu_type='a100_3g.20gb')
DEADLINES = dict(startup=240, worker=2620, soft=2630, cleanup=2645, hard=2670,
    progress=180, telemetry=90)
MAX_PREPARED = 256*1024**2
CPU_ACCEPTANCE_SCHEMA = 'ace-scientific-training-preparation-acceptance-v1'
ADMISSION_SCHEMA = 'ace-scientific-training-gpu-admission-v1'
'''
auth='''
def pin(value):
    return type(value) is str and re.fullmatch('[0-9a-f]{64}',value) is not None


def canonical(value):
    return json.dumps(value,sort_keys=True,separators=(',',':'),allow_nan=False)


def decode(raw):
    def pairs(items):
        out={}
        for key,value in items:
            need(key not in out,'duplicate JSON key')
            out[key]=value
        return out
    value=json.loads(raw,object_pairs_hook=pairs)
    canonical(value)
    return value


def exact(actual,expected):
    # JSON comparison also rejects bools where integer resources are required.
    return canonical(actual)==canonical(expected)


def packet_shape(packet):
    keys={'schema','files','source_names','resources','scope','source_commit',
          'archive','manifest','model_directory','model_files','runtime','runtime_source',
          'deadlines','plan_sha256','freeze_sha256','namespace_admission_sha256'}
    need(type(packet) is dict and set(packet)==keys and packet['schema']==VERSION
        and packet['scope']=='policy_train' and exact(packet['resources'],RESOURCES)
        and exact(packet['deadlines'],DEADLINES)
        and type(packet['source_commit']) is str and re.fullmatch('[0-9a-f]{40}',packet['source_commit'])
        and packet['source_names']==sorted(SOURCE_NAMES)
        and type(packet['files']) is dict and set(packet['files'])==set(SOURCE_NAMES)|EXTRA_DATA
        and all(pin(p) for p in packet['files'].values())
        and all(pin(packet[n]) for n in ('plan_sha256','freeze_sha256','namespace_admission_sha256')),
        'complete scientific packet contract differs')
    need(all(packet['files'][n]==p for n,p in INDEPENDENT.items()),'reviewed helper/worker source differs')


def validate_admission(admission,packet,packet_pin):
    expected={'schema':ADMISSION_SCHEMA,'status':'admitted','scope':'policy_train',
        'packet_sha256':packet_pin,'cpu_acceptance_sha256':packet['files']['cpu-acceptance.json'],
        'prepared_sha256':packet['files']['prepared.json'],'plan_sha256':packet['plan_sha256'],
        'freeze_sha256':packet['freeze_sha256'],'namespace_admission_sha256':packet['namespace_admission_sha256'],
        'resources':RESOURCES,'deadlines':DEADLINES,'required_findings':0,
        'source_runtime_scheduler_admitted':True,'scientific_protocol_frozen':True,'namespace_owned':True}
    need(type(admission) is dict and set(admission)==set(expected)|{'output','site_readiness_sha256'}
        and all(exact(admission.get(k),v) for k,v in expected.items())
        and pin(admission['site_readiness_sha256']) and type(admission['output']) is str
        and Path(admission['output']).is_absolute(),'independent scientific admission differs')


def validate_prepared(prepared,packet,data):
    cpu_packet=decode(data['cpu-packet.json'])
    need(cpu_packet['schema']=='ace-scientific-training-preparation-cpu-v1'
        and cpu_packet['scope']=='policy_train','original scientific CPU packet required')
    accepted=decode(data['cpu-acceptance.json'])
    expected={'schema':CPU_ACCEPTANCE_SCHEMA,'status':'accepted','scope':'policy_train','required_findings':0,
        'cpu_packet_sha256':packet['files']['cpu-packet.json'],
        'prepared_sha256':packet['files']['prepared.json'],'plan_sha256':packet['plan_sha256'],
        'freeze_sha256':packet['freeze_sha256'],'namespace_admission_sha256':packet['namespace_admission_sha256'],
        'complete_custody_verified':True,'runtime_qualified_for_this_cpu_execution':True,
        'owned_process_cleanup_verified':True,'training_execution_qualified':False,'scientific_qualified':False}
    need(type(accepted) is dict and set(accepted)==set(expected)|{'job_id'}
        and all(exact(accepted.get(k),v) for k,v in expected.items())
        and type(accepted['job_id']) is str and re.fullmatch('[1-9][0-9]*',accepted['job_id']),
        'independent actual scientific CPU acceptance differs')
    for key in ('archive','manifest','model_files','runtime','runtime_source'):
        need(exact(packet[key],cpu_packet[key]),'accepted CPU runtime/model input changed: '+key)
    # The CPU tokenizer-only directory intentionally differs from the GPU full model directory.
    cpu_sources=cpu_packet['source_names']
    need(type(cpu_sources) is list and len(cpu_sources)==len(set(cpu_sources))
        and PREPARATION_SOURCES<=set(cpu_sources)
        and all(cpu_packet['files'][n]==packet['files'][n] for n in set(cpu_sources)&set(SOURCE_NAMES)),
        'accepted CPU/training shared source closure differs')
    need(packet['files']['llm_intervention_runtime_archive.py']==cpu_packet['files']['llm_intervention_runtime_archive.py'],
        'accepted runtime archive source differs')
    need(cpu_packet['collection']['freeze_sha256']==packet['freeze_sha256'], 'collection freeze differs')
    need(data['prepared.json']==(canonical(prepared)+'\\n').encode()
        and prepared['training_plan_sha256']==packet['plan_sha256']==sha(canonical(prepared['training_plan']).encode())
        and prepared['training_plan']['outer_provenance_receipt_sha256']==packet['files']['cpu-packet.json']
        and prepared['tokenizer_sha256']==sha(canonical(packet['model_files']).encode()),
        'original prepared bytes, plan or model tokenizer identity differs')
    for key,name in (('collection_terminal_sha256','terminal.json'),('collection_inventory_sha256','inventory.json'),
                     ('collection_plan_sha256','plan.json')):
        need(prepared[key]==cpu_packet['collection']['files'][name],'original collection lineage differs: '+key)
    records=prepared['training_plan']['records']
    need(len(records)==160 and all(0<len(r['prompt_ids'])<=4744 for r in records),
        'actual saved prompt exceeds measured 4744-token resource envelope; no truncation permitted')
    return cpu_packet


def authenticate(path,packet_pin,admission_path,admission_pin):
    root=Path(path).absolute().parent
    packet=decode(capture(path,packet_pin,256*1024))
    packet_shape(packet)
    admission=decode(capture(admission_path,admission_pin,128*1024))
    validate_admission(admission,packet,packet_pin)
    # Capture every input before executing even stdlib helper source.
    data={n:capture(root/n,p,MAX_PREPARED if n=='prepared.json' else 8*1024**2)
          for n,p in packet['files'].items()}
    prepared=decode(data['prepared.json'])
    validate_prepared(prepared,packet,data)
    need(Path(__file__).absolute()==root/ENTRY,'frozen entrypoint must be beside packet')
    service=module('pinned_scientific_service',root/'llm_intervention_model_service.py',data['llm_intervention_model_service.py'])
    cpu=module('pinned_scientific_cpu',root/CPU,data[CPU])
    d=module('pinned_scientific_diagnostic',root/DIAGNOSTIC,data[DIAGNOSTIC])
    gpu=module('pinned_scientific_gpu',root/GPU,data[GPU])
    helper=module('pinned_scientific_supervisor',root/SUPERVISOR,data[SUPERVISOR])
    # Full pure roster/exposure/recipe validation precedes staging and heavy imports.
    loader=CapturedSources({n:data[n] for n in packet['source_names']},root)
    sys.meta_path.insert(0,loader)
    try:
        worker=importlib.import_module(Path(WORKER).stem)
        worker._plan(prepared,prepared_sha256=packet['files']['prepared.json'],plan_sha256=packet['plan_sha256'])
    finally:
        sys.meta_path.remove(loader)
        for name,mod in loader.loaded.items():
            if sys.modules.get(name) is mod:del sys.modules[name]
    return root,packet,data,packet,prepared,service,cpu,d,gpu,helper


def authenticate_allocation(raw,job_id,resources,helper):
    need(exact(resources,RESOURCES) and re.fullmatch('[1-9][0-9]*',job_id),'fixed resources/job required')
    fields=helper.scheduler_fields(raw)
    expected={'JobId':job_id,'Account':'ucb736_asc2','Partition':'aa100','QOS':'gpu-testing',
        'JobState':'RUNNING','NumNodes':'1','NumTasks':'1','TimeLimit':'00:45:00',
        'Requeue':'0','Restarts':'0','NumCPUs':'4','CPUs/Task':'4'}
    need(all(fields.get(k)==v for k,v in expected.items()) and fields.get('UserId','').startswith('paco0228('),
        'scheduler identity/state/allocation differs')
    def tres(text):
        result={}
        for pair in text.split(','):
            need(pair.count('=')==1,'invalid resource evidence')
            key,value=pair.split('=');need(key not in result,'duplicate resource');result[key]=value
        need(result.get('cpu')=='4' and helper.memory_mib(result.get('mem',''))==15360
            and result.get('node')=='1' and result.get('gres/gpu:a100_3g.20gb')=='1'
            and result.get('gres/gpu','1')=='1'
            and not any(k.startswith('gres/') and k not in ('gres/gpu','gres/gpu:a100_3g.20gb') for k in result),
            'actual/requested CPU memory MIG resources differ')
        return result
    return {'fields':fields,'allocated_resources':tres(fields.get('AllocTRES','')),
            'requested_resources':tres(fields.get('ReqTRES',''))}


def positive_owned_memory(sample,pid):
    if sample.get('returncode')!=0 or type(sample.get('owned_rows')) is not list or len(sample['owned_rows'])!=1:
        return False
    row=sample['owned_rows'][0].split(',')
    if len(row)!=3 or row[0].strip()!=str(pid) or not row[1].strip():return False
    try:memory=float(row[2].strip())
    except ValueError:return False
    return math.isfinite(memory) and memory>0


class ProgressWatch:
    """Completed per-record score events count; telemetry is not utilization %."""
    def __init__(self,now,progress,pid):
        self.last_gpu=self.last_progress=now
        self.progress=set(progress);self.pid=pid
    def observe(self,now,sample,progress):
        if positive_owned_memory(sample,self.pid):self.last_gpu=now
        new=set(progress)
        if new-self.progress:self.last_progress=now
        self.progress.update(new)
        if now-self.last_gpu>DEADLINES['telemetry']:
            raise TimeoutError('no reliable positive owned GPU memory for 90 seconds; utilization uncertain')
        if now-self.last_progress>DEADLINES['progress']:
            raise TimeoutError('no completed training/inference operation for 180 seconds')
        return {'last_gpu_monotonic':self.last_gpu,'last_progress_monotonic':self.last_progress,
                'progress':sorted(self.progress),'progress_bound_seconds':180,'telemetry_bound_seconds':90}


def arm_hard_deadline(start,current):
    """Reserve absolute cleanup/reporting time; never call the old 580s alarm."""
    def final(sig,frame):
        if current is not None:
            try:os.killpg(current.pid,signal.SIGKILL)
            except ProcessLookupError:pass
        os._exit(124)
    signal.signal(signal.SIGALRM,final)
    for sig in (signal.SIGINT,signal.SIGTERM):signal.signal(sig,signal.SIG_IGN)
    signal.setitimer(signal.ITIMER_REAL,max(.001,start+DEADLINES['hard']-time.monotonic()))


def validate_handoff(handoff,args,now,parent_pid,job_id):
    need(set(handoff)=={'packet_sha256','admission_sha256','runtime_stage_sha256','parent_pid','job_id','started','deadlines'}
        and handoff['packet_sha256']==args.packet_sha256 and handoff['admission_sha256']==args.admission_sha256
        and handoff['runtime_stage_sha256']==args.runtime_stage_sha256
        and type(handoff['parent_pid']) is int and handoff['parent_pid']==parent_pid
        and handoff['job_id']==job_id and re.fullmatch('[1-9][0-9]*',job_id)
        and type(handoff['started']) in (int,float) and math.isfinite(handoff['started'])
        and 0<handoff['started']<=now and exact(handoff['deadlines'],DEADLINES)
        and now<handoff['started']+DEADLINES['worker'],'inherited absolute worker deadline/parent differs')
    return handoff['started']+DEADLINES['worker']

'''
parent=s[s.index('def parent('):s.index('def main(')]
parent=parent.replace('gpu.arm_final_deadline(start,current)','arm_hard_deadline(start,current)').replace("gpu.authenticate_allocation(scheduler,job,packet['resources'],helper)","authenticate_allocation(scheduler,job,packet['resources'],helper)")
parent=parent.replace('ace-screen-training-shape-', 'ace-scientific-training-')
parent=parent.replace("        command=[", "        handoff_pin=save(out/'handoff.json',{'packet_sha256':args.packet_sha256,\n            'admission_sha256':args.admission_sha256,'runtime_stage_sha256':stage_pin,\n            'parent_pid':os.getpid(),'job_id':job,'started':start,'deadlines':DEADLINES})\n        command=[")
parent=parent.replace("'--runtime-stage-sha256',stage_pin,'--worker-deadline',str(start+540)]", "'--runtime-stage-sha256',stage_pin,\n            '--admission',str(Path(args.admission).absolute()),'--admission-sha256',args.admission_sha256,\n            '--handoff',str(out/'handoff.json'),'--handoff-sha256',handoff_pin]")
parent=parent.replace('start+540','start+DEADLINES[\'worker\']').replace('start+550',"start+DEADLINES['soft']").replace('start+565',"start+DEADLINES['cleanup']").replace('start+580',"start+DEADLINES['hard']")
parent=parent.replace("if sample.get('returncode')==0 and sample.get('owned_rows'):gpu_seen=True", "if positive_owned_memory(sample,current.pid):gpu_seen=True")
parent=parent.replace('verified_at is None and gpu_seen and positive_work', 'verified_at is None and positive_owned_memory(sample,current.pid) and positive_work')
parent=parent.replace("ProgressWatch(time.monotonic(),progress_records(session/'worker/artifacts'))", "ProgressWatch(time.monotonic(),progress_records(session/'worker/artifacts'),current.pid)")
parent=parent.replace('(550 if verified_at is not None else 240)',"(DEADLINES['soft'] if verified_at is not None else DEADLINES['startup'])")
parent=parent.replace('artificial_training_complete','scientific_training_complete')
parent=parent.replace("        if current is not None and not (out/'cleanup.json').exists():\n            save(out/'cleanup.json',helper.terminate(current,min(time.monotonic()+12,start+DEADLINES['cleanup'])))\n        save(out/'failure.json',{'type':type(exc).__name__,'message':str(exc),'traceback':traceback.format_exc()})", "        preserve_failure(out,exc,current,helper,start)")
parent=parent.replace("'packet_sha256':args.packet_sha256,'stage_sha256':stage_pin", "'packet_sha256':args.packet_sha256,'admission_sha256':args.admission_sha256,'stage_sha256':stage_pin")
ending='''
def preserve_failure(out,exc,current,helper,start):
    # Publish the original error before secondary cleanup/publication can fail.
    first={'type':type(exc).__name__,'message':str(exc),'traceback':traceback.format_exc()}
    try:save(out/'failure.json',first)
    except BaseException:
        traceback.print_exc(file=sys.stderr)
    if current is not None and not (out/'cleanup.json').exists():
        try:save(out/'cleanup.json',helper.terminate(current,min(time.monotonic()+12,start+DEADLINES['cleanup'])))
        except BaseException as secondary:
            try:save(out/'cleanup-failure.json',{'type':type(secondary).__name__,'message':str(secondary)})
            except BaseException:traceback.print_exc(file=sys.stderr)


def main():
    p=argparse.ArgumentParser(description=__doc__)
    for n in ('packet','packet-sha256','admission','admission-sha256','output'):p.add_argument('--'+n,required=True)
    p.add_argument('--worker',action='store_true')
    for n in ('runtime-stage','runtime-stage-sha256','handoff','handoff-sha256'):p.add_argument('--'+n)
    args=p.parse_args()
    args.started,args.process_started=time.monotonic(),time.process_time()
    out=Path(args.output).absolute()
    # Resolve before publication, so aliases cannot overwrite the immutable input tree.
    inputs=Path(args.packet).resolve(strict=True).parent
    target=out.resolve()
    need(target!=inputs and inputs not in target.parents and target not in inputs.parents,
        'output must be disjoint from captured input tree')
    out.mkdir(mode=0o700,exist_ok=False)
    def interrupted(sig,frame):raise TimeoutError('scientific training authentication/worker signal '+str(sig))
    for sig in (signal.SIGALRM,signal.SIGTERM,signal.SIGINT):signal.signal(sig,interrupted)
    try:
        deadline=args.started+DEADLINES['startup']
        if args.worker:
            need(args.handoff and args.handoff_sha256 and args.runtime_stage and args.runtime_stage_sha256,
                 'independent parent handoff/stage required')
            handoff=decode(capture(args.handoff,args.handoff_sha256,128*1024))
            deadline=validate_handoff(handoff,args,time.monotonic(),os.getppid(),os.environ.get('SLURM_JOB_ID',''))
        signal.setitimer(signal.ITIMER_REAL,max(.001,deadline-time.monotonic()))
        context=authenticate(args.packet,args.packet_sha256,args.admission,args.admission_sha256)
        admission=decode(capture(args.admission,args.admission_sha256,128*1024))
        expected=Path(admission['output']).absolute()
        if args.worker:expected=expected/'session/worker'
        need(out==expected,'admitted exclusive output differs')
        if args.worker:child(args,*context)
        else:parent(args,*context)
    except BaseException as exc:
        if not (out/'failure.json').exists():
            save(out/'failure.json',{'type':type(exc).__name__,'message':str(exc),'traceback':traceback.format_exc()})
        raise
    finally:
        signal.setitimer(signal.ITIMER_REAL,0)


if __name__=='__main__':main()
'''
path=Path('scripts/research/supervise_llm_intervention_scientific_training_gpu.py')
with path.open('x') as f:f.write(intro+head+source+prep+constants+'\n'+helpers+auth+loader+child+'def validate_worker('+validator+readers+parent+ending)
