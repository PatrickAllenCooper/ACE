def _plan(prepared,*,prepared_sha256,plan_sha256):
    if prepared['training_plan'].get('toy_gate') != 'valid':raise ValueError('pure worker plan rejected')
    return prepared['training_plan']
