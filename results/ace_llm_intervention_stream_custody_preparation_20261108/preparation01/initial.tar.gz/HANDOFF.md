# Prospective streamed custody transport — independent review required

Source-only sidecar in a new exclusive temp tree. The running collection02 collector and all TOKEN/GPU coordinator sources, repository files, scientific freeze, acceptance contracts, allocations and jobs are unchanged. No actual remote command, transfer, worker, model, tokenizer, scientific draw or project callable ran. Only the NEW helper and fabricated local subprocess/archive cases ran.

## Exact final sources

- `stream_custody.py`: `efa8d878cd0f41d6eae691d9d7040a152f86673bc5c70724dcab6a55dda8c417`
- `test_stream_custody.py`: `fff2d4c1757bb29b53540045298ff1fa03f2612a22640fd91e3a50a6588d7dd4`
- `test_final_readback_delta.py`: `21ae2514ae67308f2120701b232db0f407ee0b9c8fca1d170bd44effcc58c30a`

No independent review verdict is asserted. Review and separately pin this new source before any future collector integration. Existing complete terminal inventory, source/packet/Git/review bindings, both locks, site/accounting/journal/namespace checks, exact upstream custody and scientific acceptance gates remain mandatory.

## Narrow transport design

One stdlib file exposes three CLI modes and corresponding functions; it contains no site hostname, Slurm/job command, retry, cancellation of study jobs, allocation or acceptance authority. `emit` scans only caller-specified roots and standalone files, verifies their complete expected inventory, and emits an uncompressed USTAR stream to stdout. It writes no remote archive or other remote file. Pass the reviewed source via `python3 -B -c SOURCE emit --request-sha256 FULL_PIN`; stdin carries the pinned request bytes. This avoids a remote helper upload and bytecode creation. The future collector must quote that argv safely and authenticate the exact embedded source/command before running its single explicitly authorized SSH command.

`capture` executes exactly one caller-supplied, independently pinned argv without a shell, with a mandatory 1..7200-second transport timeout. It creates a new exclusive attempt directory, retains request/argv/partial archive/stderr/result, bounds archive bytes from the complete inventory, monitors stderr size, and kills only its owned local process group on a transport failure/timeout. A failed attempt is never erased or automatically reused/retried. The remote read-only producer can stop on the resulting closed pipe; this helper does not own a remote scientific process or authorize remote cleanup.

`materialize` requires a successful pinned capture result, exact retained archive/stderr bytes, the producer's source-unchanged receipt, and separately pinned complete remote observations from before and after transfer. It exclusively claims its materialization intent, creates two separate empty roots, writes every file independently, rereads both complete trees, verifies distinct inodes/link-count one for every file, and rereads the archive hash. A failed extraction or second-copy failure preserves the archive, intent and every partial/complete copy. No successful receipt is written on failure. Completion status is `transport_verified_pending_collector_gates`; acceptance is always false.

## Input and caller interface

The pinned request is a transport mapping, not a scientific/admission schema:

```
{
  "roots": {"launch": "/absolute/canonical/immutable/job-root",
            "common": "/absolute/canonical/immutable/upstream-root"},
  "single_files": {"namespace.json": "/absolute/canonical/registry.json"},
  "inventory": {
    "files": {"launch/example": {"bytes": 123, "sha256": "FULL_PIN"},
              "namespace.json": {"bytes": 456, "sha256": "FULL_PIN"}},
    "directories": ["launch", "common", "common/empty-directory"]
  }
}
```

The example is shape-only, deliberately not runnable evidence. Use each future collector's complete already-verified `files` and `directories` maps verbatim. Include every root label and all empty directories; do not select/filter private candidates, failures, logs or evolving upstream files. Hardlink names each appear as full regular file bytes. Original link topology is preserved in the existing observations and the emitter receipt, never reconstructed as local links.

CLI arguments:

- `capture --request PATH --request-sha256 PIN --command PATH --command-sha256 PIN --attempt NEW_ABSOLUTE_DIR --timeout SECONDS`. Command file is JSON argv, not shell text. The capture records canonical argv bytes and their SHA; the independently reviewed collector must bind this argv/embedded emitter source and all roots/request bytes to its concrete metadata.
- `materialize --attempt DIR --capture-sha256 PIN --before PATH --before-sha256 PIN --after PATH --after-sha256 PIN --copy-a NEW_ABSOLUTE_DIR --copy-b NEW_ABSOLUTE_DIR`.

The emitter must be the sole stdout producer: no SSH banner, pipeline, shell wrapper that suppresses its nonzero exit, extra stdout log or compression. Its last stderr line is the JSON source-unchanged receipt; all stderr, including transport diagnostics, is retained and hashed. Producer exception/nonzero exit is disqualifying even if tar end markers were already written.

Caller sequence: preserve exact reviewed coordinator/source/intent and existing terminal/readiness gates under both locks; acquire and pin the full before observation; derive/pin the complete request; check space/deadline; capture once; acquire/pin the full independent after observation and run the collector's EXISTING accounting/queue/journal/namespace/upstream/immutability comparisons; materialize both independent copies; finish all existing collector gates/capsule inventories. The helper compares exact files, directories and original-hardlink observations only. It does not replace the caller's whole observation reconciliation or independently decide that a job is terminal.

Keep the successful archive, source/argv/request, capture and materialization records as transport evidence and copy/seal them into the final custody capsule under the reviewed collector's normal complete inventory. Partial/failed attempts are retained separately and cannot silently become the successful capsule. No deletion policy or retry authority is introduced.

## Safe format and explicit bounds

Only regular USTAR files and canonical USTAR directory entries are accepted. The parser reads raw 512-byte records, rather than an archive iterator that could hide extension headers. It rejects absolute/empty/dot/dot-dot/backslash/control-character paths, symlinks, tar hardlinks, device/FIFO entries, sparse/GNU/PAX extensions, duplicate/colliding names, missing/extra files or directories, hash/size discrepancies, truncation, invalid checksums, nonzero padding, additional archive streams and nonzero trailing content. It never calls `extractall` or honors archive owner/mode/time metadata; new output directories are mode0700 subject to umask; new regular files use the caller's umask inside those private directories. Original remote mode/owner/timestamps are not restored.

Bounds: 262144 total file/directory members, 8GiB total content, 256MiB per file, 128MiB metadata/stderr monitoring limit. Names must fit canonical UTF-8 USTAR (at most255 bytes overall, representable name/prefix split). Unsupported names fail during request/header preflight before a transport attempt, not by silently enabling extensions or omitting files. No compression is used. These are transport rejection bounds, not permission to widen an existing collector's source scope. Validate that a future exact inventory fits before adoption.

All source path components must be ordinary directories (O_NOFOLLOW); source files are opened without following links. Roots must be explicitly supplied with canonical spelling. This helper does not infer or bless the CURC /scratch→/gpfs alias. A future collector must retain its existing approved root/alias gate and supply the verified canonical transport path while preserving the archive label/logical source mapping. Local destination parents must also be canonical ordinary directories; callers retain exclusive ownership of those parents during materialization.

The producer hashes the source before, while emitting, and after; compares source device/inode/type/size/mtime/ctime/link-count snapshots; and verifies full membership each time. These checks and the independently pinned full observations detect observed changes. They do not claim protection against a privileged adversary restoring filesystem state, nor replace quiescent-job/lock gates. Source content is read as opaque bytes; no private training/response/model data is decoded.

## Retained NEW fabricated evidence

`attempt01/` preserves exact initial source/test bytes, full stdout/stderr, source pins, execution receipt and all fabricated fixtures/partial archives. Twelve new methods passed once: positive hardlink expansion/empty-directory roster/two independent copies; unsafe paths; links/devices/extensions; duplicate/missing/extra membership; hash/size/padding/truncation/trailing bytes; source symlink/FIFO/parent aliases; mutation during emission; failed/nonzero/timed-out/over-bound local producers; before/after pins and bounds; archive tamper/missing producer receipt; exclusive output and second-copy failure preservation; USTAR name bounds.

Initial measured child CPU0.295160s, wall1.341048417s, maximum child RSS23658496 bytes (Darwin units). No test failure occurred. Test time includes only fabricated local helper processes, never SSH.

`delta02/` preserves final source and two NEW focused methods only, after adding final readback of both copies, preflight of USTAR names before capture, and set-based directory lookup. One method checks unchanged copies positively and catches mutation of copyA during copyB; the other proves an unrepresentable request rejects before attempt/process creation. Both passed; original12 were not repeated. Measured child CPU0.126253s, wall0.150481375s, maximum child RSS22528000 bytes. `final-readback.delta.diff` records exact changes; `before-final-readback.py` preserves the predecessor. Total measured child CPU0.421413s; authoring/static/package overhead unmetered. No allocation or accounting baseline changed.

Test fixtures intentionally retain symlinks and source hardlinks. `inventory.json` uses lstat: regular bytes have hashes/size, symlinks have link-target metadata without dereferencing, and directory entries are recorded. Do not recursively follow fixture links when later packaging; if archiving this evidence, represent links as explicit metadata and regular hardlink names as independent bytes.

No WAN or production filesystem benchmark was run; throughput improvement is prospective. The design removes per-file WAN transfer round trips, but performs complete source/local reads, USTAR padding, retained archive storage and per-file local fsync. Budget local space for archive plus both copies and normal coordinator evidence; preserve the collector's stricter space checks. Distinct review and concrete future collector integration review remain required.

Actual collection02 audit remains the priority when parent confirms full original custody and pins. This helper provides no collection acceptance or42/86 baseline.
