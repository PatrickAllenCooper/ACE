"""Only new final-readback and USTAR request-preflight boundaries; no original rerun."""
from pathlib import Path
import sys
import unittest
from unittest import mock
sys.path.insert(0,str(Path(__file__).parent))
from test_stream_custody import StreamCustodyTests, m


class FinalReadbackDelta(unittest.TestCase):
    setUp = StreamCustodyTests.setUp
    tearDown = StreamCustodyTests.tearDown
    meta = staticmethod(StreamCustodyTests.meta)
    nextpath = StreamCustodyTests.nextpath
    capture_good = StreamCustodyTests.capture_good
    materialize_good = StreamCustodyTests.materialize_good

    def test_final_readback_positive_and_first_copy_mutation_rejected(self):
        attempt, result, bp, ap = self.capture_good()
        receipt = self.materialize_good(attempt, bp, ap)
        self.assertEqual(receipt['status'],'transport_verified_pending_collector_gates')
        attempt, result, bp, ap = self.capture_good()
        original = m.extract_archive
        first = None
        def changed(archive, expected, destination):
            nonlocal first
            value = original(archive, expected, destination)
            if first is None:
                first = Path(destination)
            else:
                (first/'launch/a').write_bytes(b'mutation')
            return value
        with mock.patch.object(m,'extract_archive',changed), self.assertRaises(ValueError):
            self.materialize_good(attempt,bp,ap)
        self.assertTrue((attempt/'materialization.intent.json').exists())
        self.assertFalse((attempt/'materialization.json').exists())
        self.assertTrue((attempt/'archive.tar').exists())

    def test_unrepresentable_ustar_request_rejected_before_attempt_creation(self):
        n = 'x'*101
        request = dict(roots={},single_files={n:str(self.root/'claim.json')},
                       inventory=dict(files={n:self.meta(b'')},directories=[]))
        attempt = self.nextpath('must-not-exist')
        with self.assertRaises(ValueError):
            m.capture([sys.executable,'-c',"raise RuntimeError('must not execute')"],m.raw(request),attempt,5)
        self.assertFalse(attempt.exists())


if __name__ == '__main__':
    unittest.main(defaultTest='FinalReadbackDelta',verbosity=2)
