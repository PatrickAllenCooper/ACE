"""New regressions for R1/R2/R3 only. No original test batch is rerun."""
import json
import os
from pathlib import Path
import signal
import sys
import unittest
from unittest import mock
sys.path.insert(0, str(Path(__file__).parent))
from test_stream_custody import StreamCustodyTests, m


class ReviewDelta(unittest.TestCase):
    setUp = StreamCustodyTests.setUp
    tearDown = StreamCustodyTests.tearDown
    meta = staticmethod(StreamCustodyTests.meta)
    nextpath = StreamCustodyTests.nextpath
    capture_good = StreamCustodyTests.capture_good
    materialize_good = StreamCustodyTests.materialize_good

    def test_r1_record_padding_boundary_roundtrip(self):
        content = b'x' * 9216
        p = self.root/'boundary'; p.write_bytes(content)
        self.inv = dict(files={'boundary': self.meta(content)}, directories=[])
        self.request = dict(roots={}, single_files={'boundary': str(p)}, inventory=self.inv)
        data = m.raw(self.request)
        attempt = self.nextpath('capture')
        m.capture([sys.executable, '-B', str(Path(m.__file__).resolve()), 'emit',
                   '--request-sha256', m.sha(data)], data, attempt, 5)
        self.assertEqual((attempt/'archive.tar').stat().st_size, 20480)
        self.assertEqual(m.archive_bound(self.inv), 20480)
        before = self.nextpath('before'); before.write_bytes(m.raw(self.inv))
        after = self.nextpath('after'); after.write_bytes(m.raw(self.inv))
        result = self.materialize_good(attempt, before, after)
        for root in result['copies']:
            self.assertEqual((Path(root)/'boundary').read_bytes(), content)

    def test_r2_exited_leader_live_descendant_is_closed(self):
        pid_path = self.root/'owned-child.pid'
        code = """import os,time,sys
pid=os.fork()
if pid:
 os._exit(0)
with open(sys.argv[1],'x') as f:
 f.write(str(os.getpid()));f.flush();os.fsync(f.fileno())
time.sleep(30)
"""
        attempt = self.nextpath('capture')
        pid = None
        try:
            with self.assertRaisesRegex(ValueError, 'transport deadline exceeded'):
                m.capture([sys.executable, '-c', code, str(pid_path)], m.raw(self.request), attempt, 1)
            pid = int(pid_path.read_text())
            result = json.loads((attempt/'capture.json').read_text())
            self.assertEqual(result['returncode'], 0)
            self.assertEqual(result['status'], 'failed')
            self.assertTrue(result['cleanup']['signal_sent'])
            self.assertTrue(result['cleanup']['leader_reaped'])
            self.assertTrue(result['cleanup']['group_absent'])
            with self.assertRaises(ProcessLookupError):
                os.kill(pid, 0)
        finally:
            if pid is None and pid_path.exists():
                pid = int(pid_path.read_text())
            if pid is not None:
                try: os.kill(pid, signal.SIGKILL)
                except ProcessLookupError: pass

    def test_r2_cleanup_error_does_not_mask_original_failure(self):
        attempt = self.nextpath('capture')
        with mock.patch.object(m.os, 'killpg', side_effect=PermissionError('fabricated signal failure')):
            with self.assertRaisesRegex(ValueError, 'producer/transport returned nonzero'):
                m.capture([sys.executable, '-c', 'import sys;sys.exit(7)'], m.raw(self.request), attempt, 5)
        result = json.loads((attempt/'capture.json').read_text())
        self.assertEqual(result['error']['message'], 'producer/transport returned nonzero')
        self.assertEqual(result['returncode'], 7)
        self.assertFalse(result['cleanup']['verified'])
        self.assertTrue(result['cleanup']['errors'])
        self.assertIn('archive.tar', result)
        self.assertIn('stderr.log', result)

    def test_r3_unexpected_top_level_file_directory_or_link_rejects(self):
        for kind in ('file', 'directory', 'symlink'):
            with self.subTest(kind=kind):
                attempt, result, before, after = self.capture_good()
                original = m.extract_archive
                copies = []
                def add_extra(archive, expected, destination):
                    answer = original(archive, expected, destination)
                    copies.append(Path(destination))
                    if len(copies) == 2:
                        p = copies[0]/'unexpected'
                        if kind == 'file': p.write_bytes(b'new')
                        elif kind == 'directory': p.mkdir()
                        else: p.symlink_to(self.root/'missing-target')
                    return answer
                with mock.patch.object(m, 'extract_archive', add_extra):
                    with self.assertRaisesRegex(ValueError, 'unexpected local top-level membership'):
                        self.materialize_good(attempt, before, after)
                self.assertTrue((attempt/'materialization.intent.json').exists())
                self.assertFalse((attempt/'materialization.json').exists())
                self.assertTrue((attempt/'archive.tar').exists())


if __name__ == '__main__':
    unittest.main(defaultTest='ReviewDelta', verbosity=2)
