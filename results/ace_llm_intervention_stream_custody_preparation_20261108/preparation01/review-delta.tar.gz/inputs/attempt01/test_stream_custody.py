"""Only NEW fabricated local archive/transport edges; no project/runtime imports."""
import hashlib
import importlib.util
import io
import json
import os
from pathlib import Path
import subprocess
import sys
import tarfile
import tempfile
import unittest
from unittest import mock

SPEC = importlib.util.spec_from_file_location('stream_custody', Path(__file__).with_name('stream_custody.py'))
m = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(m)


class StreamCustodyTests(unittest.TestCase):
    def setUp(self):
        self.root = Path(tempfile.mkdtemp(prefix='fabricated-', dir=Path(__file__).parent)).resolve()
        (self.root/'src').mkdir()
        (self.root/'src'/'empty').mkdir()
        (self.root/'src'/'a').write_bytes(b'artificial bytes\x00\xff')
        os.link(self.root/'src'/'a', self.root/'src'/'b')
        (self.root/'claim.json').write_bytes(b'{"artificial":true}\n')
        self.inv = dict(files={
            'launch/a': self.meta((self.root/'src'/'a').read_bytes()),
            'launch/b': self.meta((self.root/'src'/'b').read_bytes()),
            'claim.json': self.meta((self.root/'claim.json').read_bytes())},
            directories=['launch', 'launch/empty'])
        self.request = dict(roots={'launch': str(self.root/'src')},
            single_files={'claim.json': str(self.root/'claim.json')}, inventory=self.inv)
        self.counter = 0

    def tearDown(self):
        pass  # Retain every fabricated tree/partial archive with this evidence attempt.

    @staticmethod
    def meta(data):
        return dict(bytes=len(data), sha256=hashlib.sha256(data).hexdigest())

    def nextpath(self, label):
        self.counter += 1
        return self.root/(str(self.counter)+'-'+label)

    def emitted(self):
        stream = io.BytesIO()
        receipt = m.emit(self.request, stream)
        return stream.getvalue(), receipt

    def unpack(self, data, inv=None):
        path = self.nextpath('archive.tar'); path.write_bytes(data)
        dest = self.nextpath('out')
        return m.extract_archive(path, inv or self.inv, dest)

    def raw_archive(self, entries):
        blocks = []
        for info, data in entries:
            blocks.append(info.tobuf(format=tarfile.USTAR_FORMAT, encoding='utf-8', errors='strict'))
            blocks.append(data + b'\0' * ((-len(data)) % 512))
        return b''.join(blocks) + b'\0'*1024

    def capture_good(self):
        data = m.raw(self.request)
        command = [sys.executable, '-B', str(Path(m.__file__).resolve()), 'emit', '--request-sha256', m.sha(data)]
        attempt = self.nextpath('attempt')
        result = m.capture(command, data, attempt, 20)
        before = dict(self.inv, original_hardlink_groups=[dict(paths=['launch/a','launch/b'], link_count=2)])
        bp = self.nextpath('before.json'); bp.write_bytes(m.raw(before))
        ap = self.nextpath('after.json'); ap.write_bytes(m.raw(before))
        return attempt, result, bp, ap

    def materialize_good(self, attempt, bp, ap):
        return m.materialize(attempt, m.sha((attempt/'capture.json').read_bytes()), bp, m.sha(bp.read_bytes()),
            ap, m.sha(ap.read_bytes()), self.nextpath('copy-a'), self.nextpath('copy-b'))

    def test_roundtrip_hardlinks_are_independent_bytes_and_empty_directory_roster(self):
        attempt, result, bp, ap = self.capture_good()
        receipt = self.materialize_good(attempt, bp, ap)
        self.assertFalse(receipt['acceptance'])
        self.assertEqual(receipt['files'], 3)
        copies = [Path(x) for x in receipt['copies']]
        self.assertTrue(all((p/'launch'/'empty').is_dir() for p in copies))
        inodes = {(p/n).stat().st_ino for p in copies for n in ('launch/a','launch/b')}
        self.assertEqual(len(inodes), 4)
        self.assertTrue(all((p/n).stat().st_nlink == 1 for p in copies for n in self.inv['files']))
        with tarfile.open(attempt/'archive.tar') as tf:
            self.assertTrue(all(i.type in (tarfile.REGTYPE,tarfile.DIRTYPE) for i in tf.getmembers()))
        with self.assertRaises(FileExistsError):
            self.materialize_good(attempt, bp, ap)
        # A capture attempt is also exclusive, with no implicit reuse.
        with self.assertRaises(FileExistsError):
            m.capture([sys.executable, '-c', 'pass'], m.raw(self.request), attempt, 5)

    def test_unsafe_paths_rejected(self):
        for n in ('/outside', '../outside', 'launch/../outside', './launch', 'launch//a', 'launch/./a', 'launch\\a', 'launch/\na'):
            with self.subTest(name=repr(n)), self.assertRaises(ValueError):
                m.normalized(dict(files={n:self.meta(b'')}, directories=[]))
        info = m.header('launch'); info.name = 'launch//'
        with self.assertRaises(ValueError):
            self.unpack(self.raw_archive([(info,b'')]))
        info = m.header('launch/a', 0); info.name = '../outside'
        with self.assertRaises(ValueError):
            self.unpack(self.raw_archive([(info,b'')]))
        self.assertFalse((self.root.parent/'outside').exists())

    def test_links_devices_and_extension_headers_rejected(self):
        for kind in (tarfile.SYMTYPE, tarfile.LNKTYPE, tarfile.CHRTYPE, tarfile.BLKTYPE,
                     tarfile.FIFOTYPE, tarfile.XHDTYPE, tarfile.XGLTYPE, tarfile.GNUTYPE_LONGNAME,
                     tarfile.GNUTYPE_LONGLINK, tarfile.GNUTYPE_SPARSE):
            info = m.header('launch/a',0); info.type = kind
            info.linkname = 'launch/b' if kind in (tarfile.SYMTYPE,tarfile.LNKTYPE) else ''
            with self.subTest(kind=kind), self.assertRaises(ValueError):
                self.unpack(self.raw_archive([(info,b'')]))

    def test_duplicate_extra_missing_members_and_directory_roster_rejected(self):
        d = m.header('launch')
        for entries in ([(d,b''),(d,b'')], [(m.header('extra'),b'')], [(d,b'')], []):
            with self.subTest(entries=len(entries)), self.assertRaises(ValueError):
                self.unpack(self.raw_archive(entries))
        data, _ = self.emitted()
        inv = dict(files=self.inv['files'], directories=['launch','launch/empty','launch/unseen'])
        with self.assertRaises(ValueError):
            self.unpack(data, inv)
        info = m.header('launch/a', 0)
        with self.assertRaises(ValueError):
            self.unpack(self.raw_archive([(d,b''),(info,b'')]))

    def test_hash_size_padding_truncation_and_trailing_stream_rejected(self):
        data, _ = self.emitted()
        # Determine actual offsets using only the local fabricated archive.
        with tarfile.open(fileobj=io.BytesIO(data)) as tf:
            member = tf.getmember('launch/a'); offset = member.offset_data; end = offset+member.size
        bad = bytearray(data); bad[offset] ^= 1
        bad_padding = bytearray(data); bad_padding[end] = 1
        malformed_header = bytearray(data); malformed_header[0] ^= 1
        for value in (bytes(bad), bytes(bad_padding), bytes(malformed_header), data[:end-1], data+b'nonzero', data+data):
            with self.subTest(length=len(value)), self.assertRaises((ValueError, tarfile.HeaderError)):
                self.unpack(value)
        missing = self.raw_archive([(m.header('launch'),b'')])[:-512]
        with self.assertRaises(ValueError):
            self.unpack(missing)

    def test_source_symlink_special_files_and_alias_parents_rejected(self):
        alias = self.root/'source-alias'; alias.symlink_to(self.root/'src', target_is_directory=True)
        request = dict(self.request, roots={'launch':str(alias)})
        with self.assertRaises(OSError):
            m.emit(request, io.BytesIO())
        for kind in ('symlink','fifo'):
            path = self.root/'src'/'new'
            if kind == 'symlink': path.symlink_to(self.root/'claim.json')
            else: os.mkfifo(path)
            with self.subTest(kind=kind), self.assertRaises(ValueError):
                m.emit(self.request, io.BytesIO())
            path.unlink()
        alias_out = self.root/'output-alias'; alias_out.symlink_to(self.root/'src', target_is_directory=True)
        archive = self.root/'archive.tar'; archive.write_bytes(self.emitted()[0])
        with self.assertRaises(OSError):
            m.extract_archive(archive, self.inv, alias_out/'out')
        self.assertFalse((self.root/'src'/'out').exists())

    def test_source_mutation_during_emit_rejected(self):
        original_read = m.DigestReader.read
        touched = False
        def mutate(reader, size):
            nonlocal touched
            data = original_read(reader, size)
            if not touched:
                touched = True
                with (self.root/'src'/'a').open('ab') as f: f.write(b'changed')
            return data
        with mock.patch.object(m.DigestReader, 'read', mutate), self.assertRaises(ValueError):
            m.emit(self.request, io.BytesIO())
        self.assertTrue(touched)

    def test_capture_nonzero_timeout_overbound_preserve_partial_and_no_retries(self):
        variants = [
            ("import sys;sys.stdout.buffer.write(b'partial');sys.stdout.flush();sys.exit(7)",5),
            ("import sys,time;sys.stdout.buffer.write(b'partial');sys.stdout.flush();time.sleep(10)",1),
            ("import sys;sys.stdout.buffer.write(b'x'*20000);sys.stdout.flush()",5)]
        for code, deadline in variants:
            attempt = self.nextpath('failed')
            with self.subTest(code=code), self.assertRaises((ValueError, subprocess.TimeoutExpired)):
                m.capture([sys.executable,'-B','-c',code], m.raw(self.request), attempt, deadline)
            result = json.loads((attempt/'capture.json').read_bytes())
            self.assertEqual(result['status'], 'failed')
            self.assertGreater((attempt/'archive.tar').stat().st_size, 0)
            self.assertFalse(result['acceptance'])
            self.assertIn('error', result)

    def test_before_after_pin_and_inventory_mismatch_prevent_copies(self):
        attempt, result, bp, ap = self.capture_good()
        changed = json.loads(ap.read_bytes()); changed['files']['launch/a']['sha256'] = '0'*64
        ap.write_bytes(m.raw(changed))
        with self.assertRaises(ValueError): self.materialize_good(attempt, bp, ap)
        self.assertFalse((attempt/'materialization.intent.json').exists())
        with self.assertRaises(ValueError): m.read_pinned(bp, '0'*64)
        with self.assertRaises(ValueError): m.decode(b'{"x":1,"x":2}')
        with self.assertRaises(ValueError): m.decode(b'{"x":NaN}')
        for value in (-1, True, m.MAX_FILE_BYTES+1):
            inv = dict(files={'a':dict(bytes=value,sha256='0'*64)},directories=[])
            with self.assertRaises(ValueError): m.normalized(inv)

    def test_captured_archive_tampering_and_missing_emitter_receipt_rejected(self):
        attempt, result, bp, ap = self.capture_good()
        with (attempt/'archive.tar').open('ab') as f: f.write(b'x')
        with self.assertRaises(ValueError): self.materialize_good(attempt, bp, ap)
        # A zero exit without the authenticated producer protocol does not suffice.
        attempt = self.nextpath('wrong-producer')
        m.capture([sys.executable,'-B','-c',"print('not an archive')"],m.raw(self.request),attempt,5)
        with self.assertRaises(ValueError): self.materialize_good(attempt, bp, ap)

    def test_existing_output_preserved_and_second_copy_failure_keeps_first(self):
        attempt, result, bp, ap = self.capture_good()
        first, second = self.nextpath('copy-a'), self.nextpath('copy-b')
        second.mkdir(); (second/'keep').write_bytes(b'untouched')
        with self.assertRaises(FileExistsError):
            m.materialize(attempt,m.sha((attempt/'capture.json').read_bytes()),bp,m.sha(bp.read_bytes()),
                ap,m.sha(ap.read_bytes()),first,second)
        self.assertEqual((second/'keep').read_bytes(),b'untouched')
        self.assertEqual((first/'launch/a').read_bytes(),(self.root/'src/a').read_bytes())
        self.assertTrue((attempt/'archive.tar').exists())
        self.assertTrue((attempt/'materialization.intent.json').exists())
        self.assertFalse((attempt/'materialization.json').exists())

    def test_long_ustar_name_and_unrepresentable_names_fail_before_stream(self):
        # Valid prefix/name split beyond 100 bytes remains portable USTAR.
        name = 'launch/'+'d'*80+'/'+'f'*80
        info = m.header(name,0)
        self.assertEqual(tarfile.TarInfo.frombuf(info.tobuf(format=tarfile.USTAR_FORMAT), 'utf-8','strict').name,name)
        with self.assertRaises(ValueError): m.header('x'*101,0)
        with self.assertRaises(ValueError): m.name_ok('x'*256)


if __name__ == '__main__':
    unittest.main(verbosity=2)
